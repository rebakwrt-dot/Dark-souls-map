#define _CRT_SECURE_NO_WARNINGS
// dinput8 proxy: forwards DirectInput8Create and loads DSRMods DLLs.
// The log is flushed after every step so a crash identifies the last DLL being loaded.
#include <windows.h>
#include <objbase.h>
#include <algorithm>
#include <string>
#include <vector>

typedef HRESULT(WINAPI* DI8Create)(HINSTANCE, DWORD, REFIID, LPVOID*, LPUNKNOWN);

HRESULT WINAPI DirectInput8Create(HINSTANCE h, DWORD v, REFIID r, LPVOID* o, LPUNKNOWN u) {
    static DI8Create fn = nullptr;
    if (!fn) {
        char sys[MAX_PATH]{};
        GetSystemDirectoryA(sys, MAX_PATH);
        std::string p = std::string(sys) + "\\dinput8.dll";
        HMODULE real = LoadLibraryA(p.c_str());
        if (real) fn = (DI8Create)GetProcAddress(real, "DirectInput8Create");
    }
    return fn ? fn(h, v, r, o, u) : E_FAIL;
}

static HANDLE g_log = INVALID_HANDLE_VALUE;

static void Log(const std::string& msg) {
    if (g_log == INVALID_HANDLE_VALUE) return;
    SYSTEMTIME t{};
    GetLocalTime(&t);
    char prefix[64]{};
    wsprintfA(prefix, "[%02u:%02u:%02u.%03u] ", t.wHour, t.wMinute, t.wSecond, t.wMilliseconds);
    std::string line = prefix + msg + "\r\n";
    DWORD written = 0;
    WriteFile(g_log, line.data(), (DWORD)line.size(), &written, nullptr);
    FlushFileBuffers(g_log);
}

static bool GameWindowReady() {
    if (!GetModuleHandleA("d3d11.dll") || !GetModuleHandleA("dxgi.dll")) return false;
    HWND w = nullptr;
    DWORD pid = GetCurrentProcessId();
    while ((w = FindWindowExA(nullptr, w, nullptr, nullptr)) != nullptr) {
        DWORD p = 0;
        GetWindowThreadProcessId(w, &p);
        RECT rc{};
        if (p == pid && IsWindowVisible(w) && GetClientRect(w, &rc) &&
            rc.right > rc.left && rc.bottom > rc.top) return true;
    }
    return false;
}

static DWORD WINAPI LoadMods(LPVOID self) {
    char path[MAX_PATH]{};
    GetModuleFileNameA((HMODULE)self, path, MAX_PATH);
    std::string root = path;
    root = root.substr(0, root.find_last_of("\\/") + 1);
    std::string dir = root + "DSRMods\\";
    CreateDirectoryA(dir.c_str(), nullptr);
    g_log = CreateFileA((dir + "loader.log").c_str(), FILE_APPEND_DATA,
                        FILE_SHARE_READ | FILE_SHARE_WRITE, nullptr, OPEN_ALWAYS,
                        FILE_ATTRIBUTE_NORMAL, nullptr);
    Log("loader started");

    bool ready = false;
    for (int i = 0; i < 900; ++i) {
        if (GameWindowReady()) { ready = true; break; }
        Sleep(100);
    }
    if (!ready) {
        Log("ERROR: game window / D3D11 not ready after 90 seconds; no mod DLLs loaded");
        if (g_log != INVALID_HANDLE_VALUE) CloseHandle(g_log);
        return 0;
    }

    // Give the game additional time to finish the transition into the menu.
    Log("game window and D3D11 detected; waiting 8 seconds before loading mods");
    Sleep(8000);

    std::vector<std::string> found;
    WIN32_FIND_DATAA fd{};
    HANDLE h = FindFirstFileA((dir + "*.dll").c_str(), &fd);
    if (h != INVALID_HANDLE_VALUE) {
        do { if (!(fd.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY)) found.push_back(fd.cFileName); }
        while (FindNextFileA(h, &fd));
        FindClose(h);
    }

    // Load the rendering overlays first and DSRCombat last. Every attempt is logged
    // before LoadLibrary, so the log remains useful even if a DLL crashes in attach.
    const char* order[] = { "DSRMap.dll", "DSROptimize.dll", "DSRCombat.dll" };
    std::vector<std::string> names;
    for (const char* preferred : order) {
        auto it = std::find(found.begin(), found.end(), preferred);
        if (it != found.end()) { names.push_back(*it); found.erase(it); }
    }
    std::sort(found.begin(), found.end());
    names.insert(names.end(), found.begin(), found.end());

    if (names.empty()) Log("WARNING: no DLL files found in DSRMods");
    for (const auto& n : names) {
        Log("LOAD_BEGIN " + n);
        SetLastError(ERROR_SUCCESS);
        HMODULE mod = LoadLibraryA((dir + n).c_str());
        if (mod) Log("LOAD_OK " + n);
        else Log("LOAD_FAIL " + n + " error=" + std::to_string(GetLastError()));
        Sleep(1500);
    }
    Log("all mod DLL load attempts finished");
    if (g_log != INVALID_HANDLE_VALUE) {
        CloseHandle(g_log);
        g_log = INVALID_HANDLE_VALUE;
    }
    return 0;
}

BOOL APIENTRY DllMain(HMODULE m, DWORD reason, LPVOID) {
    if (reason == DLL_PROCESS_ATTACH) {
        DisableThreadLibraryCalls(m);
        HANDLE t = CreateThread(nullptr, 0, LoadMods, m, 0, nullptr);
        if (t) CloseHandle(t);
    }
    return TRUE;
}
