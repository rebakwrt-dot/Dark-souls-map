#define _CRT_SECURE_NO_WARNINGS
// Прокси dinput8.dll: пробрасывает DirectInput8Create в системную библиотеку
// и подгружает все *.dll из папки DSRMods рядом с собой.
#include <windows.h>
#include <objbase.h>
#include <cstdio>
#include <algorithm>
#include <string>
#include <vector>

typedef HRESULT(WINAPI* DI8Create)(HINSTANCE, DWORD, REFIID, LPVOID*, LPUNKNOWN);

HRESULT WINAPI DirectInput8Create(HINSTANCE h, DWORD v, REFIID r, LPVOID* o, LPUNKNOWN u) {
    static DI8Create fn = nullptr;
    if (!fn) {
        char sys[MAX_PATH];
        GetSystemDirectoryA(sys, MAX_PATH);
        std::string p = std::string(sys) + "\\dinput8.dll";
        HMODULE real = LoadLibraryA(p.c_str());
        if (real) fn = (DI8Create)GetProcAddress(real, "DirectInput8Create");
    }
    return fn ? fn(h, v, r, o, u) : E_FAIL;
}

static bool GameWindowReady() {
    if (!GetModuleHandleA("d3d11.dll") || !GetModuleHandleA("dxgi.dll")) return false;
    HWND w = nullptr;
    DWORD pid = GetCurrentProcessId();
    while ((w = FindWindowExA(nullptr, w, nullptr, nullptr)) != nullptr) {
        DWORD p = 0;
        GetWindowThreadProcessId(w, &p);
        if (p == pid && IsWindowVisible(w)) return true;
    }
    return false;
}

static DWORD WINAPI LoadMods(LPVOID self) {
    // ждём, пока игра сама создаст окно и загрузит d3d11 (до 60 с), потом ещё пауза
    for (int i = 0; i < 600 && !GameWindowReady(); ++i) Sleep(100);
    Sleep(3000);
    char path[MAX_PATH];
    GetModuleFileNameA((HMODULE)self, path, MAX_PATH);
    std::string dir = path;
    dir = dir.substr(0, dir.find_last_of("\\/") + 1) + "DSRMods\\";
    std::string log;
    std::vector<std::string> names;
    WIN32_FIND_DATAA fd;
    HANDLE h = FindFirstFileA((dir + "*.dll").c_str(), &fd);
    if (h != INVALID_HANDLE_VALUE) {
        do { names.push_back(fd.cFileName); } while (FindNextFileA(h, &fd));
        FindClose(h);
    }
    std::sort(names.begin(), names.end());  // предсказуемый порядок загрузки
    if (names.empty()) log += "В папке DSRMods нет DLL\r\n";
    // моды грузим по одному с паузой, чтобы хуки ставились строго последовательно
    for (auto& n : names) {
        Sleep(1500);
        if (LoadLibraryA((dir + n).c_str()))
            log += "OK   " + n + "\r\n";
        else
            log += "FAIL " + n + " (код ошибки " + std::to_string(GetLastError()) + ")\r\n";
    }
    HANDLE f = CreateFileA((dir + "loader.log").c_str(), GENERIC_WRITE, FILE_SHARE_READ, nullptr, CREATE_ALWAYS,
                           FILE_ATTRIBUTE_NORMAL, nullptr);
    if (f != INVALID_HANDLE_VALUE) {
        DWORD w;
        WriteFile(f, log.data(), (DWORD)log.size(), &w, nullptr);
        CloseHandle(f);
    }
    return 0;
}

BOOL APIENTRY DllMain(HMODULE m, DWORD reason, LPVOID) {
    if (reason == DLL_PROCESS_ATTACH) {
        DisableThreadLibraryCalls(m);
        CreateThread(nullptr, 0, LoadMods, m, 0, nullptr);
    }
    return TRUE;
}
