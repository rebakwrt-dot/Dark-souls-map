#define _CRT_SECURE_NO_WARNINGS
// DSRCombat: два боевых мода в одной DLL + оверлей-калибратор (calib.cpp, клавиша U).
//  1) Эстус на сдачу: если эстус выпит при HP >= порога (по умолчанию 90%),
//     флакон не тратится, а лечение остаётся.
//  2) Отмена замаха перекатом: пока замах не дошёл до хитбокса (окно в мс),
//     нажатие переката сразу прерывает удар. После окна (когда урон уже может
//     быть нанесён) отмена не работает, а стамина за перекат списывается.
// Адреса задаются цепочками указателей в DSRCombat.ini; их можно найти калибратором (U в игре).
// Пока цепочка пуста, соответствующая функция выключена.
#include <windows.h>

#include <algorithm>
#include <cstdio>
#include <cstring>
#include <deque>
#include <fstream>
#include <mutex>
#include <string>
#include <vector>

#include "../map/mem.h"
#include "combat.h"

namespace {

struct AttackRange {
    int lo, hi;
    float windowSec;
};

struct Cfg {
    Chain hp, maxHp, estus;                    // int32
    Chain animId, animReq, stamina;            // int32
    Chain animTime;                            // float, секунды с начала анимации
    bool estusOn = true, rollOn = true;
    float threshold = 0.90f;
    int snapshotMs = 300;
    int rollKey = VK_SPACE;
    int padMask = 0x2000;                      // кнопка B геймпада, 0 = выкл
    int rollClass = 0;                         // 0 лёгкий (700-703), 1 средний (710-713), 2 тяжёлый (720-723)
    int keyF = 'W', keyB = 'S', keyR = 'D', keyL = 'A';  // направление переката
    int staminaCost = 10;
    float defaultWindowSec = 0.15f;
    std::vector<AttackRange> attacks;          // необязательные свои окна по диапазонам ID
};

Cfg g;
std::mutex g_mx;
HMODULE g_self;
uintptr_t g_base;

template <class T>
bool WrAt(uintptr_t a, T v) {
    if (a < 0x10000) return false;
    __try {
        *reinterpret_cast<T*>(a) = v;
        return true;
    } __except (EXCEPTION_EXECUTE_HANDLER) {
        return false;
    }
}

template <class T>
bool WrChain(const Chain& c, T v) {
    uintptr_t a = 0;
    return Resolve(c, g_base, a) && WrAt<T>(a, v);
}

bool Focused() {
    DWORD pid = 0;
    GetWindowThreadProcessId(GetForegroundWindow(), &pid);
    return pid == GetCurrentProcessId();
}

Chain GetChain(const char* key, const std::string& ini) {
    char buf[512] = {};
    GetPrivateProfileStringA("offsets", key, "", buf, sizeof(buf), ini.c_str());
    return ParseChain(buf);
}

void LoadCfg() {
    std::string ini = CombatIniPath();
    if (GetFileAttributesA(ini.c_str()) == INVALID_FILE_ATTRIBUTES) {
        std::ofstream f(ini);
        f << "[estus]\n"
             "enabled=1\n"
             "; Порог HP, при котором эстус не тратится (0.90 = 90%)\n"
             "threshold=0.90\n"
             "; Окно (мс), за которое берётся минимум HP перед выпиванием\n"
             "snapshot_ms=300\n\n"
             "[roll_cancel]\n"
             "enabled=1\n"
             "; Клавиша переката (VK-код, 0x20 = Space) и маска кнопки геймпада (0x2000 = B)\n"
             "roll_key=0x20\n"
             "roll_pad_mask=0x2000\n"
             "; Тип переката по нагрузке: 0 лёгкий (700-703), 1 средний (710-713), 2 тяжёлый (720-723)\n"
             "roll_class=0\n"
             "; Клавиши направления (VK): W S D A. Вперёд=+0, назад=+1, вправо=+2, влево=+3\n"
             "key_forward=0x57\nkey_back=0x53\nkey_right=0x44\nkey_left=0x41\n"
             "; Стамина, списываемая за перекат\n"
             "stamina_cost=10\n"
             "; Окно (мс) от начала замаха; должно быть короче времени до первого хитбокса\n"
             "default_window_ms=150\n\n"
             "; Необязательно: свои окна для диапазонов ID, мин-макс=мс. Пример: 14000-14999=180\n"
             "; Атаки по умолчанию определяются по схеме ID вики (категория*10000 + рука + действие).\n"
             "[attack_anims]\n\n"
             "; Цепочки указателей. Проще всего заполнить калибратором (клавиша U в игре).\n"
             "; int32: hp, max_hp, estus, anim_id, anim_request, stamina. float: anim_time (сек).\n"
             "[offsets]\n"
             "hp=\n"
             "max_hp=\n"
             "estus=\n"
             "anim_id=\n"
             "anim_time=\n"
             "anim_request=\n"
             "stamina=\n";
    }
    const char* c = ini.c_str();
    Cfg n;
    n.estusOn = GetPrivateProfileIntA("estus", "enabled", 1, c) != 0;
    n.rollOn = GetPrivateProfileIntA("roll_cancel", "enabled", 1, c) != 0;
    n.snapshotMs = std::min(1000, std::max(50, (int)GetPrivateProfileIntA("estus", "snapshot_ms", 300, c)));

    char buf[64];
    GetPrivateProfileStringA("estus", "threshold", "0.90", buf, sizeof(buf), c);
    n.threshold = (float)atof(buf);

    char kb[32];
    GetPrivateProfileStringA("roll_cancel", "roll_key", "0x20", kb, sizeof(kb), c);
    n.rollKey = (int)strtol(kb, nullptr, 0);
    GetPrivateProfileStringA("roll_cancel", "roll_pad_mask", "0x2000", kb, sizeof(kb), c);
    n.padMask = (int)strtol(kb, nullptr, 0);
    n.rollClass = std::min(2, std::max(0, (int)GetPrivateProfileIntA("roll_cancel", "roll_class", 0, c)));
    GetPrivateProfileStringA("roll_cancel", "key_forward", "0x57", kb, sizeof(kb), c); n.keyF = (int)strtol(kb, nullptr, 0);
    GetPrivateProfileStringA("roll_cancel", "key_back", "0x53", kb, sizeof(kb), c); n.keyB = (int)strtol(kb, nullptr, 0);
    GetPrivateProfileStringA("roll_cancel", "key_right", "0x44", kb, sizeof(kb), c); n.keyR = (int)strtol(kb, nullptr, 0);
    GetPrivateProfileStringA("roll_cancel", "key_left", "0x41", kb, sizeof(kb), c); n.keyL = (int)strtol(kb, nullptr, 0);
    n.staminaCost = GetPrivateProfileIntA("roll_cancel", "stamina_cost", 10, c);
    n.defaultWindowSec = std::min(400, std::max(20, (int)GetPrivateProfileIntA("roll_cancel", "default_window_ms", 150, c))) / 1000.0f;

    char sec[4096] = {};
    GetPrivateProfileSectionA("attack_anims", sec, sizeof(sec), c);
    for (const char* p = sec; *p; p += strlen(p) + 1) {
        int lo = 0, hi = 0, ms = 0;
        if (sscanf(p, "%d-%d=%d", &lo, &hi, &ms) == 3 && lo <= hi && ms >= 20 && ms <= 400) n.attacks.push_back({lo, hi, ms / 1000.0f});
    }

    // защита от некорректных значений
    n.snapshotMs = std::min(1000, std::max(50, n.snapshotMs));
    n.threshold = std::min(1.0f, std::max(0.5f, n.threshold));
    n.defaultWindowSec = std::min(0.5f, std::max(0.02f, n.defaultWindowSec));
    n.staminaCost = std::max(0, n.staminaCost);
    for (auto& a : n.attacks) {
        if (a.lo > a.hi) std::swap(a.lo, a.hi);
        a.windowSec = std::min(0.5f, a.windowSec);
    }

    n.hp = GetChain("hp", ini);
    n.maxHp = GetChain("max_hp", ini);
    n.estus = GetChain("estus", ini);
    n.animId = GetChain("anim_id", ini);
    n.animTime = GetChain("anim_time", ini);
    n.animReq = GetChain("anim_request", ini);
    n.stamina = GetChain("stamina", ini);

    std::lock_guard<std::mutex> l(g_mx);
    g = n;
}

// ---------- Эстус на сдачу ----------
struct Sample {
    ULONGLONG t;
    float ratio;
};
std::deque<Sample> g_hist;
int g_prevEstus = -1;

void EstusTick() {
    if (!g.estusOn || !g.hp.valid() || !g.maxHp.valid() || !g.estus.valid()) return;
    int32_t hp = 0, mx = 0, es = 0;
    if (!ReadChain(g.hp, g_base, hp) || !ReadChain(g.maxHp, g_base, mx) || !ReadChain(g.estus, g_base, es) ||
        mx <= 0) {
        g_prevEstus = -1;
        g_hist.clear();
        return;
    }
    ULONGLONG now = GetTickCount64();
    g_hist.push_back({now, (float)hp / (float)mx});
    while (!g_hist.empty() && now - g_hist.front().t > (ULONGLONG)g.snapshotMs) g_hist.pop_front();

    if (g_prevEstus > 0 && es == g_prevEstus - 1) {
        // минимум за окно: лечение могло уже пойти, но тогда минимум всё равно «до» него
        float minRatio = 1.0f;
        for (auto& s : g_hist) minRatio = std::min(minRatio, s.ratio);
        if (minRatio >= g.threshold && WrChain<int32_t>(g.estus, g_prevEstus)) es = g_prevEstus;
    }
    g_prevEstus = es;
}

// ---------- Отмена замаха перекатом ----------
typedef DWORD(WINAPI* XGetState)(DWORD, void*);
XGetState g_xinput = nullptr;
bool g_prevPress = false;
bool g_cancelled = false;
int g_lastAnim = -1;

bool RollPressed() {
    if (g.rollKey && (GetAsyncKeyState(g.rollKey) & 0x8000)) return true;
    if (g.padMask && g_xinput) {
        struct { DWORD packet; WORD buttons; BYTE lt, rt; SHORT lx, ly, rx, ry; } st = {};
        if (g_xinput(0, &st) == 0 && (st.buttons & g.padMask)) return true;
    }
    return false;
}

// Схема ID анимаций атак (вики soulsmodding, DS1): категория*10000 + рука + действие.
// Рука: 3000 правая, 4000 обе, 5000 левая. Действия-атаки: 0,1,2 (быстрые), 300,301,310 (сильные),
// 500 (бег), 600/640 (прыжок), 900 (после переката). +5 = оружие на нуле прочности.
bool IsAttackBySchema(int id) {
    int base = id % 10000;
    int hand = base / 1000;
    if (hand < 3 || hand > 5) return false;
    int act = base % 1000;
    if (act % 10 == 5) act -= 5;
    switch (act) {
        case 0: case 1: case 2: case 300: case 301: case 310: case 500: case 600: case 640: case 900:
            return true;
    }
    return false;
}

// возвращает окно в секундах или <0, если это не атака
float AttackWindow(int id) {
    for (auto& a : g.attacks)
        if (id >= a.lo && id <= a.hi) return a.windowSec > 0 ? a.windowSec : g.defaultWindowSec;
    return IsAttackBySchema(id) ? g.defaultWindowSec : -1.0f;
}

// Выбор анимации переката: 700+класс*10, смещение по направлению ввода (0 вперёд, 1 назад, 2 вправо, 3 влево).
int PickRollAnim() {
    bool f = GetAsyncKeyState(g.keyF) & 0x8000, b = GetAsyncKeyState(g.keyB) & 0x8000;
    bool r = GetAsyncKeyState(g.keyR) & 0x8000, l = GetAsyncKeyState(g.keyL) & 0x8000;
    int dir = 0;
    if (g_xinput) {
        struct { DWORD packet; WORD buttons; BYTE lt, rt; SHORT lx, ly, rx, ry; } st = {};
        if (g_xinput(0, &st) == 0) {
            if (st.ly > 12000) f = true;
            if (st.ly < -12000) b = true;
            if (st.lx > 12000) r = true;
            if (st.lx < -12000) l = true;
        }
    }
    if (b && !f) dir = 1;
    else if (r && !l && !f) dir = 2;
    else if (l && !r && !f) dir = 3;
    else if (!f && !b && !r && !l) dir = 1;  // без направления: назад
    return 700 + g.rollClass * 10 + dir;
}

void RollTick() {
    if (!g.rollOn || !g.animId.valid() || !g.animTime.valid() || !g.animReq.valid()) return;

    bool press = RollPressed();
    bool edge = press && !g_prevPress;
    g_prevPress = press;

    int32_t id = 0;
    float t = 0;
    if (!ReadChain(g.animId, g_base, id) || !ReadChain(g.animTime, g_base, t)) return;
    if (id != g_lastAnim) {
        g_lastAnim = id;
        g_cancelled = false;
    }
    if (!edge || g_cancelled) return;

    float window = AttackWindow(id);
    if (window < 0) return;
    if (t < 0 || t > window) return;  // хитбокс уже мог начаться, отмена запрещена

    // стамину платим всегда, без неё перекат не даём
    if (g.stamina.valid()) {
        int32_t st = 0;
        if (!ReadChain(g.stamina, g_base, st) || st < g.staminaCost) return;
        WrChain<int32_t>(g.stamina, st - g.staminaCost);
    }
    if (WrChain<int32_t>(g.animReq, PickRollAnim())) g_cancelled = true;
}

DWORD WINAPI Run(LPVOID) {
    g_base = (uintptr_t)GetModuleHandleA(nullptr);
    LoadCfg();
    CalibStart(g_self);
    CoopStart();
    HMODULE x = LoadLibraryA("xinput1_4.dll");
    if (!x) x = LoadLibraryA("xinput9_1_0.dll");
    if (x) g_xinput = (XGetState)GetProcAddress(x, "XInputGetState");
    while (true) {
        Sleep(4);
        std::lock_guard<std::mutex> l(g_mx);
        EstusTick();
        if (Focused()) RollTick();
    }
    return 0;
}

}  // namespace

std::string CombatIniPath() {
    char p[MAX_PATH];
    GetModuleFileNameA(g_self, p, MAX_PATH);
    std::string s = p;
    return s.substr(0, s.find_last_of("\\/") + 1) + "DSRCombat.ini";
}

void CombatReloadCfg() { LoadCfg(); CoopReloadCfg(); }

BOOL APIENTRY DllMain(HMODULE m, DWORD reason, LPVOID) {
    if (reason == DLL_PROCESS_ATTACH) {
        g_self = m;
        DisableThreadLibraryCalls(m);
        CreateThread(nullptr, 0, Run, nullptr, 0, nullptr);
    }
    return TRUE;
}
