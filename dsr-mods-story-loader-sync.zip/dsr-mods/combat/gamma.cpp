#define _CRT_SECURE_NO_WARNINGS
// Гамма-коррекция поверх кадра (для тёмных локаций). Клавиши Num+ / Num- (меняются в [gamma]).
#include <windows.h>
#include <d3d11.h>
#include <d3dcompiler.h>
#include <dxgi.h>

#include <algorithm>
#include <cmath>
#include <cstdio>
#include <string>

#include "imgui.h"
#include "combat.h"

namespace {
const char* kShader = R"(
Texture2D src : register(t0);
SamplerState smp : register(s0);
cbuffer cb : register(b0) { float invG; float3 pad; };
struct VO { float4 p : SV_Position; float2 uv : TEXCOORD0; };
VO vs(uint id : SV_VertexID) {
    VO o; float2 uv = float2((id << 1) & 2, id & 2);
    o.uv = uv; o.p = float4(uv * float2(2, -2) + float2(-1, 1), 0, 1); return o;
}
float4 ps(VO i) : SV_Target {
    float4 c = src.Sample(smp, i.uv);
    c.rgb = pow(max(c.rgb, 0.0), invG);
    return c;
}
)";

float g_gamma = 1.0f;
bool g_loaded = false, g_dirty = false, g_ready = false, g_failed = false;
int g_keyUp = VK_ADD, g_keyDown = VK_SUBTRACT;
ULONGLONG g_lastChange = 0;

ID3D11VertexShader* g_vs;
ID3D11PixelShader* g_ps;
ID3D11SamplerState* g_smp;
ID3D11Buffer* g_cb;
ID3D11BlendState* g_bs;
ID3D11RasterizerState* g_rs;
ID3D11DepthStencilState* g_ds;
ID3D11Texture2D* g_tex;
ID3D11ShaderResourceView* g_srv;
UINT g_w, g_h;
DXGI_FORMAT g_fmt;

void Load() {
    g_loaded = true;
    std::string ini = CombatIniPath();
    char b[64];
    GetPrivateProfileStringA("gamma", "value", "1.0", b, sizeof(b), ini.c_str());
    g_gamma = std::min(3.0f, std::max(0.5f, (float)atof(b)));
    GetPrivateProfileStringA("gamma", "key_up", "0x6B", b, sizeof(b), ini.c_str());
    g_keyUp = (int)strtol(b, nullptr, 0);
    GetPrivateProfileStringA("gamma", "key_down", "0x6D", b, sizeof(b), ini.c_str());
    g_keyDown = (int)strtol(b, nullptr, 0);
}

void Save() {
    char b[32];
    snprintf(b, sizeof(b), "%.2f", g_gamma);
    WritePrivateProfileStringA("gamma", "value", b, CombatIniPath().c_str());
    g_dirty = false;
}

DXGI_FORMAT Typed(DXGI_FORMAT f) {
    switch (f) {
        case DXGI_FORMAT_R8G8B8A8_TYPELESS: return DXGI_FORMAT_R8G8B8A8_UNORM;
        case DXGI_FORMAT_B8G8R8A8_TYPELESS: return DXGI_FORMAT_B8G8R8A8_UNORM;
        case DXGI_FORMAT_R10G10B10A2_TYPELESS: return DXGI_FORMAT_R10G10B10A2_UNORM;
        default: return f;
    }
}

bool Init(ID3D11Device* d) {
    ID3DBlob *vb = nullptr, *pb = nullptr, *err = nullptr;
    if (FAILED(D3DCompile(kShader, strlen(kShader), nullptr, nullptr, nullptr, "vs", "vs_4_0", 0, 0, &vb, &err))) return false;
    if (FAILED(D3DCompile(kShader, strlen(kShader), nullptr, nullptr, nullptr, "ps", "ps_4_0", 0, 0, &pb, &err))) return false;
    d->CreateVertexShader(vb->GetBufferPointer(), vb->GetBufferSize(), nullptr, &g_vs);
    d->CreatePixelShader(pb->GetBufferPointer(), pb->GetBufferSize(), nullptr, &g_ps);
    vb->Release();
    pb->Release();
    D3D11_SAMPLER_DESC sd{};
    sd.Filter = D3D11_FILTER_MIN_MAG_MIP_POINT;
    sd.AddressU = sd.AddressV = sd.AddressW = D3D11_TEXTURE_ADDRESS_CLAMP;
    d->CreateSamplerState(&sd, &g_smp);
    D3D11_BUFFER_DESC bd{};
    bd.ByteWidth = 16;
    bd.Usage = D3D11_USAGE_DEFAULT;
    bd.BindFlags = D3D11_BIND_CONSTANT_BUFFER;
    d->CreateBuffer(&bd, nullptr, &g_cb);
    D3D11_BLEND_DESC bl{};
    bl.RenderTarget[0].RenderTargetWriteMask = D3D11_COLOR_WRITE_ENABLE_ALL;
    d->CreateBlendState(&bl, &g_bs);
    D3D11_RASTERIZER_DESC rd{};
    rd.FillMode = D3D11_FILL_SOLID;
    rd.CullMode = D3D11_CULL_NONE;
    rd.DepthClipEnable = TRUE;
    d->CreateRasterizerState(&rd, &g_rs);
    D3D11_DEPTH_STENCIL_DESC dd{};
    d->CreateDepthStencilState(&dd, &g_ds);
    return g_vs && g_ps && g_smp && g_cb && g_bs && g_rs && g_ds;
}

void Draw(IDXGISwapChain* sc) {
    ID3D11Device* dev = nullptr;
    if (FAILED(sc->GetDevice(__uuidof(ID3D11Device), (void**)&dev))) return;
    ID3D11DeviceContext* ctx = nullptr;
    dev->GetImmediateContext(&ctx);
    if (!g_ready && !g_failed) {
        g_ready = Init(dev);
        g_failed = !g_ready;
    }
    ID3D11Texture2D* bb = nullptr;
    if (g_ready && SUCCEEDED(sc->GetBuffer(0, __uuidof(ID3D11Texture2D), (void**)&bb))) {
        D3D11_TEXTURE2D_DESC td;
        bb->GetDesc(&td);
        if (td.SampleDesc.Count == 1) {
            DXGI_FORMAT f = Typed(td.Format);
            if (!g_tex || g_w != td.Width || g_h != td.Height || g_fmt != td.Format) {
                if (g_srv) { g_srv->Release(); g_srv = nullptr; }
                if (g_tex) { g_tex->Release(); g_tex = nullptr; }
                D3D11_TEXTURE2D_DESC n = td;
                n.Format = f;
                n.BindFlags = D3D11_BIND_SHADER_RESOURCE;
                n.MiscFlags = 0;
                n.Usage = D3D11_USAGE_DEFAULT;
                n.CPUAccessFlags = 0;
                if (SUCCEEDED(dev->CreateTexture2D(&n, nullptr, &g_tex))) {
                    dev->CreateShaderResourceView(g_tex, nullptr, &g_srv);
                    g_w = td.Width; g_h = td.Height; g_fmt = td.Format;
                }
            }
            D3D11_RENDER_TARGET_VIEW_DESC rv{};
            rv.Format = f;
            rv.ViewDimension = D3D11_RTV_DIMENSION_TEXTURE2D;
            ID3D11RenderTargetView* rtv = nullptr;
            if (g_srv && SUCCEEDED(dev->CreateRenderTargetView(bb, &rv, &rtv))) {
                if (f == td.Format) ctx->CopyResource(g_tex, bb);
                else ctx->CopySubresourceRegion(g_tex, 0, 0, 0, 0, bb, 0, nullptr);
                // сохраняем состояние конвейера
                ID3D11RenderTargetView* oRtv[1] = {};
                ID3D11DepthStencilView* oDsv = nullptr;
                ctx->OMGetRenderTargets(1, oRtv, &oDsv);
                UINT nvp = 1;
                D3D11_VIEWPORT oVp{};
                ctx->RSGetViewports(&nvp, &oVp);
                ID3D11VertexShader* oVs; ID3D11PixelShader* oPs;
                ctx->VSGetShader(&oVs, nullptr, nullptr);
                ctx->PSGetShader(&oPs, nullptr, nullptr);
                ID3D11ShaderResourceView* oSrv = nullptr;
                ctx->PSGetShaderResources(0, 1, &oSrv);
                ID3D11SamplerState* oSmp = nullptr;
                ctx->PSGetSamplers(0, 1, &oSmp);
                ID3D11Buffer* oCb = nullptr;
                ctx->PSGetConstantBuffers(0, 1, &oCb);
                ID3D11InputLayout* oIl = nullptr;
                ctx->IAGetInputLayout(&oIl);
                D3D11_PRIMITIVE_TOPOLOGY oTop;
                ctx->IAGetPrimitiveTopology(&oTop);
                ID3D11BlendState* oBs; float oBf[4]; UINT oMask;
                ctx->OMGetBlendState(&oBs, oBf, &oMask);
                ID3D11DepthStencilState* oDs; UINT oRef;
                ctx->OMGetDepthStencilState(&oDs, &oRef);
                ID3D11RasterizerState* oRs = nullptr;
                ctx->RSGetState(&oRs);

                float cbv[4] = {1.0f / g_gamma, 0, 0, 0};
                ctx->UpdateSubresource(g_cb, 0, nullptr, cbv, 0, 0);
                D3D11_VIEWPORT vp{0, 0, (float)td.Width, (float)td.Height, 0, 1};
                ctx->OMSetRenderTargets(1, &rtv, nullptr);
                ctx->RSSetViewports(1, &vp);
                ctx->RSSetState(g_rs);
                ctx->OMSetBlendState(g_bs, nullptr, 0xFFFFFFFF);
                ctx->OMSetDepthStencilState(g_ds, 0);
                ctx->IASetInputLayout(nullptr);
                ctx->IASetPrimitiveTopology(D3D11_PRIMITIVE_TOPOLOGY_TRIANGLELIST);
                ctx->VSSetShader(g_vs, nullptr, 0);
                ctx->PSSetShader(g_ps, nullptr, 0);
                ctx->PSSetShaderResources(0, 1, &g_srv);
                ctx->PSSetSamplers(0, 1, &g_smp);
                ctx->PSSetConstantBuffers(0, 1, &g_cb);
                ctx->Draw(3, 0);
                ID3D11ShaderResourceView* nullSrv = nullptr;
                ctx->PSSetShaderResources(0, 1, &nullSrv);

                // восстановление
                ctx->OMSetRenderTargets(1, oRtv, oDsv);
                ctx->RSSetViewports(1, &oVp);
                ctx->VSSetShader(oVs, nullptr, 0);
                ctx->PSSetShader(oPs, nullptr, 0);
                ctx->PSSetShaderResources(0, 1, &oSrv);
                ctx->PSSetSamplers(0, 1, &oSmp);
                ctx->PSSetConstantBuffers(0, 1, &oCb);
                ctx->IASetInputLayout(oIl);
                ctx->IASetPrimitiveTopology(oTop);
                ctx->OMSetBlendState(oBs, oBf, oMask);
                ctx->OMSetDepthStencilState(oDs, oRef);
                ctx->RSSetState(oRs);
                if (oRtv[0]) oRtv[0]->Release();
                if (oDsv) oDsv->Release();
                if (oVs) oVs->Release();
                if (oPs) oPs->Release();
                if (oSrv) oSrv->Release();
                if (oSmp) oSmp->Release();
                if (oCb) oCb->Release();
                if (oIl) oIl->Release();
                if (oBs) oBs->Release();
                if (oDs) oDs->Release();
                if (oRs) oRs->Release();
                rtv->Release();
            }
        }
        bb->Release();
    }
    ctx->Release();
    dev->Release();
}
}  // namespace

void GammaApply(IDXGISwapChain* sc) {
    if (!g_loaded) Load();
    DWORD pid = 0;
    GetWindowThreadProcessId(GetForegroundWindow(), &pid);
    if (pid == GetCurrentProcessId()) {
        float d = 0;
        if (GetAsyncKeyState(g_keyUp) & 0x8000) d += 0.01f;
        if (GetAsyncKeyState(g_keyDown) & 0x8000) d -= 0.01f;
        if (d != 0) {
            g_gamma = std::min(3.0f, std::max(0.5f, g_gamma + d));
            g_dirty = true;
            g_lastChange = GetTickCount64();
        }
    }
    if (g_dirty && GetTickCount64() - g_lastChange > 1000) Save();
    if (std::fabs(g_gamma - 1.0f) < 0.005f || g_failed) return;
    Draw(sc);
}

void GammaUI() {
    ImGui::Separator();
    if (ImGui::SliderFloat("Гамма (Num+ / Num-)", &g_gamma, 0.5f, 3.0f, "%.2f")) {
        g_dirty = true;
        g_lastChange = GetTickCount64();
    }
    if (ImGui::SmallButton("Сброс гаммы")) { g_gamma = 1.0f; g_dirty = true; g_lastChange = GetTickCount64(); }
    if (g_failed) ImGui::TextColored(ImVec4(1, 0.4f, 0.4f, 1), "Шейдер гаммы не создан");
}
