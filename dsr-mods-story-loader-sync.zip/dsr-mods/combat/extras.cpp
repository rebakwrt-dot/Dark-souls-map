#define _CRT_SECURE_NO_WARNINGS
// DSRCombat / extras.cpp: сюжетные роли кооператива и личные твики.
//
// Сюжет: игрок 1 (хост) — «человек», игрок 2 (клиент) — красный фантом, скованный с ним цепью.
//  * Человечность: оба всегда люди (флаг «полый» принудительно сбрасывается), количество человечности можно терять.
//  * Стамина: у фантома максимум = 50% от обычного; 50% стамины, потраченной одним, списывается и у второго (в обе стороны).
//  * Человек: +30 защиты от всех типов урона, пока укрывается щитом; успешное парри -> +50% к восстановлению стамины на 10 с
//    (вместо +20% урона).
//  * Фантом: +25% урона от стихий, -25% урона от физики.
// Все адреса — цепочки в DSRCombat.ini [offsets]; без них соответствующая функция молча выключена.
#include <windows.h>

#include <algorithm>
#include <atomic>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <map>
#include <string>
#include <utility>
#include <vector>

#include "imgui.h"
#include "../map/mem.h"
#include "combat.h"

namespace {

typedef std::pair<int, int> Range;

struct SCfg {
    bool story = false;
    // цепочки
    Chain stam, maxStam, hp, animId, animTime, animReq, parrySucc, human, dmgPhys, dmgElem;
    Chain def[4];  // физ, магия, огонь, молния
    bool stamFloat = false, defFloat = false;
    // сюжет
    float phantomStam = 0.5f, mirror = 0.5f;
    float shieldBonus = 30.0f;
    std::vector<Range> guardAnims;
    float parryRegen = 0.5f, parrySec = 10.0f;
    int humanVal = 0, hollowVal = 1;
    bool humanLock = true;
    float elemMul = 1.25f, physMul = 0.75f;
    // роль
    float angleSign = 1.0f, angleOff = 0.0f;
    int rollClass = 0, rollCost = 10;
    // личные твики (читаются без создания ключей в ini)
    int keyToggle = VK_NUMPAD9, keyA = 'E', keyB = VK_SPACE;
    std::vector<Range> melee, ranged;
    std::vector<std::pair<Range, float>> hitSec;
    float defaultHit = 0.45f, rangeM = 3.5f, rollLead = 0.13f, parryLead = 0.20f, cooldown = 24.0f / 30.0f;
    int parryAnim = 0, parriedAnim = 0;
};

SCfg k;
uintptr_t g_base = 0;
std::atomic<float> g_spent{0.0f};
std::atomic<bool> g_noDmgBuff{false};
bool g_loaded = false;

template <class T>
bool WrAt(uintptr_t a, T v) {
    if (a < 0x10000) return false;
    __try {
        *reinterpret_cast<T*>(a) = v;
        return true;
    } __except (EXCEPTION_EXECUTE_HANDLER) {
        return false;
    }
}

// число с плавающей запятой / int32 по флагу
bool RdNum(const Chain& c, bool isFloat, float& out) {
    uintptr_t a = 0;
    if (!Resolve(c, g_base, a)) return false;
    if (isFloat) return Rd(a, out) && std::isfinite(out);
    int32_t v = 0;
    if (!Rd(a, v)) return false;
    out = (float)v;
    return true;
}
bool WrNum(const Chain& c, bool isFloat, float v) {
    uintptr_t a = 0;
    if (!Resolve(c, g_base, a)) return false;
    return isFloat ? WrAt<float>(a, v) : WrAt<int32_t>(a, (int32_t)std::lround(v));
}

std::string Ini() { return CombatIniPath(); }

std::string IniStr(const char* sec, const char* key, const char* def, bool create) {
    char b[512] = {};
    std::string ini = Ini();
    GetPrivateProfileStringA(sec, key, "\x01", b, sizeof(b), ini.c_str());
    if (b[0] == '\x01') {
        if (create) WritePrivateProfileStringA(sec, key, def, ini.c_str());
        return def;
    }
    return b;
}
float IniF(const char* sec, const char* key, float def, bool create = true) {
    char d[32];
    snprintf(d, sizeof(d), "%g", def);
    return (float)atof(IniStr(sec, key, d, create).c_str());
}
Chain GetCh(const char* key, bool create = true) {
    char b[512] = {};
    std::string ini = Ini();
    GetPrivateProfileStringA("offsets", key, "\x01", b, sizeof(b), ini.c_str());
    if (b[0] == '\x01') {
        if (create) WritePrivateProfileStringA("offsets", key, "", ini.c_str());
        return Chain();
    }
    return ParseChain(b);
}
std::vector<Range> ParseRanges(const std::string& s) {
    std::vector<Range> r;
    for (size_t i = 0; i < s.size();) {
        size_t j = s.find(',', i);
        if (j == std::string::npos) j = s.size();
        int lo = 0, hi = 0;
        std::string t = s.substr(i, j - i);
        if (sscanf(t.c_str(), "%d-%d", &lo, &hi) == 2) r.push_back({lo, hi});
        else if (sscanf(t.c_str(), "%d", &lo) == 1) r.push_back({lo, lo});
        i = j + 1;
    }
    return r;
}
bool In(const std::vector<Range>& r, int id) {
    for (auto& x : r)
        if (id >= x.first && id <= x.second) return true;
    return false;
}

void LoadCfg() {
    SCfg n;
    n.story = IniStr("story", "enabled", "0", true) != "0";
    n.stam = GetCh("stamina");
    n.maxStam = GetCh("max_stamina");
    n.hp = GetCh("hp");
    n.animId = GetCh("anim_id");
    n.animTime = GetCh("anim_time");
    n.animReq = GetCh("anim_request");
    n.parrySucc = GetCh("parry_success");
    n.human = GetCh("human_state");
    n.dmgPhys = GetCh("last_dmg_phys");
    n.dmgElem = GetCh("last_dmg_elem");
    const char* dn[4] = {"def_phys", "def_magic", "def_fire", "def_lightning"};
    for (int i = 0; i < 4; ++i) n.def[i] = GetCh(dn[i]);
    n.stamFloat = IniStr("story", "stamina_type", "int", true) == "float";
    n.defFloat = IniStr("story", "def_type", "int", true) == "float";
    n.phantomStam = std::min(1.0f, std::max(0.1f, IniF("story", "phantom_stamina_ratio", 0.5f)));
    n.mirror = std::min(1.0f, std::max(0.0f, IniF("story", "stamina_mirror", 0.5f)));
    n.shieldBonus = IniF("story", "shield_def_bonus", 30.0f);
    n.guardAnims = ParseRanges(IniStr("story", "guard_anims", "", true));
    n.parryRegen = IniF("story", "parry_stamina_regen", 0.5f);
    n.parrySec = IniF("story", "parry_stamina_seconds", 10.0f);
    n.humanVal = (int)IniF("story", "human_value", 0);
    n.hollowVal = (int)IniF("story", "hollow_value", 1);
    n.humanLock = IniStr("story", "always_human", "1", true) != "0";
    n.elemMul = IniF("story", "phantom_elem_taken", 1.25f);
    n.physMul = IniF("story", "phantom_phys_taken", 0.75f);
    n.angleSign = IniF("coop", "angle_sign", 1.0f, false);
    n.angleOff = IniF("coop", "angle_offset", 0.0f, false);
    n.rollClass = std::min(2, std::max(0, (int)IniF("roll_cancel", "roll_class", 0, false)));
    n.rollCost = (int)IniF("roll_cancel", "stamina_cost", 10, false);

    // личные твики: ключи в ini не создаются
    n.keyToggle = (int)strtol(IniStr("x", "toggle_key", "0x69", false).c_str(), nullptr, 0);
    n.keyA = (int)strtol(IniStr("x", "hold_key1", "0x45", false).c_str(), nullptr, 0);
    n.keyB = (int)strtol(IniStr("x", "hold_key2", "0x20", false).c_str(), nullptr, 0);
    n.melee = ParseRanges(IniStr("x", "melee", "3000-3999", false));
    n.ranged = ParseRanges(IniStr("x", "ranged", "", false));
    n.defaultHit = IniF("x", "default_hit_ms", 450, false) / 1000.0f;
    n.rangeM = IniF("x", "range_m", 3.5f, false);
    n.rollLead = IniF("x", "roll_lead_ms", 130, false) / 1000.0f;
    n.parryLead = IniF("x", "parry_lead_ms", 200, false) / 1000.0f;
    n.cooldown = IniF("x", "roll_frames_total", 24, false) / 30.0f;
    n.parryAnim = (int)IniF("x", "parry_anim", 0, false);
    n.parriedAnim = (int)IniF("x", "enemy_parried_anim", 0, false);
    char sec[2048] = {};
    GetPrivateProfileSectionA("x_hits", sec, sizeof(sec), Ini().c_str());  // 3000-3010=380 (мс до хитбокса)
    for (const char* p = sec; *p; p += strlen(p) + 1) {
        int lo = 0, hi = 0, ms = 0;
        if (sscanf(p, "%d-%d=%d", &lo, &hi, &ms) == 3) n.hitSec.push_back({{lo, hi}, ms / 1000.0f});
    }
    k = n;
    g_loaded = true;
}

bool Focused() {
    DWORD pid = 0;
    GetWindowThreadProcessId(GetForegroundWindow(), &pid);
    return pid == GetCurrentProcessId();
}

// ---------- состояние ----------
bool Phantom() { return CoopEnabled() && !CoopIsHost(); }

// --- стамина
float g_prevStam = -1, g_origMax = 0, g_setMax = 0, g_lastPeerSpent = -1;
ULONGLONG g_regenUntil = 0;
int32_t g_lastParry = 0;
bool g_parryValid = false;

void StaminaTick(ULONGLONG now) {
    if (!k.stam.valid()) { g_prevStam = -1; return; }
    float cur;
    if (!RdNum(k.stam, k.stamFloat, cur)) { g_prevStam = -1; return; }

    // максимум стамины фантома
    if (k.maxStam.valid()) {
        float mx;
        if (RdNum(k.maxStam, k.stamFloat, mx) && mx > 0) {
            bool ph = k.story && Phantom();
            if (std::fabs(mx - g_setMax) > 0.5f) g_origMax = mx;  // значение изменил не мы (уровень, снаряжение)
            if (ph && g_origMax > 0) {
                float want = std::floor(g_origMax * k.phantomStam);
                if (std::fabs(mx - want) > 0.5f) WrNum(k.maxStam, k.stamFloat, want);
                g_setMax = want;
                if (cur > want) { cur = want; WrNum(k.stam, k.stamFloat, cur); }
            } else if (g_setMax > 0 && g_origMax > 0) {  // роль сменилась / режим выключен: вернуть как было
                WrNum(k.maxStam, k.stamFloat, g_origMax);
                g_setMax = 0;
            }
        }
    }

    if (g_prevStam < 0) { g_prevStam = cur; return; }
    float written = cur;
    // самостоятельная трата (без нашей зеркальной части: prev уже учитывает наши записи)
    float drop = g_prevStam - cur;
    if (drop > 0.01f) g_spent = g_spent + drop;
    // восстановление: бонус после парри (человек)
    float up = cur - g_prevStam;
    if (up > 0.01f && now < g_regenUntil) {
        written = cur + up * k.parryRegen;
        if (k.maxStam.valid()) {
            float mx;
            if (RdNum(k.maxStam, k.stamFloat, mx) && mx > 0) written = std::min(written, mx);
        }
    }
    // зеркальная трата напарника
    if (CoopEnabled() && k.story) {
        PeerView pe;
        if (CoopPeerView(pe)) {
            float d = pe.spent - g_lastPeerSpent;
            if (g_lastPeerSpent < 0 || d < 0 || d > 2000.0f) d = 0;  // первый пакет / переподключение
            g_lastPeerSpent = pe.spent;
            if (d > 0) written = std::max(0.0f, written - d * k.mirror);
        } else {
            g_lastPeerSpent = -1;
        }
    }
    if (std::fabs(written - cur) > 0.001f) WrNum(k.stam, k.stamFloat, written);
    g_prevStam = written;
}

// --- парри человека: бафф восстановления стамины
void ParryTick(ULONGLONG now) {
    bool human = !Phantom();
    g_noDmgBuff = k.story && human;
    if (!k.parrySucc.valid()) return;
    int32_t s = 0;
    if (!ReadChain(k.parrySucc, g_base, s)) return;
    if (g_parryValid && s != g_lastParry && s != 0 && k.story && human) g_regenUntil = now + (ULONGLONG)(k.parrySec * 1000);
    g_lastParry = s;
    g_parryValid = true;
}

// --- щит: +защита, пока укрывается
bool g_guardOn = false;
float g_defOrig[4] = {}, g_defBuf[4] = {};

void GuardTick() {
    if (k.guardAnims.empty() || !k.animId.valid()) return;
    int32_t id = 0;
    if (!ReadChain(k.animId, g_base, id)) return;
    bool want = k.story && !Phantom() && In(k.guardAnims, id);
    if (want && !g_guardOn) {
        for (int i = 0; i < 4; ++i) {
            float v;
            g_defOrig[i] = g_defBuf[i] = 0;
            if (k.def[i].valid() && RdNum(k.def[i], k.defFloat, v)) {
                g_defOrig[i] = v;
                g_defBuf[i] = v + k.shieldBonus;
                WrNum(k.def[i], k.defFloat, g_defBuf[i]);
            }
        }
        g_guardOn = true;
    } else if (g_guardOn && want) {  // игра могла перезаписать значения
        for (int i = 0; i < 4; ++i) {
            float v;
            if (g_defBuf[i] > 0 && RdNum(k.def[i], k.defFloat, v) && std::fabs(v - g_defBuf[i]) > 0.5f && std::fabs(v - g_defOrig[i]) < 0.5f)
                WrNum(k.def[i], k.defFloat, g_defBuf[i]);
        }
    } else if (g_guardOn && !want) {
        for (int i = 0; i < 4; ++i) {
            float v;
            if (g_defBuf[i] > 0 && RdNum(k.def[i], k.defFloat, v) && std::fabs(v - g_defBuf[i]) < 0.5f) WrNum(k.def[i], k.defFloat, g_defOrig[i]);
        }
        g_guardOn = false;
    }
}

// --- урон фантому: стихии +25%, физика -25%
int32_t g_prevHp = -1;

void DamageTick() {
    if (!k.story || !k.hp.valid()) { g_prevHp = -1; return; }
    int32_t hp = 0;
    if (!ReadChain(k.hp, g_base, hp)) { g_prevHp = -1; return; }
    if (g_prevHp >= 0 && hp < g_prevHp && Phantom() && k.dmgPhys.valid() && k.dmgElem.valid()) {
        float ph = 0, el = 0;
        if (ReadChain(k.dmgPhys, g_base, ph) && ReadChain(k.dmgElem, g_base, el) && ph >= 0 && el >= 0 && ph + el > 0.01f) {
            float share = ph / (ph + el);
            float mul = share * k.physMul + (1.0f - share) * k.elemMul;
            int32_t drop = g_prevHp - hp;
            int32_t want = g_prevHp - (int32_t)std::lround(drop * mul);
            if (want != hp && want > 0) {
                uintptr_t a = 0;
                if (Resolve(k.hp, g_base, a) && WrAt<int32_t>(a, want)) hp = want;
            }
        }
    }
    g_prevHp = hp;
}

// --- человечность: никогда не «полый»
void HumanTick() {
    if (!k.story || !k.humanLock || !k.human.valid()) return;
    int32_t v = 0;
    if (!ReadChain(k.human, g_base, v)) return;
    if (v == k.hollowVal) {
        uintptr_t a = 0;
        if (Resolve(k.human, g_base, a)) WrAt<int32_t>(a, k.humanVal);
    }
}

// ---------- личные твики ----------
bool g_toggle = false, g_prevToggle = false;
ULONGLONG g_rollBlockUntil = 0, g_parryBlockUntil = 0;
struct Mark {
    int32_t anim;
    float t;
};
std::map<uintptr_t, Mark> g_done;  // враг -> анимация, на которую уже отреагировали
struct Sched {
    uintptr_t ptr;
    ULONGLONG at;
};
std::vector<Sched> g_sched;

float HitTime(int anim) {
    for (auto& h : k.hitSec)
        if (anim >= h.first.first && anim <= h.first.second) return h.second;
    return k.defaultHit;
}

void CombatExtras(ULONGLONG now) {
    if (!Focused() || !k.animId.valid() || !k.animReq.valid()) return;
    bool tg = (GetAsyncKeyState(k.keyToggle) & 0x8000) != 0;
    if (tg && !g_prevToggle) {
        g_toggle = !g_toggle;
        MessageBeep(g_toggle ? MB_OK : MB_ICONASTERISK);
    }
    g_prevToggle = tg;
    bool holdParry = k.parryAnim > 0 && (GetAsyncKeyState(k.keyA) & 0x8000) && (GetAsyncKeyState(k.keyB) & 0x8000);

    // отложенные «оглушения» после парри
    if (k.parriedAnim > 0)
        for (size_t i = 0; i < g_sched.size();) {
            if (now >= g_sched[i].at) { WorldEnemyWriteAnim(g_sched[i].ptr, k.parriedAnim); g_sched.erase(g_sched.begin() + i); }
            else ++i;
        }
    if (!g_toggle && !holdParry) { g_done.clear(); return; }

    PeerView me;
    if (!CoopMyView(me)) return;
    std::vector<EnemyView> en;
    if (!WorldEnemies(en)) return;
    int32_t myAnim = 0;
    if (!ReadChain(k.animId, g_base, myAnim)) return;
    bool rolling = myAnim >= 700 && myAnim <= 729;

    for (auto& e : en) {
        if (e.anim < 0) continue;
        auto it = g_done.find(e.ptr);
        if (it != g_done.end() && it->second.anim == e.anim && e.animTime >= it->second.t) { it->second.t = e.animTime; continue; }
        if (!In(k.melee, e.anim) || In(k.ranged, e.anim)) continue;
        float dx = me.x - e.x, dz = me.z - e.z, d = std::hypot(dx, dz);
        if (d > k.rangeM || std::fabs(me.y - e.y) > 3.0f) continue;
        // враг должен быть повёрнут к нам (атака направлена на игрока)
        float fx = std::sin(e.ang * k.angleSign + k.angleOff), fz = std::cos(e.ang * k.angleSign + k.angleOff);
        if (d > 0.01f && (fx * dx + fz * dz) / d < 0.2f) continue;
        float hit = HitTime(e.anim);

        if (holdParry && now >= g_parryBlockUntil && e.animTime >= hit - k.parryLead && e.animTime <= hit) {
            uintptr_t a = 0;
            if (Resolve(k.animReq, g_base, a) && WrAt<int32_t>(a, k.parryAnim)) {
                g_parryBlockUntil = now + 500;
                g_done[e.ptr] = {e.anim, e.animTime};
                if (k.parriedAnim > 0) g_sched.push_back({e.ptr, now + (ULONGLONG)(k.parryLead * 1000)});
                return;
            }
        }
        if (g_toggle && !holdParry && !rolling && now >= g_rollBlockUntil && e.animTime >= hit - k.rollLead && e.animTime <= hit) {
            // стамина: перекат без неё не даём
            if (k.stam.valid()) {
                float st;
                if (!RdNum(k.stam, k.stamFloat, st) || st < (float)k.rollCost) continue;
                WrNum(k.stam, k.stamFloat, st - (float)k.rollCost);
            }
            // враг спереди -> перекат назад, враг сзади -> вперёд
            float mfx = std::sin(me.ang * k.angleSign + k.angleOff), mfz = std::cos(me.ang * k.angleSign + k.angleOff);
            bool enemyFront = d > 0.01f && (-(mfx * dx + mfz * dz)) / d > 0;
            int dir = enemyFront ? 1 : 0;
            uintptr_t a = 0;
            if (Resolve(k.animReq, g_base, a) && WrAt<int32_t>(a, 700 + k.rollClass * 10 + dir)) {
                g_rollBlockUntil = now + (ULONGLONG)(k.cooldown * 1000);  // 11 кадров неуязвимости + 13 восстановления
                g_done[e.ptr] = {e.anim, e.animTime};
                return;
            }
        }
    }
}

}  // namespace

void ExtrasReloadCfg() { LoadCfg(); }
float ExtrasSpent() { return g_spent; }
bool ExtrasNoDamageBuff() { return g_noDmgBuff; }

void ExtrasTick() {
    static ULONGLONG next = 0;
    ULONGLONG now = GetTickCount64();
    if (now < next) return;
    next = now + 4;
    if (!g_base) g_base = (uintptr_t)GetModuleHandleA(nullptr);
    if (!g_loaded) LoadCfg();
    StaminaTick(now);
    ParryTick(now);
    GuardTick();
    DamageTick();
    HumanTick();
    CombatExtras(now);
}

void ExtrasUI() {
    ImGui::Separator();
    ImGui::Text("Сюжет: человек / красный фантом ([story] в DSRCombat.ini)");
    ImGui::TextDisabled("Роль: %s. Включение: [story] enabled=1, нужны цепочки stamina, max_stamina, def_*, human_state, last_dmg_*.",
                        Phantom() ? "красный фантом (клиент)" : "человек (хост)");
}
