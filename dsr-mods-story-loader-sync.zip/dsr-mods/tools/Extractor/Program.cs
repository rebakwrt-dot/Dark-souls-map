// DSRExtract: читает карты Dark Souls Remastered (*.msb / *.msb.dcx) и создаёт markers.json
// для мода DSRMap: все враги и предметы (сундуки/трупы с лутом) на каждой карте.
//
// Использование:  DSRExtract.exe [папка_игры] [куда_сохранить_markers.json]
using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Numerics;
using System.Reflection;
using System.Text.Json;
using SoulsFormats;

static class Program
{
    static object Get(object o, string name)
    {
        var p = o.GetType().GetProperty(name, BindingFlags.Public | BindingFlags.Instance);
        return p?.GetValue(o);
    }

    static List<object> Entries(object container)
    {
        var res = new List<object>();
        if (container == null) return res;
        var m = container.GetType().GetMethod("GetEntries", BindingFlags.Public | BindingFlags.Instance, null, Type.EmptyTypes, null);
        if (m != null && m.Invoke(container, null) is IEnumerable en)
            foreach (var e in en) res.Add(e);
        return res;
    }

    static bool Pos(object o, out Vector3 v)
    {
        v = default;
        if (Get(o, "Position") is Vector3 p) { v = p; return true; }
        return false;
    }

    // DSRExtract.exe --tae <c0000.anibnd.dcx> [id_от-id_до] : события TAE (кадры при 30 fps) для подбора окна парри
    static int DumpTae(string path, string range)
    {
        long lo = long.MinValue, hi = long.MaxValue;
        if (!string.IsNullOrEmpty(range))
        {
            var pr = range.Split('-');
            lo = long.Parse(pr[0]); hi = pr.Length > 1 ? long.Parse(pr[1]) : lo;
        }
        var bnd = BND3.Read(path);
        foreach (var f in bnd.Files)
        {
            if (!f.Name.EndsWith(".tae", StringComparison.OrdinalIgnoreCase)) continue;
            TAE tae;
            try { tae = TAE.Read(f.Bytes); } catch { continue; }
            foreach (var anim in (IEnumerable)Get(tae, "Animations") ?? new object[0])
            {
                long id = Convert.ToInt64(Get(anim, "ID"));
                if (id < lo || id > hi) continue;
                Console.WriteLine($"anim {id}  ({Path.GetFileName(f.Name)})");
                foreach (var ev in ((IEnumerable)Get(anim, "Events") ?? new object[0]))
                {
                    double st = Convert.ToDouble(Get(ev, "StartTime")), en = Convert.ToDouble(Get(ev, "EndTime"));
                    Console.WriteLine($"   type {Get(ev, "Type")}  кадры {st * 30:0.#} - {en * 30:0.#}  (длина {(en - st) * 30:0.#})");
                }
            }
        }
        return 0;
    }

    static int Main(string[] args)
    {
        if (args.Length >= 2 && args[0] == "--tae") return DumpTae(args[1], args.Length > 2 ? args[2] : null);
        string root = args.Length > 0 ? args[0] : Directory.GetCurrentDirectory();
        string outPath = args.Length > 1 ? args[1] : Path.Combine(root, "markers.json");

        var files = Directory.EnumerateFiles(root, "*.msb*", SearchOption.AllDirectories)
            .Where(f => f.EndsWith(".msb", StringComparison.OrdinalIgnoreCase) ||
                        f.EndsWith(".msb.dcx", StringComparison.OrdinalIgnoreCase))
            .OrderBy(f => f).ToList();
        if (files.Count == 0)
        {
            Console.WriteLine("Файлы *.msb не найдены в: " + root);
            Console.WriteLine("Сначала распакуйте игру (например, UXM Selective Unpacker), затем укажите папку игры.");
            return 1;
        }

        var result = new SortedDictionary<string, List<Dictionary<string, object>>>();
        int ok = 0, fail = 0;
        foreach (var f in files)
        {
            string map = Path.GetFileName(f);
            map = map.Substring(0, map.IndexOf('.'));
            try
            {
                var msb = MSB1.Read(f);
                var list = new List<Dictionary<string, object>>();
                var parts = Entries(Get(msb, "Parts"));
                var byName = new Dictionary<string, object>();
                foreach (var p in parts)
                    if (Get(p, "Name") is string n) byName[n] = p;

                foreach (var p in parts)
                {
                    if (p.GetType().Name != "Enemy" || !Pos(p, out var v)) continue;
                    string model = Get(p, "ModelName") as string ?? "enemy";
                    list.Add(new() { ["type"] = "enemy", ["name"] = model, ["x"] = v.X, ["y"] = v.Y, ["z"] = v.Z });
                }

                foreach (var e in Entries(Get(msb, "Events")))
                {
                    if (e.GetType().Name != "Treasure") continue;
                    string partName = (Get(e, "TreasurePartName") ?? Get(e, "PartName")) as string;
                    if (partName == null || !byName.TryGetValue(partName, out var part) || !Pos(part, out var v)) continue;
                    list.Add(new() { ["type"] = "loot", ["name"] = Get(e, "Name") as string ?? "treasure", ["x"] = v.X, ["y"] = v.Y, ["z"] = v.Z });
                }

                result[map] = list;
                Console.WriteLine($"{map}: {list.Count(m => (string)m["type"] == "enemy")} врагов, {list.Count(m => (string)m["type"] == "loot")} предметов");
                ok++;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"{map}: ошибка ({ex.GetType().Name}: {ex.Message})");
                fail++;
            }
        }

        Directory.CreateDirectory(Path.GetDirectoryName(Path.GetFullPath(outPath)));
        File.WriteAllText(outPath, JsonSerializer.Serialize(result, new JsonSerializerOptions { WriteIndented = false }));
        Console.WriteLine($"\nГотово: карт {ok}, ошибок {fail}. Файл: {outPath}");
        return ok > 0 ? 0 : 1;
    }
}
