#pragma once
#include <windows.h>
#include <d3d11.h>
#include <dxgi.h>

// Общий хук DX11 через подмену записей в vtable. Несколько модов могут
// ставить хуки независимо: вызовы выстраиваются в цепочку.
namespace dx11 {
struct Callbacks {
    void (*onPresent)(IDXGISwapChain*, UINT& syncInterval) = nullptr;  // до оригинального Present
    void (*onAfterPresent)(IDXGISwapChain*) = nullptr;                 // после
    void (*onCreateSampler)(D3D11_SAMPLER_DESC&) = nullptr;            // можно менять описание
};
bool Install(const Callbacks& cb);
}  // namespace dx11
