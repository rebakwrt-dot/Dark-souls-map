@echo off
chcp 65001 >nul
setlocal
set "SRC=%~dp0"
set "GAME=C:\Program Files (x86)\Steam\steamapps\common\DARK SOULS REMASTERED"
if not "%~1"=="" set "GAME=%~1"
if not exist "%GAME%\DarkSoulsRemastered.exe" (
  echo Папка игры не найдена: %GAME%
  echo Запустите так: install.bat "D:\Games\DARK SOULS REMASTERED"
  pause
  exit /b 1
)
copy /y "%SRC%dinput8.dll" "%GAME%\" >nul
xcopy /e /i /y "%SRC%DSRMods" "%GAME%\DSRMods" >nul
echo Установлено в %GAME%
pause
