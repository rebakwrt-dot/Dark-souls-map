#pragma once
#include <windows.h>
#include <cstdint>
#include <cstdlib>
#include <string>
#include <vector>

// Цепочка указателей: [первое число — смещение от старта (база exe или адрес сущности)],
// каждое следующее: прочитать указатель по текущему адресу и прибавить смещение.
struct Chain {
    std::vector<uintptr_t> v;
    bool valid() const { return !v.empty(); }
};

inline Chain ParseChain(const std::string& s) {
    Chain c;
    size_t i = 0;
    while (i < s.size()) {
        size_t j = s.find(',', i);
        if (j == std::string::npos) j = s.size();
        std::string t = s.substr(i, j - i);
        size_t a = t.find_first_not_of(" \t");
        if (a != std::string::npos) c.v.push_back((uintptr_t)strtoull(t.c_str() + a, nullptr, 0));
        i = j + 1;
    }
    return c;
}

template <class T>
inline bool Rd(uintptr_t a, T& out) {
    if (a < 0x10000) return false;
    __try {
        out = *reinterpret_cast<const T*>(a);
        return true;
    } __except (EXCEPTION_EXECUTE_HANDLER) {
        return false;
    }
}

inline bool Resolve(const Chain& c, uintptr_t start, uintptr_t& out) {
    if (c.v.empty()) return false;
    uintptr_t p = start + c.v[0];
    for (size_t i = 1; i < c.v.size(); ++i) {
        uintptr_t q = 0;
        if (!Rd(p, q) || !q) return false;
        p = q + c.v[i];
    }
    out = p;
    return true;
}

template <class T>
inline bool ReadChain(const Chain& c, uintptr_t start, T& out) {
    uintptr_t a = 0;
    return Resolve(c, start, a) && Rd(a, out);
}
