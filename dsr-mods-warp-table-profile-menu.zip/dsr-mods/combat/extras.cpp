#define _CRT_SECURE_NO_WARNINGS
// DSRCombat: coordinate-only predictive dodge using configurable geometric proxies.
// These proxies are approximations, not the game's real attack hitboxes.
#include <windows.h>
#include <algorithm>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <atomic>
#include <map>
#include <mutex>
#include <set>
#include <string>
#include <unordered_map>
#include <vector>
#include <fstream>
#include <sstream>

#include "imgui.h"
#include "../common/mem.h"
#include "combat.h"

namespace {
struct Config {
    Chain animReq;
    int toggleKey = VK_F9;
    int rollClass = 0;
    float rangeM = 3.5f;
    float leadMs = 130.0f;
    float cooldownMs = 800.0f;
    float playerRadius = 0.48f;
    float playerHeight = 1.65f;
    float playerYOffset = 0.10f;
    float enemyAttackRadius = 0.72f;
    float enemyAttackLength = 2.15f;
    float enemyAttackHeight = 1.35f;
    float enemyAttackYOffset = 0.65f;
    float predictionHorizonMs = 650.0f;
    bool predictionEnabled = true;
    bool debugDraw = false;
    // Только боссы: перекат срабатывает лишь на врагов из списка боссов / отмеченных вручную.
    // Если цепочка anim_request не задана, перекат выполняется «нажатием» клавиши (по умолчанию Left Shift).
    int rollKey = 0xA0;         // VK_LSHIFT
    int rollHoldMs = 60;
    bool bossesOnly = true;
    int markKey = VK_NUMPAD8;   // пометить / снять метку «босс» с ближайшего врага
    int clearKey = VK_NUMPAD7;  // снять все ручные метки
    float markRangeM = 25.0f;
    std::vector<int32_t> extraBossIds;
    std::string dodgeProfile;
    float dodgeLeadMs = 130.0f;
    float dodgeWindowMs = 180.0f;
    bool dodgeProjectiles = true;
    float dodgeReachScale = 1.0f;     // множитель табличной дальности удара (dX)
    float dodgeReachMarginM = 0.6f;   // запас на радиус игрока, м
    float dodgeFacingDeg = 0.0f;      // legacy INI compatibility; direction no longer hard-blocks table dodges
    float facingOffsetDeg = 0.0f;     // поправка к углу взгляда, если угол в игре отсчитывается иначе
    float dodgeMaxDyM = 4.0f;         // оставлено для совместимости INI; таблица больше не отсекает удары только по высоте
};

// Entity ID боссов Dark Souls (Souls Modding Wiki, страница ds1-refmat:boss-info).
// У Bed of Chaos, Ornstein & Smough и Four Kings на вики нет entity ID — их отмечайте клавишей mark_key.
constexpr int32_t kBossIds[] = {
    1000800,           // Gaping Dragon
    1010700,           // Taurus Demon
    1010800, 1010801,  // Bell Gargoyles
    1010750,           // Capra Demon
    1100160,           // Priscilla
    1200801,           // Moonlight Butterfly
    1200800,           // Wolf Sif
    1210800,           // Sanctuary Guardian
    1210820,           // Knight Artorias
    1210840,           // Manus
    1210401, 1210402,  // Kalameet
    1300800,           // Pinwheel
    1310800,           // Nito
    1400800,           // Quelaag
    1410600,           // Ceaseless Discharge
    1410400,           // Demon Firesage
    1410700,           // Centipede Demon
    1500800,           // Iron Golem
    1510650,           // Gwyndolin
    1700800,           // Seath
    1800800,           // Gwyn
    1810800,           // Asylum Demon
    1810810,           // Stray Demon
};
Config g_cfg;
uintptr_t g_base = 0;
bool g_loaded = false;
bool g_enabled = true;
bool g_prevToggle = false;
ULONGLONG g_nextRoll = 0;
uintptr_t g_playerPtr = 0;               // указатель на сущность игрока (если найден автопоиском)
std::set<uintptr_t> g_marked;            // ручные метки боссов (только поток логики)
std::atomic<bool> g_autoDone{false};     // автонастройка цепочек завершена
std::atomic<bool> g_forceRediscover{false};  // список врагов пуст/неверен: перенайти его
int g_autoAttempts = 0;
std::atomic<int> g_markedCount{0}, g_bossInView{0}, g_idsRead{0};
std::mutex g_uiMx;
std::string g_uiStatus;
void SetUi(const std::string& t) { std::lock_guard<std::mutex> l(g_uiMx); g_uiStatus = t; }

struct Sample { float x=0, y=0, z=0; ULONGLONG ms=0; };
struct Track {
    Sample older{}, latest{};
    float vx=0, vy=0, vz=0;
    float ax=0, ay=0, az=0;
    bool valid=false;
    bool threatLatched=false;
};
std::unordered_map<uintptr_t, Track> g_tracks;
Track g_playerTrack;
struct ThreatDebug {
    float ex=0, ey=0, ez=0, fx=0, fz=1, t=-1;
    bool hit=false;
};
std::vector<ThreatDebug> g_debug;

// Тайминги из dodge_timings.txt. Профиль выбирается вручную, а ID/время анимации читаются автоматически.
struct DodgeEvent { float time = 0.0f; bool projectile = false; };
enum class AttackKind : unsigned char { Unknown, Melee, Area, Projectile, Grab, Mixed, Multi };
std::map<int, AttackKind> g_dodgeAttackKind;
struct DodgeAnimState { int anim = -1; float previous = 0.0f; bool initialized = false; std::vector<unsigned char> fired; };
std::map<int, std::vector<DodgeEvent>> g_dodgeTable;
std::map<int, float> g_dodgeReach;   // макс. дальность удара из dX (м); нет записи = не ограничена
std::unordered_map<uintptr_t, DodgeAnimState> g_dodgeStates;
std::string g_loadedDodgeProfile;
Chain g_dodgeAnimChain, g_dodgeTimeChain;
bool g_dodgeTableLoaded = false;
std::string g_dodgeTableStatus = "таблица ещё не загружена";
void SetDodgeStatus(const std::string& value) { std::lock_guard<std::mutex> lock(g_uiMx); g_dodgeTableStatus = value; }
std::string GetDodgeStatus() { std::lock_guard<std::mutex> lock(g_uiMx); return g_dodgeTableStatus; }

std::string Ini() { return CombatIniPath(); }
std::string ReadIni(const char* section, const char* key, const char* def) {
    char b[256]{};
    GetPrivateProfileStringA(section, key, def, b, sizeof(b), Ini().c_str());
    return b;
}
float ReadFloat(const char* key, float def, float lo, float hi) {
    char d[32]{}; snprintf(d, sizeof(d), "%g", def);
    return std::clamp((float)atof(ReadIni("auto_roll", key, d).c_str()), lo, hi);
}
bool ReadBool(const char* key, bool def) {
    return ReadIni("auto_roll", key, def ? "1" : "0") != "0";
}
void EnsureDefault(const char* key, const char* value) {
    char b[8]{};
    GetPrivateProfileStringA("auto_roll", key, "\x01", b, sizeof(b), Ini().c_str());
    if (b[0] == '\x01') WritePrivateProfileStringA("auto_roll", key, value, Ini().c_str());
}
void LoadCfg() {
    // Legacy INI entries are left untouched; only the keys below are consumed here.
    const char* defaults[][2] = {
        {"toggle_key", "0x78"}, {"roll_class", "0"}, {"range_m", "3.5"},
        {"roll_lead_ms", "130"}, {"cooldown_ms", "800"},
        {"player_radius", "0.48"}, {"player_height", "1.65"}, {"player_y_offset", "0.10"},
        {"enemy_attack_radius", "0.72"}, {"enemy_attack_length", "2.15"},
        {"enemy_attack_height", "1.35"}, {"enemy_attack_y_offset", "0.65"},
        {"prediction_horizon_ms", "650"}, {"prediction_enabled", "1"}, {"debug_draw", "0"},
        {"roll_key", "0xA0"}, {"roll_hold_ms", "60"}, {"bosses_only", "1"}, {"boss_ids", ""}, {"mark_key", "0x68"}, {"clear_marks_key", "0x67"}, {"mark_range_m", "25"}, {"dodge_profile", ""}, {"dodge_lead_ms", "130"}, {"dodge_window_ms", "180"}, {"dodge_projectiles", "1"}, {"dodge_reach_scale", "1"}, {"dodge_reach_margin_m", "0.6"}, {"dodge_facing_deg", "0"}, {"facing_offset_deg", "0"}, {"dodge_max_dy_m", "4"}
    };
    for (const auto& d : defaults) EnsureDefault(d[0], d[1]);
    Config c;
    c.animReq = ParseChain(ReadIni("offsets", "anim_request", ""));
    c.toggleKey = (int)strtol(ReadIni("auto_roll", "toggle_key", "0x78").c_str(), nullptr, 0);
    if (c.toggleKey == VK_NUMPAD9) {  // старое значение по умолчанию переносим на F9 (NumPad 9 ломал сторонние трейнеры)
        c.toggleKey = VK_F9;
        WritePrivateProfileStringA("auto_roll", "toggle_key", "0x78", Ini().c_str());
    }
    c.rollClass = std::clamp(atoi(ReadIni("auto_roll", "roll_class", "0").c_str()), 0, 2);
    c.rangeM = ReadFloat("range_m", 3.5f, 0.5f, 15.0f);
    c.leadMs = ReadFloat("roll_lead_ms", 130.0f, 20.0f, 500.0f);
    c.cooldownMs = ReadFloat("cooldown_ms", 800.0f, 200.0f, 2500.0f);
    c.playerRadius = ReadFloat("player_radius", 0.48f, 0.15f, 1.5f);
    c.playerHeight = ReadFloat("player_height", 1.65f, 0.6f, 2.8f);
    c.playerYOffset = ReadFloat("player_y_offset", 0.10f, -1.0f, 1.0f);
    c.enemyAttackRadius = ReadFloat("enemy_attack_radius", 0.72f, 0.15f, 2.5f);
    c.enemyAttackLength = ReadFloat("enemy_attack_length", 2.15f, 0.3f, 6.0f);
    c.enemyAttackHeight = ReadFloat("enemy_attack_height", 1.35f, 0.3f, 3.5f);
    c.enemyAttackYOffset = ReadFloat("enemy_attack_y_offset", 0.65f, -1.0f, 2.5f);
    c.predictionHorizonMs = ReadFloat("prediction_horizon_ms", 650.0f, 100.0f, 1500.0f);
    c.predictionEnabled = ReadBool("prediction_enabled", true);
    c.debugDraw = ReadBool("debug_draw", false);
    c.rollKey = (int)strtol(ReadIni("auto_roll", "roll_key", "0xA0").c_str(), nullptr, 0);
    c.rollHoldMs = (int)ReadFloat("roll_hold_ms", 60.0f, 20.0f, 250.0f);
    c.bossesOnly = ReadBool("bosses_only", true);
    c.markKey = (int)strtol(ReadIni("auto_roll", "mark_key", "0x68").c_str(), nullptr, 0);
    c.clearKey = (int)strtol(ReadIni("auto_roll", "clear_marks_key", "0x67").c_str(), nullptr, 0);
    c.markRangeM = ReadFloat("mark_range_m", 25.0f, 3.0f, 100.0f);
    {   // boss_ids=1234567, 1234568 — дополнительные entity ID сверх встроенного списка
        const std::string list = ReadIni("auto_roll", "boss_ids", "");
        size_t i = 0;
        while (i < list.size()) {
            size_t j = list.find_first_of(",; ", i);
            if (j == std::string::npos) j = list.size();
            if (j > i) {
                const long v = strtol(list.substr(i, j - i).c_str(), nullptr, 0);
                if (v > 0) c.extraBossIds.push_back((int32_t)v);
            }
            i = j + 1;
        }
    }
    c.dodgeProfile = ReadIni("auto_roll", "dodge_profile", "");
    c.dodgeLeadMs = ReadFloat("dodge_lead_ms", 130.0f, 20.0f, 500.0f);
    c.dodgeWindowMs = ReadFloat("dodge_window_ms", 180.0f, 50.0f, 500.0f);
    c.dodgeProjectiles = ReadBool("dodge_projectiles", true);
    c.dodgeReachScale = ReadFloat("dodge_reach_scale", 1.0f, 0.2f, 3.0f);
    c.dodgeReachMarginM = ReadFloat("dodge_reach_margin_m", 0.6f, 0.0f, 5.0f);
    c.dodgeFacingDeg = ReadFloat("dodge_facing_deg", 0.0f, 0.0f, 180.0f);
    c.facingOffsetDeg = ReadFloat("facing_offset_deg", 0.0f, -180.0f, 180.0f);
    c.dodgeMaxDyM = ReadFloat("dodge_max_dy_m", 4.0f, 0.5f, 50.0f);
    g_cfg = c;
    g_dodgeTableLoaded = false;
    g_dodgeStates.clear();
    g_playerTrack = Track{};
    g_tracks.clear();
    g_loaded = true;
}

template <class T> bool WriteAt(uintptr_t address, T value) {
    if (address < 0x10000 || address > UINTPTR_MAX - sizeof(T)) return false;
    __try { *reinterpret_cast<T*>(address) = value; return true; }
    __except (EXCEPTION_EXECUTE_HANDLER) { return false; }
}
float Length2(float x, float z) { return std::sqrt(x*x + z*z); }
void Normalize(float& x, float& z) {
    const float n = Length2(x, z);
    if (n > 0.0001f) { x /= n; z /= n; }
    else { x = 0.0f; z = 1.0f; }
}
float PointSegmentDistance2D(float px, float pz, float ax, float az, float bx, float bz) {
    const float dx = bx - ax, dz = bz - az;
    const float d2 = dx*dx + dz*dz;
    float t = d2 > 0.000001f ? ((px-ax)*dx + (pz-az)*dz) / d2 : 0.0f;
    t = std::clamp(t, 0.0f, 1.0f);
    return Length2(px - (ax + t*dx), pz - (az + t*dz));
}

bool UpdateTrackPosition(float x, float y, float z, ULONGLONG now, Track& tr) {
    if (!tr.valid) {
        tr.latest = {x,y,z,now}; tr.older = tr.latest; tr.valid = true;
        return false;
    }
    if (now <= tr.latest.ms) return false;
    const float dt = (float)(now - tr.latest.ms) / 1000.0f;
    const float dx=x-tr.latest.x, dy=y-tr.latest.y, dz=z-tr.latest.z;
    const float jump = std::sqrt(dx*dx + dy*dy + dz*dz);
    // Ignore implausible teleports / entity reuse and restart the history.
    if (dt > 0.30f || dt < 0.004f || jump > 8.0f) {
        tr = Track{}; tr.latest = {x,y,z,now}; tr.older = tr.latest; tr.valid = true;
        return false;
    }
    const float ivx=dx/dt, ivy=dy/dt, ivz=dz/dt;
    const float oldVx=tr.vx, oldVy=tr.vy, oldVz=tr.vz;
    tr.ax = std::clamp((ivx-oldVx)/dt, -35.0f, 35.0f);
    tr.ay = std::clamp((ivy-oldVy)/dt, -35.0f, 35.0f);
    tr.az = std::clamp((ivz-oldVz)/dt, -35.0f, 35.0f);
    // Smooth velocity to reduce noisy single-frame position changes.
    tr.vx = oldVx*0.35f + ivx*0.65f;
    tr.vy = oldVy*0.35f + ivy*0.65f;
    tr.vz = oldVz*0.35f + ivz*0.65f;
    tr.older = tr.latest;
    tr.latest = {x,y,z,now};
    return true;
}
bool UpdateTrack(const EnemyView& e, ULONGLONG now, Track& tr) {
    return UpdateTrackPosition(e.x, e.y, e.z, now, tr);
}

bool FindPredictedContact(const EnemyView& e, const PeerView& me, const Track& tr,
                          float& contactTime, float& outFx, float& outFz) {
    const float rx=me.x-e.x, rz=me.z-e.z;
    if (Length2(rx,rz) > g_cfg.rangeM) return false; // range_m is the real detection limit

    float fx=std::sin(e.ang), fz=std::cos(e.ang);
    Normalize(fx,fz);
    const float speed=Length2(tr.vx,tr.vz);
    if (speed > 0.45f) {
        float mx=tr.vx/speed, mz=tr.vz/speed;
        // Blend facing and measured travel direction; never infer attack state from animation.
        fx=fx*0.65f + mx*0.35f; fz=fz*0.65f + mz*0.35f;
        Normalize(fx,fz);
    }
    outFx=fx; outFz=fz;
    const float horizon=g_cfg.predictionEnabled ? g_cfg.predictionHorizonMs/1000.0f : 0.0f;
    const float radius=g_cfg.enemyAttackRadius + g_cfg.playerRadius;
    const float playerBottom=me.y + g_cfg.playerYOffset;
    const float playerTop=playerBottom + g_cfg.playerHeight;
    if (e.hasY) {
        const float attackBottom=e.y + g_cfg.enemyAttackYOffset;
        const float attackTop=attackBottom + g_cfg.enemyAttackHeight;
        if (attackTop < playerBottom || attackBottom > playerTop) return false;
    }

    // Sweep the approximate forward capsule along the predicted root trajectory.
    // This is intentionally a configurable proxy, not a claim about real game hitboxes.
    const float step=0.025f;
    const int steps=std::max(1,(int)std::ceil(horizon/step));
    for (int i=0;i<=steps;++i) {
        const float t=(horizon>0.0f) ? std::min(horizon, i*step) : 0.0f;
        const float ex=e.x + tr.vx*t + 0.5f*tr.ax*t*t;
        const float ez=e.z + tr.vz*t + 0.5f*tr.az*t*t;
        float ax=ex + fx*0.20f, az=ez + fz*0.20f;
        float bx=ex + fx*std::min(g_cfg.enemyAttackLength,g_cfg.rangeM);
        float bz=ez + fz*std::min(g_cfg.enemyAttackLength,g_cfg.rangeM);
        const float d=PointSegmentDistance2D(me.x,me.z,ax,az,bx,bz);
        if (d <= radius) { contactTime=t; return true; }
    }
    return false;
}

// Снимок для отладочной отрисовки: ImGui можно трогать только из потока рендера, а AutoRollTick
// работает в потоке логики. Поэтому логика кладёт сюда копию, а рисует ExtrasDrawDebug() в Present.
struct DbgItem { EnemyView e; Track tr; ThreatDebug d; bool hasD=false; };
struct DbgSnap { PeerView me; std::vector<DbgItem> items; };
std::mutex g_dbgMx;
DbgSnap g_snap;
std::atomic<bool> g_dbgOn{false};
std::atomic<bool> g_reload{false};
ULONGLONG g_idleUntil = 0;

void SaveSnap(const PeerView& me, const std::vector<EnemyView>& enemies) {
    DbgSnap n;
    n.me = me;
    for (const auto& e : enemies) {
        auto it = g_tracks.find(e.ptr);
        if (it == g_tracks.end()) continue;
        DbgItem d;
        d.e = e; d.tr = it->second;
        auto dbg = std::find_if(g_debug.begin(), g_debug.end(), [&](const ThreatDebug& t){ return t.ex==e.x && t.ez==e.z; });
        if (dbg != g_debug.end()) { d.d = *dbg; d.hasD = true; }
        n.items.push_back(d);
    }
    std::lock_guard<std::mutex> l(g_dbgMx);
    g_snap = std::move(n);
}

void DrawDebugSnap(const DbgSnap& sn) {
    const PeerView& me = sn.me;
    ImDrawList* dl=ImGui::GetForegroundDrawList();
    const ImVec2 display=ImGui::GetIO().DisplaySize;
    const ImVec2 origin(display.x-190.0f, 190.0f);
    constexpr float scale=34.0f;
    dl->AddCircle(origin, 4.0f, IM_COL32(80,220,120,255), 16, 2.0f);
    dl->AddCircle(origin, g_cfg.rangeM*scale, IM_COL32(120,120,120,90), 48, 1.0f);
    dl->AddText(ImVec2(origin.x-45,origin.y+8),IM_COL32(100,240,140,255),"PLAYER");
    for (const auto& it : sn.items) {
        const EnemyView& e = it.e; const Track& tr = it.tr;
        const float dx=e.x-me.x, dz=e.z-me.z;
        const ImVec2 ep(origin.x+dx*scale,origin.y-dz*scale);
        float fx=std::sin(e.ang), fz=std::cos(e.ang); Normalize(fx,fz);
        const ImVec2 end(ep.x+fx*g_cfg.enemyAttackLength*scale,ep.y-fz*g_cfg.enemyAttackLength*scale);
        dl->AddCircle(ep,4.0f,IM_COL32(255,180,70,255),12,1.5f);
        dl->AddLine(ep,end,IM_COL32(255,150,60,180),2.0f);
        dl->AddCircle(end,g_cfg.enemyAttackRadius*scale,IM_COL32(255,100,70,110),16,1.0f);
        const float sp=Length2(tr.vx,tr.vz);
        if (sp>0.05f) dl->AddLine(ep,ImVec2(ep.x+tr.vx*0.25f*scale,ep.y-tr.vz*0.25f*scale),IM_COL32(80,180,255,255),2.0f);
        if (it.hasD && it.d.hit) {
            char label[64]; snprintf(label,sizeof(label),"CONTACT %.0f ms",it.d.t*1000.0f);
            dl->AddText(ImVec2(ep.x+5,ep.y-18),IM_COL32(255,90,90,255),label);
        }
    }
}

bool IsBossId(int32_t id) {
    if (id <= 0) return false;
    for (int32_t b : kBossIds) if (b == id) return true;
    for (int32_t b : g_cfg.extraBossIds) if (b == id) return true;
    return false;
}
bool IsBoss(const EnemyView& e) { return g_marked.count(e.ptr) > 0 || IsBossId(e.entityId); }

bool KeyHit(int vk, bool& prev) {
    if (!vk) return false;
    const SHORT st = GetAsyncKeyState(vk);
    const bool down = (st & 0x8000) != 0;
    const bool hit = (down && !prev) || (st & 1);  // низкий бит ловит короткое нажатие между опросами
    prev = down;
    return hit;
}

// Ручная метка: ближайший к игроку враг в mark_range_m становится (или перестаёт быть) боссом.
void HandleMarkKeys() {
    static bool prevMark = false, prevClear = false;
    const bool clear = KeyHit(g_cfg.clearKey, prevClear);
    const bool mark = KeyHit(g_cfg.markKey, prevMark);
    if (clear) {
        g_marked.clear(); g_markedCount = 0;
        SetUi("Ручные метки боссов сброшены.");
    }
    if (!mark) return;
    PeerView me;
    std::vector<EnemyView> en;
    if (!CoopMyPosition(me) || !WorldEnemyPositions(en)) {
        SetUi("Не удалось прочитать позицию игрока или список врагов: проверьте цепочки в DSRCombat.ini.");
        return;
    }
    const EnemyView* best = nullptr;
    float bestD = g_cfg.markRangeM;
    int others = 0;
    float nearest = 1e9f;
    for (const auto& e : en) {
        if (!e.ptr || e.ptr == g_playerPtr) continue;
        const float d = Length2(e.x - me.x, e.z - me.z);
        if (d < 0.5f) continue;  // сам игрок (дубликат указателя)
        ++others;
        if (d < nearest) nearest = d;
        if (d < bestD) { bestD = d; best = &e; }
    }
    char msg[480];
    if (!best) {
        if (others == 0) {
            snprintf(msg, sizeof(msg), "Список врагов пуст (сущностей в списке: %d, кроме игрока: 0). Список найден неверно — запускаю автопоиск заново, повторите NumPad 8 через ~5 с.", (int)en.size());
            g_autoAttempts = 0; g_autoDone = false; g_forceRediscover = true;
        } else {
            snprintf(msg, sizeof(msg), "Нет врагов в радиусе %.0f м: в списке %d сущн., ближайшая в %.0f м (радиус — mark_range_m в INI).", g_cfg.markRangeM, others, nearest);
        }
    } else if (g_marked.erase(best->ptr)) {
        snprintf(msg, sizeof(msg), "Метка снята: враг на %.1f м (entity ID %d).", bestD, best->entityId);
    } else {
        g_marked.insert(best->ptr);
        snprintf(msg, sizeof(msg), "Босс отмечен: враг на %.1f м (entity ID %d).", bestD, best->entityId);
    }
    g_markedCount = (int)g_marked.size();
    SetUi(msg);
}

bool CanRoll() { return g_cfg.animReq.valid() || g_cfg.rollKey != 0; }

// Короткое нажатие клавиши переката в отдельном потоке (в DS перекат срабатывает по отпусканию короткого нажатия).
DWORD WINAPI KeyTapThread(LPVOID param) {
    const int vk = (int)(INT_PTR)param & 0xFFFF;
    const int hold = (int)((INT_PTR)param >> 16);
    const WORD scan = (WORD)MapVirtualKeyA((UINT)vk, MAPVK_VK_TO_VSC);
    INPUT in{};
    in.type = INPUT_KEYBOARD;
    in.ki.wVk = 0; in.ki.wScan = scan; in.ki.dwFlags = KEYEVENTF_SCANCODE;
    SendInput(1, &in, sizeof(INPUT));
    Sleep((DWORD)hold);
    in.ki.dwFlags = KEYEVENTF_SCANCODE | KEYEVENTF_KEYUP;
    SendInput(1, &in, sizeof(INPUT));
    return 0;
}
void TapRollKey() {
    HANDLE h = CreateThread(nullptr, 0, KeyTapThread, (LPVOID)(INT_PTR)((g_cfg.rollHoldMs << 16) | (g_cfg.rollKey & 0xFFFF)), 0, nullptr);
    if (h) CloseHandle(h);
}

// ---------- автонастройка цепочек ----------
// Смещения взяты из исходников DSR-Gadget (DSROffsets.cs): WorldChrBase -> +0x68 ChrData1 -> +0x48 (+0x20 на 1.03) ChrMapData
// -> +0x28 ChrPosData -> +0x10 X, +0x14 Y, +0x18 Z, +0x4 угол. Пишутся только в ПУСТЫЕ ключи [offsets].
bool OffsetKeyEmpty(const char* key) {
    char b[512]{};
    GetPrivateProfileStringA("offsets", key, "", b, sizeof(b), Ini().c_str());
    return b[0] == 0;
}
bool FillIfEmpty(const char* key, const std::string& value) {
    if (!OffsetKeyEmpty(key)) return false;
    WritePrivateProfileStringA("offsets", key, value.c_str(), Ini().c_str());
    return true;
}
int MapDataOffsetBySize() {
    const IMAGE_DOS_HEADER* dos = reinterpret_cast<const IMAGE_DOS_HEADER*>(g_base);
    const IMAGE_NT_HEADERS* nt = reinterpret_cast<const IMAGE_NT_HEADERS*>(g_base + dos->e_lfanew);
    const DWORD sz = nt->OptionalHeader.SizeOfImage;
    // Старые сборки 1.01 / 1.01.1 / 1.01.2 — без сдвига; всё остальное считаем как 1.03.
    const bool old = sz == 0x4869400 || sz == 0x496BE00 || sz == 0x37CB400;
    return old ? 0x48 : 0x68;
}
int MapDataOffset();
bool Readable(uintptr_t a, size_t n) {
    if (a < 0x10000) return false;
    MEMORY_BASIC_INFORMATION m{};
    if (!VirtualQuery(reinterpret_cast<void*>(a), &m, sizeof(m))) return false;
    if (m.State != MEM_COMMIT || (m.Protect & (PAGE_GUARD | PAGE_NOACCESS))) return false;
    return a + n <= (uintptr_t)m.BaseAddress + m.RegionSize;
}
bool Peek64(uintptr_t a, uintptr_t& o) { return Readable(a, 8) && Rd(a, o); }
bool Peek32(uintptr_t a, int32_t& o) { return Readable(a, 4) && Rd(a, o); }

// Ищем в объекте WorldChrBase (и на уровень глубже) массив указателей, в котором лежит указатель на игрока.
// Из всех кандидатов берём тот, где больше всего сущностей с читаемыми координатами (по цепочке игрока),
// а счётчик — ближайший к числу найденных сущностей. Раньше брался первый попавшийся массив, и им мог оказаться
// не список персонажей мира (отсюда «нет врагов рядом»).
bool PeekF(uintptr_t a, float& o) { return Readable(a, 4) && Rd(a, o); }

// Смещение ChrMapData у разных сборок (в т.ч. пиратских) отличается: подбираем его по живому игроку.
// Берём первое смещение, по которому цепочка ChrMapData -> +0x28 даёт конечные координаты. Сначала 0x68 и 0x48.
std::atomic<int> g_mdDetected{-1};
int MapDataOffset() {
    const int cached = g_mdDetected.load();
    if (cached >= 0) return cached;
    const uintptr_t S = FindWorldChrStatic();
    uintptr_t W = 0, pl = 0;
    if (S && Peek64(S, W) && W && Peek64(W + 0x68, pl) && pl) {
        static const int order[] = {0x68, 0x48, 0x58, 0x78, 0x50, 0x60, 0x70, 0x40, 0x80, 0x88, 0x90, 0x38, 0x30, 0x98, 0xA0, 0xA8, 0xB0};
        for (int off : order) {
            uintptr_t m = 0, pd = 0;
            float x = 0, y = 0, z = 0;
            if (!Peek64(pl + off, m) || !m || !Peek64(m + 0x28, pd) || !pd) continue;
            if (!PeekF(pd + 0x10, x) || !PeekF(pd + 0x14, y) || !PeekF(pd + 0x18, z)) continue;
            if (!std::isfinite(x) || !std::isfinite(y) || !std::isfinite(z)) continue;
            if (std::fabs(x) > 1e4f || std::fabs(y) > 1e4f || std::fabs(z) > 1e4f) continue;
            if (x == 0 && y == 0 && z == 0) continue;
            g_mdDetected = off;
            return off;
        }
    }
    return MapDataOffsetBySize();  // игрока ещё нет: временно берём по размеру образа (не кэшируем)
}
bool EntityXZ(uintptr_t e, float& x, float& z) {
    const int md = MapDataOffset();
    uintptr_t m = 0, pd = 0;
    if (!Peek64(e + md, m) || !m || !Peek64(m + 0x28, pd) || !pd) return false;
    if (!PeekF(pd + 0x10, x) || !PeekF(pd + 0x18, z)) return false;
    return std::isfinite(x) && std::isfinite(z) && std::fabs(x) < 1e5f && std::fabs(z) < 1e5f;
}
bool InModule(uintptr_t p) {
    const IMAGE_DOS_HEADER* dos = reinterpret_cast<const IMAGE_DOS_HEADER*>(g_base);
    const IMAGE_NT_HEADERS* nt = reinterpret_cast<const IMAGE_NT_HEADERS*>(g_base + dos->e_lfanew);
    return p >= g_base && p < g_base + nt->OptionalHeader.SizeOfImage;
}
// Указатель на «персонажа»: у объекта есть vtable в exe и читаемые координаты по цепочке игрока.
bool IsEntityPtr(uintptr_t e) {
    uintptr_t vt = 0;
    float x = 0, z = 0;
    return e >= 0x10000 && Peek64(e, vt) && InModule(vt) && EntityXZ(e, x, z);
}
struct Cand { std::string list; int stride = 0, valid = 0, others = 0; };
// Массив указателей на сущности по адресу holder. Шаг элемента неизвестен (8, 0x10, ... 0x40), игрок в нём
// необязателен; счётчик не нужен — читаем, пока подряд не встретится 8 «не сущностей».
void EvalHolder(uintptr_t holder, const std::string& listStr, std::vector<Cand>& all) {
    static const int strides[] = {8, 0x10, 0x18, 0x20, 0x28, 0x30, 0x38, 0x40};
    uintptr_t arr = 0, e0 = 0;
    if (!Peek64(holder, arr) || !Readable(arr, 16)) return;
    Peek64(arr, e0);
    const bool first = IsEntityPtr(e0);
    for (int st : strides) {
        uintptr_t e1 = 0;
        if (!first) { if (!Peek64(arr + st, e1) || !IsEntityPtr(e1)) continue; }
        int valid = 0, others = 0, bad = 0;
        for (int i = 0; i < 512; ++i) {
            uintptr_t e = 0;
            if (!Peek64(arr + (uintptr_t)i * st, e)) break;
            if (IsEntityPtr(e)) { ++valid; if (e != g_playerPtr) ++others; bad = 0; }
            else if (++bad >= 8) break;
        }
        if (others > 0) all.push_back({listStr, st, valid, others});
    }
}
void DumpScanLog(uintptr_t W, const std::vector<Cand>& all, const Cand* best) {
    std::string path = Ini();
    path = path.substr(0, path.find_last_of("\\/") + 1) + "enemy_scan.log";
    FILE* f = fopen(path.c_str(), "wt");
    if (!f) return;
    fprintf(f, "WorldChrBase=%p player=%p base=%p md=0x%X (detected=%d) imageSize=0x%lX\n", (void*)W, (void*)g_playerPtr, (void*)g_base, MapDataOffset(), g_mdDetected.load() >= 0,
            (unsigned long)reinterpret_cast<const IMAGE_NT_HEADERS*>(g_base + reinterpret_cast<const IMAGE_DOS_HEADER*>(g_base)->e_lfanew)->OptionalHeader.SizeOfImage);
    uintptr_t pvt = 0; Peek64(g_playerPtr, pvt);
    fprintf(f, "player vtable = base+0x%llX\ncandidates=%d best=%s\n", (unsigned long long)(pvt - g_base), (int)all.size(),
            best ? (best->list + " stride " + std::to_string(best->stride)).c_str() : "none");
    for (size_t i = 0; i < all.size() && i < 20; ++i)
        fprintf(f, "  %s stride=0x%X valid=%d others=%d\n", all[i].list.c_str(), all[i].stride, all[i].valid, all[i].others);
    fprintf(f, "--- WorldChrBase raw (0x300 bytes) ---\n");
    for (int k = 0; k < 0x300; k += 8) {
        uintptr_t v = 0;
        if (!Peek64(W + k, v)) { fprintf(f, "+%03X unreadable\n", k); continue; }
        if (InModule(v)) fprintf(f, "+%03X base+0x%llX\n", k, (unsigned long long)(v - g_base));
        else if (Readable(v, 16)) {
            uintptr_t a = 0, b = 0; Peek64(v, a); Peek64(v + 8, b);
            fprintf(f, "+%03X ptr %p -> %p %p\n", k, (void*)v, (void*)a, (void*)b);
        } else fprintf(f, "+%03X %llX\n", k, (unsigned long long)v);
    }
    fclose(f);
}
bool DiscoverEnemyList(std::string& msg) {
    const uintptr_t S = FindWorldChrStatic();
    uintptr_t W = 0;
    if (!S || !Peek64(S, W) || !W) { msg = "Автопоиск врагов: WorldChrBase пока недоступен (меню/загрузка?)."; return false; }
    if (!Peek64(W + 0x68, g_playerPtr) || !g_playerPtr) { msg = "Автопоиск врагов: игрок ещё не создан."; return false; }
    std::vector<Cand> all;
    char b[64];
    for (int k = 0; k < 0x800; k += 8) {                                       // глубина 1
        snprintf(b, sizeof(b), "@world, 0x%X", k);
        EvalHolder(W + k, b, all);
    }
    for (int k1 = 0; k1 < 0x400; k1 += 8) {                                   // глубина 2
        uintptr_t B = 0;
        if (!Peek64(W + k1, B) || !Readable(B, 0x400)) continue;
        for (int k2 = 0; k2 < 0x400; k2 += 8) {
            snprintf(b, sizeof(b), "@world, 0x%X, 0x%X", k1, k2);
            EvalHolder(B + k2, b, all);
        }
    }
    const Cand* best = nullptr;
    for (const auto& c : all) if (!best || c.others > best->others) best = &c;
    std::stable_sort(all.begin(), all.end(), [](const Cand& a, const Cand& b2) { return a.others > b2.others; });
    best = all.empty() ? nullptr : &all[0];
    DumpScanLog(W, all, best);
    if (!best) {
        msg = "Автопоиск врагов: массив персонажей не найден (подробности в DSRMods\\enemy_scan.log). Пришлите этот файл.";
        return false;
    }
    WritePrivateProfileStringA("offsets", "enemy_list", best->list.c_str(), Ini().c_str());
    WritePrivateProfileStringA("offsets", "enemy_count", "scan", Ini().c_str());  // не число: читаем массив до конца по признакам
    WritePrivateProfileStringA("offsets", "enemy_stride", std::to_string(best->stride).c_str(), Ini().c_str());
    WritePrivateProfileStringA("offsets", "enemy_skip_first", "0", Ini().c_str());
    msg = "Автопоиск врагов: список найден (" + best->list + ", шаг " + std::to_string(best->stride) + ", персонажей кроме игрока: " +
          std::to_string(best->others) + "). Нажмите NumPad 8 рядом с боссом.";
    return true;
}
// Есть ли в текущем списке хоть одна сущность кроме игрока. in-game == false — игрока ещё нет (меню/загрузка).
bool CurrentListHasEnemies(bool& inGame) {
    PeerView me;
    inGame = CoopMyPosition(me);
    if (!inGame) return false;
    const uintptr_t S = FindWorldChrStatic();
    uintptr_t W = 0;
    if (S && Peek64(S, W) && W) Peek64(W + 0x68, g_playerPtr);
    std::vector<EnemyView> en;
    if (!WorldEnemyPositions(en)) return false;
    for (const auto& e : en) if (e.ptr && e.ptr != g_playerPtr) return true;
    return false;
}

void AutoSetup(ULONGLONG now) {
    static ULONGLONG next = 0;
    if (g_autoDone || now < next) return;
    next = now + 2500;
    char b[96];
    bool changed = false;
    const int md = MapDataOffset();
    // Пустые ключи заполняем; ранее автосозданные цепочки (оканчиваются на ту же координату) исправляем, если смещение другое.
    auto SetAuto = [&](const char* key, const std::string& value, const char* suffix) {
        char cur[512]{};
        GetPrivateProfileStringA("offsets", key, "", cur, sizeof(cur), Ini().c_str());
        std::string c = cur;
        const bool autoMade = !c.empty() && c.size() >= strlen(suffix) && c.compare(c.size() - strlen(suffix), strlen(suffix), suffix) == 0 &&
                              c.find("0x28") != std::string::npos;
        if (c.empty() || (autoMade && c != value && g_mdDetected.load() >= 0)) {
            WritePrivateProfileStringA("offsets", key, value.c_str(), Ini().c_str());
            return true;
        }
        return false;
    };
    snprintf(b, sizeof(b), "@world, 0x68, 0x%X, 0x28, 0x10", md); changed |= SetAuto("pos_x", b, ", 0x28, 0x10");
    snprintf(b, sizeof(b), "@world, 0x68, 0x%X, 0x28, 0x4", md);  changed |= SetAuto("angle", b, ", 0x28, 0x4");
    snprintf(b, sizeof(b), "0x%X, 0x28, 0x10", md); changed |= SetAuto("enemy_x", b, ", 0x28, 0x10");
    snprintf(b, sizeof(b), "0x%X, 0x28, 0x14", md); changed |= SetAuto("enemy_y", b, ", 0x28, 0x14");
    snprintf(b, sizeof(b), "0x%X, 0x28, 0x18", md); changed |= SetAuto("enemy_z", b, ", 0x28, 0x18");
    snprintf(b, sizeof(b), "0x%X, 0x28, 0x4", md);  changed |= SetAuto("enemy_angle", b, ", 0x28, 0x4");
    if (changed) g_forceRediscover = true;  // координаты пересчитаны под новое смещение: список врагов ищем заново
    if (changed) { CombatReloadCfg(); SetUi("Цепочки игрока и врагов созданы/исправлены автоматически (смещение ChrMapData подобрано по игроку)."); return; }
    if (!OffsetKeyEmpty("enemy_list") && !OffsetKeyEmpty("enemy_count") && !g_forceRediscover) {
        // Список уже записан (в т.ч. старой версией мода): проверяем, что в нём есть не только игрок.
        bool inGame = false;
        if (CurrentListHasEnemies(inGame)) { g_autoDone = true; return; }
        if (!inGame) return;  // меню/загрузка — проверим позже
    }
    std::string msg;
    if (DiscoverEnemyList(msg)) { CombatReloadCfg(); g_autoDone = true; g_forceRediscover = false; g_autoAttempts = 0; }
    else if (++g_autoAttempts >= 40) { g_autoDone = true; g_forceRediscover = false; msg += " (попытки прекращены)"; }
    SetUi(msg);
}

bool Focused() {
    DWORD pid=0; GetWindowThreadProcessId(GetForegroundWindow(),&pid);
    return pid==GetCurrentProcessId();
}

// Читает анимационные цепочки сущности. Предпочитает enemy_anim_*, иначе использует
// цепочку игрока без префикса @world, 0x68 (тот же механизм, что и авто-парирование).
Chain DodgeEnemyChain(const char* ownKey, const char* playerKey) {
    char b[512]{};
    GetPrivateProfileStringA("offsets", ownKey, "", b, sizeof(b), Ini().c_str());
    Chain c = ParseChain(b);
    if (c.valid()) return c;
    GetPrivateProfileStringA("offsets", playerKey, "", b, sizeof(b), Ini().c_str());
    c = ParseChain(b);
    if (c.aob && c.v.size() >= 3 && c.v[1] == 0x68) {
        Chain r; r.v.assign(c.v.begin() + 2, c.v.end()); return r;
    }
    return Chain();
}

template <class T>
bool DodgeReadEntity(uintptr_t ent, const Chain& c, T& out) {
    if (!c.valid() || c.aob || ent < 0x10000 || ent > UINTPTR_MAX - c.v[0]) return false;
    uintptr_t a = ent + c.v[0];
    for (size_t i = 1; i < c.v.size(); ++i) {
        uintptr_t q = 0;
        if (!Peek64(a, q) || !q || q > UINTPTR_MAX - c.v[i]) return false;
        a = q + c.v[i];
    }
    return Rd(a, out);
}

std::string DodgeTablePath() {
    std::string p = Ini();
    const size_t slash = p.find_last_of("\\/");
    return (slash == std::string::npos ? std::string() : p.substr(0, slash + 1)) + "dodge_timings.txt";
}

void LoadDodgeTable() {
    g_dodgeTable.clear();
    g_dodgeReach.clear();
    g_dodgeAttackKind.clear();
    g_dodgeStates.clear();
    g_dodgeAnimChain = DodgeEnemyChain("enemy_anim_id", "anim_id");
    g_dodgeTimeChain = DodgeEnemyChain("enemy_anim_time", "anim_time");
    SetDodgeStatus("");
    const std::string profile = g_cfg.dodgeProfile;
    if (profile.empty()) { SetDodgeStatus("профиль не выбран (используется геометрический прогноз)"); g_dodgeTableLoaded = true; return; }
    std::ifstream f(DodgeTablePath());
    if (!f) { SetDodgeStatus("не найден dodge_timings.txt рядом с DSRCombat.dll"); g_dodgeTableLoaded = true; return; }
    std::string line, section;
    bool found = false;
    while (std::getline(f, line)) {
        const size_t first = line.find_first_not_of(" \t\r");
        if (first == std::string::npos || line[first] == ';' || line[first] == '#') continue;
        if (line[first] == '[') {
            const size_t end = line.find(']', first);
            section.clear();
            if (end != std::string::npos) {
                std::istringstream hs(line.substr(first + 1, end - first - 1));
                hs >> section; // [c2232 Asylum Demon] -> c2232
            }
            if (section == profile) found = true;
            continue;
        }
        if (section != profile) continue;
        const size_t colon = line.find(':', first);
        if (colon == std::string::npos) continue;
        const int anim = atoi(line.substr(first, colon - first).c_str());
        if (anim <= 0) continue;
        std::istringstream values(line.substr(colon + 1));
        std::string token;
        while (values >> token) {
            if (!token.empty() && (token[0] == 'd' || token[0] == 'D')) {  // dX.XX — максимальная дальность удара
                const float r = (float)atof(token.c_str() + 1);
                if (std::isfinite(r) && r > 0.0f && r < 100.0f) g_dodgeReach[anim] = r;
                continue;
            }
            bool projectile = !token.empty() && (token[0] == 'r' || token[0] == 'R');
            const char* number = projectile ? token.c_str() + 1 : token.c_str();
            char* end = nullptr;
            const float t = strtof(number, &end);
            if (end != number && std::isfinite(t) && t >= 0.0f && t <= 120.0f)
                g_dodgeTable[anim].push_back({t, projectile});
        }
    }
    // Дополнительная классификация из dodge_attack_types.txt. Она не задаёт направление
    // взмаха (его нет в исходной таблице), а выбирает консервативные правила отсечения.
    {
        std::string typePath = DodgeTablePath();
        const size_t slash = typePath.find_last_of("\\/");
        typePath = (slash == std::string::npos ? std::string() : typePath.substr(0, slash + 1)) + "dodge_attack_types.txt";
        std::ifstream tf(typePath);
        std::string tl, ts;
        while (std::getline(tf, tl)) {
            const size_t f = tl.find_first_not_of(" \t\r");
            if (f == std::string::npos || tl[f] == ';' || tl[f] == '#') continue;
            if (tl[f] == '[') {
                const size_t e = tl.find(']', f); ts.clear();
                if (e != std::string::npos) { std::istringstream hs(tl.substr(f + 1, e - f - 1)); hs >> ts; }
                continue;
            }
            if (ts != profile) continue;
            const size_t c = tl.find(':', f); if (c == std::string::npos) continue;
            const int a = atoi(tl.substr(f, c - f).c_str());
            std::string k = tl.substr(c + 1);
            const size_t kf = k.find_first_not_of(" \t");
            if (kf == std::string::npos) continue;
            k.erase(0, kf);
            AttackKind kind = AttackKind::Unknown;
            if (k == "melee") kind = AttackKind::Melee;
            else if (k == "area") kind = AttackKind::Area;
            else if (k == "projectile") kind = AttackKind::Projectile;
            else if (k == "grab") kind = AttackKind::Grab;
            else if (k == "multi") kind = AttackKind::Multi;
            else if (k == "mixed") kind = AttackKind::Mixed;
            if (a > 0) g_dodgeAttackKind[a] = kind;
        }
    }
    if (!found || g_dodgeTable.empty()) SetDodgeStatus("профиль " + profile + " не найден или пуст в dodge_timings.txt");
    else if (!g_dodgeAnimChain.valid() || !g_dodgeTimeChain.valid()) SetDodgeStatus("таблица загружена, но нет цепочек enemy_anim_id/enemy_anim_time (или anim_id/anim_time игрока)");
    else SetDodgeStatus("загружен профиль " + profile + ": " + std::to_string(g_dodgeTable.size()) + " анимаций");
    g_dodgeTableLoaded = true;
}


// ---------- Снимок боя: где босс, где игрок, кто куда смотрит ----------
// Откуда берутся числа (все читаются цепочками из DSRCombat.ini, раздел [offsets], их создаёт «Автопоиск координат» в окне U):
//   координаты игрока X,Y,Z : pos_x / pos_y / pos_z   (@world, 0x68, <ChrMapData>, 0x28, 0x10 / 0x14 / 0x18)
//   взгляд игрока (рад.)    : angle                   (@world, 0x68, <ChrMapData>, 0x28, 0x4)
//   координаты босса X,Y,Z  : enemy_x / enemy_y / enemy_z   (та же структура, но от указателя сущности врага: <ChrMapData>, 0x28, 0x10 / 0x14 / 0x18)
//   взгляд босса (рад.)     : enemy_angle             (<ChrMapData>, 0x28, 0x4)
// Направление вперёд считается как (sin(угол), cos(угол)), как у остального кода авто-переката.
struct CombatSnapshot {
    bool ok = false;
    float px = 0, py = 0, pz = 0, pyawDeg = 0;   // игрок
    float bx = 0, by = 0, bz = 0, byawDeg = 0;   // босс
    float dist2d = 0, dist3d = 0, dy = 0;        // расстояния, dy = игрок − босс
    float bossLooksAtPlayerDeg = 0;              // 0 = босс смотрит прямо на игрока, 180 = спиной (всегда 0..180)
    float bossRelSideDeg = 0;                    // со знаком: игрок левее (−) или правее (+) от взгляда босса
    float playerLooksAtBossDeg = 0;              // 0 = игрок смотрит прямо на босса
};
CombatSnapshot g_snap;
float WrapDeg(float a) { while (a > 180.0f) a -= 360.0f; while (a < -180.0f) a += 360.0f; return a; }
CombatSnapshot MakeSnapshot(const EnemyView& e, const PeerView& me) {
    CombatSnapshot r;
    const float rad = 57.29578f;
    r.px = me.x; r.py = me.y; r.pz = me.z; r.pyawDeg = WrapDeg(me.ang * rad);
    r.bx = e.x; r.by = e.y; r.bz = e.z; r.byawDeg = WrapDeg(e.ang * rad);
    const float dx = me.x - e.x, dz = me.z - e.z;
    r.dist2d = std::sqrt(dx * dx + dz * dz);
    r.dy = e.hasY ? me.y - e.y : 0.0f;
    r.dist3d = std::sqrt(r.dist2d * r.dist2d + r.dy * r.dy);
    if (r.dist2d > 1e-3f) {
        const float bearing = std::atan2(dx, dz) * rad;            // азимут от босса к игроку, 0 = ось +Z
        const float side = WrapDeg(bearing - r.byawDeg - g_cfg.facingOffsetDeg);
        r.bossRelSideDeg = side;
        r.bossLooksAtPlayerDeg = std::fabs(side);
        const float toBoss = std::atan2(-dx, -dz) * rad;           // азимут от игрока к боссу
        r.playerLooksAtBossDeg = std::fabs(WrapDeg(toBoss - r.pyawDeg));
    }
    r.ok = true;
    return r;
}

bool TryTableDodge(const EnemyView& enemy, const PeerView& me, const Track& enemyTrack, const Track& playerTrack, ULONGLONG now) {
    if (g_dodgeTable.empty() || !g_dodgeAnimChain.valid() || !g_dodgeTimeChain.valid()) return false;
    int32_t anim = -1; float animTime = 0.0f;
    if (!DodgeReadEntity(enemy.ptr, g_dodgeAnimChain, anim) || !DodgeReadEntity(enemy.ptr, g_dodgeTimeChain, animTime) ||
        !std::isfinite(animTime) || animTime < 0.0f) return false;
    auto it = g_dodgeTable.find(anim);
    if (it == g_dodgeTable.end()) { g_dodgeStates.erase(enemy.ptr); return false; }
    DodgeAnimState& state = g_dodgeStates[enemy.ptr];
    if (state.anim != anim || (state.initialized && animTime + 0.05f < state.previous)) {
        state.anim = anim; state.previous = animTime; state.initialized = true;
        state.fired.assign(it->second.size(), 0);
        return false;
    }
    if (!state.initialized) { state.initialized = true; state.previous = animTime; state.fired.assign(it->second.size(), 0); return false; }
    const float lead = g_cfg.dodgeLeadMs / 1000.0f;
    const float window = g_cfg.dodgeWindowMs / 1000.0f;
    for (size_t i = 0; i < it->second.size(); ++i) {
        const DodgeEvent& ev = it->second[i];
        if (state.fired[i] || (ev.projectile && !g_cfg.dodgeProjectiles)) continue;
        const float trigger = std::max(0.0f, ev.time - lead);
        // Срабатываем в небольшом временном окне, в том числе если первый опрос пришёл чуть позже.
        if (animTime < trigger || animTime > trigger + window) continue;
        // Прогнозируем взаимное положение к моменту активной фазы, а не только
        // используем текущую дистанцию. Это прогноз корней сущностей, не реальные hitbox.
        const float timeToImpact = std::clamp(ev.time - animTime, 0.0f, 0.75f);
        auto predict = [&](float p, float v, float a, float t) {
            return p + v * t + 0.5f * std::clamp(a, -35.0f, 35.0f) * t * t;
        };
        const float ex = enemyTrack.valid ? predict(enemy.x, enemyTrack.vx, enemyTrack.ax, timeToImpact) : enemy.x;
        const float ez = enemyTrack.valid ? predict(enemy.z, enemyTrack.vz, enemyTrack.az, timeToImpact) : enemy.z;
        const float px = playerTrack.valid ? predict(me.x, playerTrack.vx, playerTrack.ax, timeToImpact) : me.x;
        const float pz = playerTrack.valid ? predict(me.z, playerTrack.vz, playerTrack.az, timeToImpact) : me.z;
        const float futureDistance = Length2(px - ex, pz - ez);
        const AttackKind kind = g_dodgeAttackKind.count(anim) ? g_dodgeAttackKind[anim] : AttackKind::Unknown;
        const bool unconstrained = ev.projectile || kind == AttackKind::Projectile || kind == AttackKind::Grab || kind == AttackKind::Mixed;
        auto reach = g_dodgeReach.find(anim);
        if (!unconstrained && reach != g_dodgeReach.end()) {
            const float enemySpeed = enemyTrack.valid ? Length2(enemyTrack.vx, enemyTrack.vz) : 0.0f;
            const float playerSpeed = playerTrack.valid ? Length2(playerTrack.vx, playerTrack.vz) : 0.0f;
            const float uncertainty = 0.35f + std::min(2.5f, enemySpeed + playerSpeed) * std::min(timeToImpact, 0.45f) * 0.45f;
            const CombatSnapshot cs = MakeSnapshot(enemy, me);
            // Угол используется только для увеличения запаса риска, никогда не запрещает перекат:
            // у sweep/серий и неизвестного направления удар может достать сбоку или сзади.
            float angleExtra = 0.0f;
            if (kind == AttackKind::Melee || kind == AttackKind::Multi) {
                if (cs.bossLooksAtPlayerDeg > 100.0f) angleExtra = 1.25f;
                else if (cs.bossLooksAtPlayerDeg > 65.0f) angleExtra = 0.65f;
            }
            const float safeReach = reach->second * g_cfg.dodgeReachScale + g_cfg.dodgeReachMarginM + uncertainty + angleExtra;
            if (futureDistance > safeReach) continue;
        }
        const float dx = enemy.x - me.x, dz = enemy.z - me.z;
        const float fx = std::sin(me.ang), fz = std::cos(me.ang);
        const int direction = (fx * dx + fz * dz) > 0.0f ? 1 : 0;
        if (g_cfg.animReq.valid()) {
            uintptr_t address = 0;
            if (!Resolve(g_cfg.animReq, g_base, address)) continue;
            const int32_t command = 700 + g_cfg.rollClass * 10 + direction;
            if (!WriteAt<int32_t>(address, command)) continue;
        } else TapRollKey();
        state.fired[i] = 1;
        g_nextRoll = now + (ULONGLONG)g_cfg.cooldownMs;
        return true;
    }
    state.previous = animTime;
    return false;
}

void AutoRollTick(ULONGLONG now) {
    if (!Focused()) return;
    const bool toggle=g_cfg.toggleKey && (GetAsyncKeyState(g_cfg.toggleKey)&0x8000);
    if (toggle && !g_prevToggle) g_enabled=!g_enabled;
    g_prevToggle=toggle;
    if (g_cfg.bossesOnly) HandleMarkKeys();
    if (!g_enabled || now<g_idleUntil) return;
    if (!g_dodgeTableLoaded) LoadDodgeTable();

    PeerView me;
    // нет позиции / цепочек / списка врагов (меню, загрузка) — не долбим память каждые 8 мс
    if (!CanRoll() || !CoopMyPosition(me)) { g_idleUntil=now+250; return; }
    std::vector<EnemyView> enemies;
    if (!WorldEnemyPositions(enemies)) { g_idleUntil=now+250; return; }

    if (g_tracks.size()>512) {
        for (auto it=g_tracks.begin();it!=g_tracks.end();) {
            if (now>it->second.latest.ms+2000) it=g_tracks.erase(it); else ++it;
        }
    }
    if (!g_marked.empty()) {  // сущность исчезла из списка (смерть/выгрузка зоны) — метка больше не нужна
        std::set<uintptr_t> alive;
        for (const auto& e:enemies) alive.insert(e.ptr);
        for (auto it=g_marked.begin();it!=g_marked.end();) { if (!alive.count(*it)) it=g_marked.erase(it); else ++it; }
        g_markedCount=(int)g_marked.size();
    }
    {
        int bosses=0, ids=0;
        for (const auto& e:enemies) { if (e.entityId>0) ++ids; if (IsBoss(e)) ++bosses; }
        g_bossInView=bosses; g_idsRead=ids;
    }
    {   // снимок для окна: ближайший босс (или ближайший враг, если боссов нет)
        const EnemyView* best = nullptr; float bd = 1e30f;
        for (const auto& e : enemies) {
            if (!e.ptr || (g_cfg.bossesOnly && !IsBoss(e))) continue;
            const float d = (e.x - me.x) * (e.x - me.x) + (e.z - me.z) * (e.z - me.z);
            if (d < bd) { bd = d; best = &e; }
        }
        std::lock_guard<std::mutex> lk(g_uiMx);
        g_snap = best ? MakeSnapshot(*best, me) : CombatSnapshot{};
    }
    UpdateTrackPosition(me.x, me.y, me.z, now, g_playerTrack);
    g_debug.clear();
    for (const auto& enemy:enemies) {
        if (!enemy.ptr) continue;
        if (g_cfg.bossesOnly && !IsBoss(enemy)) continue;  // обычных врагов пропускаем: не отслеживаем и не катимся
        Track& tr=g_tracks[enemy.ptr];
        const bool hasMotion=UpdateTrack(enemy,now,tr);
        if (now < g_nextRoll) continue; // продолжаем собирать историю координат во время cooldown
        if (TryTableDodge(enemy, me, tr, g_playerTrack, now)) break; // таблица + консервативный прогноз положения
        if (!hasMotion) continue;
        float tContact=0,fx=0,fz=1;
        const bool threat=FindPredictedContact(enemy,me,tr,tContact,fx,fz);
        g_debug.push_back({enemy.x,enemy.y,enemy.z,fx,fz,tContact,threat});
        if (!threat) { tr.threatLatched=false; continue; }
        if (tContact*1000.0f > g_cfg.leadMs+35.0f || tr.threatLatched) continue;

        const float dx=enemy.x-me.x, dz=enemy.z-me.z;
        const float playerFx=std::sin(me.ang), playerFz=std::cos(me.ang);
        const bool threatFront=(playerFx*dx+playerFz*dz)>0.0f;
        const int direction=threatFront?1:0;
        if (g_cfg.animReq.valid()) {
            uintptr_t requestAddress=0;
            if (!Resolve(g_cfg.animReq,g_base,requestAddress)) continue;
            const int32_t command=700+g_cfg.rollClass*10+direction;
            if (!WriteAt<int32_t>(requestAddress,command)) continue;
        } else {
            TapRollKey();  // направление определяет игра: по текущему вводу движения (без ввода — шаг назад)
        }
        tr.threatLatched=true;
        g_nextRoll=now+(ULONGLONG)g_cfg.cooldownMs;
        break;
    }
    if (g_cfg.debugDraw) SaveSnap(me,enemies);
}

// ---------- Авто-парирование боссов (Гвин) ----------
// Тайминги берутся из анимаций Гвина (c5370.tae, события «атака», тип 1): секунда от начала анимации, когда удар становится активным.
// Парирование нажимается за parry_lead_ms до этого момента. Нужны цепочки анимации врага (ID и время): они берутся из
// enemy_anim_id / enemy_anim_time или выводятся из anim_id / anim_time игрока (калибратор, клавиша U). Список ударов
// (мелee-взмахи 3000-3005, 3008-3016) составлен по структуре анимаций: что именно парируется, в TAE не записано.
struct ParryCfg {
    bool loaded = false;
    int key = 0x20;          // Space
    int mouse = 2;           // 0 нет, 1 левая, 2 правая кнопка мыши
    int holdMs = 70;
    int toggleKey = 0x77;    // F8
    float leadMs = 330.0f;   // за сколько мс до удара нажимать
    float windowMs = 110.0f; // допуск по времени
    float rangeM = 6.0f;
    float cooldownMs = 900.0f;
    std::map<int, float> hits;
};
ParryCfg g_pc;
bool g_parryOn = false, g_prevParryToggle = false;
ULONGLONG g_parryNext = 0;
std::atomic<int> g_parryState{0};   // 0 выкл, 1 нет цепочек анимации, 2 готово
std::atomic<int> g_parryPresses{0};
struct ParryLatch { int anim = -1; float t = 0; bool fired = false; };
std::map<uintptr_t, ParryLatch> g_pLatch;
Chain g_eAnim, g_eTime;
ULONGLONG g_chainTry = 0;

std::string ParryIni(const char* key, const char* def) {
    char b[512]{};
    GetPrivateProfileStringA("auto_parry", key, "\x01", b, sizeof(b), Ini().c_str());
    if (b[0] == '\x01') { WritePrivateProfileStringA("auto_parry", key, def, Ini().c_str()); return def; }
    return b;
}
void ParryLoad() {
    ParryCfg c;
    c.loaded = true;
    g_parryOn = ParryIni("enabled", "0") != "0";
    c.toggleKey = (int)strtol(ParryIni("toggle_key", "0x77").c_str(), nullptr, 0);
    c.key = (int)strtol(ParryIni("parry_key", "0x20").c_str(), nullptr, 0);
    c.mouse = std::clamp(atoi(ParryIni("parry_mouse", "2").c_str()), 0, 2);
    c.holdMs = std::clamp(atoi(ParryIni("hold_ms", "70").c_str()), 20, 250);
    c.leadMs = std::clamp((float)atof(ParryIni("parry_lead_ms", "330").c_str()), 50.0f, 900.0f);
    c.windowMs = std::clamp((float)atof(ParryIni("window_ms", "110").c_str()), 30.0f, 400.0f);
    c.rangeM = std::clamp((float)atof(ParryIni("range_m", "6").c_str()), 1.0f, 20.0f);
    c.cooldownMs = std::clamp((float)atof(ParryIni("cooldown_ms", "900").c_str()), 200.0f, 3000.0f);
    // момент начала активной фазы удара (сек), Гвин c5370
    static const struct { int a; float t; } gwyn[] = {
        {3000, 0.367f}, {3001, 0.400f}, {3002, 0.467f}, {3003, 0.633f}, {3004, 0.600f}, {3005, 0.633f},
        {3008, 0.800f}, {3009, 0.567f}, {3010, 0.733f}, {3011, 0.900f}, {3012, 0.867f}, {3013, 0.500f},
        {3014, 1.000f}, {3015, 0.567f}, {3016, 0.667f}};
    for (auto& g : gwyn) c.hits[g.a] = g.t;
    // свои: anims=3006:1.233,3018:0.867  (ID:секунда начала удара); пустое значение ничего не меняет, -ID:0 убирает удар
    const std::string extra = ParryIni("anims", "");
    size_t i = 0;
    while (i < extra.size()) {
        size_t j = extra.find_first_of(",; ", i);
        if (j == std::string::npos) j = extra.size();
        if (j > i) {
            const std::string tok = extra.substr(i, j - i);
            const size_t k = tok.find(':');
            if (k != std::string::npos) {
                const int id = atoi(tok.substr(0, k).c_str());
                const float t = (float)atof(tok.c_str() + k + 1);
                if (id < 0) c.hits.erase(-id); else if (id > 0) c.hits[id] = t;
            }
        }
        i = j + 1;
    }
    g_pc = c;
}

// цепочка врага: свои ключи, иначе цепочка игрока без префикса «@world, 0x68»
Chain ParryEnemyChain(const char* ownKey, const char* playerKey) {
    char b[512]{};
    GetPrivateProfileStringA("offsets", ownKey, "", b, sizeof(b), Ini().c_str());
    Chain c = ParseChain(b);
    if (c.valid()) return c;
    GetPrivateProfileStringA("offsets", playerKey, "", b, sizeof(b), Ini().c_str());
    c = ParseChain(b);
    if (c.aob && c.v.size() >= 3 && c.v[1] == 0x68) { Chain r; r.v.assign(c.v.begin() + 2, c.v.end()); return r; }
    return Chain();
}
template <class T>
bool ReadEntityChain(uintptr_t ent, const Chain& c, T& out) {
    if (!c.valid() || c.aob) return false;
    uintptr_t a = ent + c.v[0];
    for (size_t i = 1; i < c.v.size(); ++i) {
        uintptr_t q = 0;
        if (!Peek64(a, q) || !q) return false;
        a = q + c.v[i];
    }
    return Rd(a, out);
}

DWORD WINAPI ParryThread(LPVOID) {
    const ParryCfg c = g_pc;
    INPUT in[2]{};
    const WORD scan = (WORD)MapVirtualKeyA((UINT)c.key, MAPVK_VK_TO_VSC);
    if (c.key) {
        in[0].type = INPUT_KEYBOARD; in[0].ki.wScan = scan; in[0].ki.dwFlags = KEYEVENTF_SCANCODE;
        SendInput(1, &in[0], sizeof(INPUT));
        Sleep(15);
    }
    if (c.mouse) {
        INPUT m{}; m.type = INPUT_MOUSE;
        m.mi.dwFlags = c.mouse == 2 ? MOUSEEVENTF_RIGHTDOWN : MOUSEEVENTF_LEFTDOWN;
        SendInput(1, &m, sizeof(INPUT));
        Sleep((DWORD)c.holdMs);
        m.mi.dwFlags = c.mouse == 2 ? MOUSEEVENTF_RIGHTUP : MOUSEEVENTF_LEFTUP;
        SendInput(1, &m, sizeof(INPUT));
    } else Sleep((DWORD)c.holdMs);
    if (c.key) {
        in[1].type = INPUT_KEYBOARD; in[1].ki.wScan = scan; in[1].ki.dwFlags = KEYEVENTF_SCANCODE | KEYEVENTF_KEYUP;
        SendInput(1, &in[1], sizeof(INPUT));
    }
    return 0;
}

void ParryTick(ULONGLONG now) {
    if (!Focused()) return;
    if (!g_pc.loaded) ParryLoad();
    const bool tg = g_pc.toggleKey && (GetAsyncKeyState(g_pc.toggleKey) & 0x8000);
    if (tg && !g_prevParryToggle) g_parryOn = !g_parryOn;
    g_prevParryToggle = tg;
    if (!g_parryOn) { g_parryState = 0; return; }
    if ((!g_eAnim.valid() || !g_eTime.valid()) && now >= g_chainTry) {
        g_chainTry = now + 2000;
        g_eAnim = ParryEnemyChain("enemy_anim_id", "anim_id");
        g_eTime = ParryEnemyChain("enemy_anim_time", "anim_time");
    }
    if (!g_eAnim.valid() || !g_eTime.valid()) { g_parryState = 1; return; }
    g_parryState = 2;
    if (now < g_parryNext || now < g_idleUntil) return;
    PeerView me;
    if (!CoopMyPosition(me)) return;
    std::vector<EnemyView> enemies;
    if (!WorldEnemyPositions(enemies)) return;
    for (const auto& e : enemies) {
        if (!e.ptr || !IsBoss(e)) continue;
        int32_t anim = -1;
        float t = 0;
        if (!ReadEntityChain(e.ptr, g_eAnim, anim) || !ReadEntityChain(e.ptr, g_eTime, t)) continue;
        ParryLatch& L = g_pLatch[e.ptr];
        if (anim != L.anim || t + 0.05f < L.t) L.fired = false;
        L.anim = anim; L.t = t;
        auto it = g_pc.hits.find(anim);
        if (it == g_pc.hits.end() || L.fired) continue;
        const float dx = e.x - me.x, dz = e.z - me.z;
        if (std::sqrt(dx * dx + dz * dz) > g_pc.rangeM) continue;
        const float trig = it->second - g_pc.leadMs / 1000.0f;
        if (t < trig || t > trig + g_pc.windowMs / 1000.0f) continue;
        L.fired = true;
        if (HANDLE h = CreateThread(nullptr, 0, ParryThread, nullptr, 0, nullptr)) CloseHandle(h);
        g_parryNext = now + (ULONGLONG)g_pc.cooldownMs;
        ++g_parryPresses;
        break;
    }
    if (g_pLatch.size() > 256) g_pLatch.clear();
}

} // namespace

// LoadCfg меняет g_cfg (внутри вектор цепочки), а читает его поток логики: перечитываем только в нём
void ExtrasReloadCfg() { g_reload = true; }
bool ExtrasDebugActive() { return g_dbgOn; }
bool ExtrasWantsFast() { return g_loaded ? ((g_enabled || g_parryOn) && CanRoll()) : true; }
bool ExtrasWantsPoll() { return !g_loaded || g_reload || !g_autoDone || CanRoll(); }
void ExtrasDrawDebug() {
    if (!g_dbgOn) return;
    DbgSnap sn;
    {
        std::lock_guard<std::mutex> l(g_dbgMx);
        sn = g_snap;
    }
    DrawDebugSnap(sn);
}
float ExtrasSpent() { return 0.0f; }
bool ExtrasNoDamageBuff() { return false; }

void ExtrasTick() {
    static ULONGLONG next=0;
    const ULONGLONG now=GetTickCount64();
    if (now<next) return;
    next=now+8;
    if (!g_base) g_base=(uintptr_t)GetModuleHandleA(nullptr);
    if (!g_loaded || g_reload.exchange(false)) { LoadCfg(); g_dbgOn = g_cfg.debugDraw; }
    AutoSetup(now);
    AutoRollTick(now);
    ParryTick(now);
}

uintptr_t ExtrasPlayerEntity() {
    const uintptr_t S = FindWorldChrStatic();
    uintptr_t W = 0, pl = 0;
    if (S && Peek64(S, W) && W && Peek64(W + 0x68, pl) && pl > 0x10000) return pl;
    return 0;
}

// Кнопка «Автопоиск координат» в калибраторе (U): не требует HP. Подбирает смещение по живому игроку и пишет цепочки.
std::string ExtrasAutoCoords() {
    g_mdDetected = -1;
    const uintptr_t pl = ExtrasPlayerEntity();
    if (!pl) {
        return FindWorldChrStatic() ? "Игрока в мире нет: зайдите в игру (не в меню) и повторите."
                                    : "Не найден WorldChrBase: сигнатура не подходит этой сборке (смотрите DSRMods\\enemy_scan.log).";
    }
    const int md = MapDataOffset();
    if (g_mdDetected.load() < 0) return "Не удалось подобрать смещение координат: по всем кандидатам игрок даёт неверные числа.";
    char b[96];
    auto put = [&](const char* key, const char* fmt) {
        snprintf(b, sizeof(b), fmt, md);
        WritePrivateProfileStringA("offsets", key, b, Ini().c_str());
    };
    put("pos_x", "@world, 0x68, 0x%X, 0x28, 0x10");
    put("angle", "@world, 0x68, 0x%X, 0x28, 0x4");
    put("enemy_x", "0x%X, 0x28, 0x10");
    put("enemy_y", "0x%X, 0x28, 0x14");
    put("enemy_z", "0x%X, 0x28, 0x18");
    put("enemy_angle", "0x%X, 0x28, 0x4");
    g_autoDone = false;
    g_forceRediscover = true;
    CombatReloadCfg();
    uintptr_t m = 0, pd = 0;
    float x = 0, y = 0, z = 0;
    if (Peek64(pl + md, m) && Peek64(m + 0x28, pd)) { PeekF(pd + 0x10, x); PeekF(pd + 0x14, y); PeekF(pd + 0x18, z); }
    snprintf(b, sizeof(b), "Готово: смещение 0x%X. Позиция игрока X=%.2f Y=%.2f Z=%.2f. Пройдите вперёд: числа должны меняться.", md, x, y, z);
    return b;
}

void ExtrasUI() {
    ImGui::Separator();
    ImGui::Text("Автоматический перекат: %s",g_enabled?"включён":"выключен");
    ImGui::TextDisabled("F9 / toggle_key — переключение. Геометрия атак приблизительная.");
    // Выбор профиля доступен прямо в окне U. Пустой профиль оставляет только геометрический прогноз.
    struct DodgeProfileOption { const char* id; const char* label; };
    static const DodgeProfileOption profiles[] = {
        {"", "Геометрический прогноз (без профиля)"},
        {"c2232", "Asylum Demon"},
        {"c2250", "Taurus Demon"},
        {"c5350", "Bell Gargoyles"},
        {"c2240", "Capra Demon"},
        {"c3230", "Moonlight Butterfly"},
        {"c5210", "Great Grey Wolf Sif"},
        {"c5260", "Gaping Dragon"},
        {"c5280", "Quelaag"},
        {"c5250", "Ceaseless Discharge"},
        {"c2320", "Iron Golem"},
        {"c5270", "Ornstein & Smough"},
        {"c5370", "Gwyn"}
    };
    int selectedProfile = 0;
    for (int i = 0; i < (int)(sizeof(profiles) / sizeof(profiles[0])); ++i) {
        if (g_cfg.dodgeProfile == profiles[i].id) { selectedProfile = i; break; }
    }
    const char* profileLabels[sizeof(profiles) / sizeof(profiles[0])]{};
    for (int i = 0; i < (int)(sizeof(profiles) / sizeof(profiles[0])); ++i) profileLabels[i] = profiles[i].label;
    ImGui::SetNextItemWidth(280.0f);
    if (ImGui::Combo("Профиль уворотов", &selectedProfile, profileLabels, (int)(sizeof(profiles) / sizeof(profiles[0])))) {
        WritePrivateProfileStringA("auto_roll", "dodge_profile", profiles[selectedProfile].id, Ini().c_str());
        ExtrasReloadCfg(); // перечитать конфиг и таблицу в потоке логики
    }
    ImGui::TextDisabled("Профиль можно менять здесь; изменения сохраняются в DSRCombat.ini.");
    const std::string dodgeStatus = GetDodgeStatus();
    ImGui::Text("Таблица уворотов: %s", dodgeStatus.c_str());
    ImGui::TextDisabled("Таблица + прогноз координат игрока/босса к моменту удара. При неопределённости перекат не отменяется.");
    ImGui::TextDisabled("dodge_lead_ms — запас до удара; dodge_projectiles=1 включает записи r. Направление только расширяет запас, не блокирует перекат.");
    {
        CombatSnapshot cs; { std::lock_guard<std::mutex> lk(g_uiMx); cs = g_snap; }
        if (cs.ok) {
            ImGui::Text("Игрок: X %.2f  Y %.2f  Z %.2f  взгляд %.0f°", cs.px, cs.py, cs.pz, cs.pyawDeg);
            ImGui::Text("Босс:  X %.2f  Y %.2f  Z %.2f  взгляд %.0f°", cs.bx, cs.by, cs.bz, cs.byawDeg);
            ImGui::Text("Дистанция %.2f м (по высоте %.2f)", cs.dist2d, cs.dy);
            ImGui::Text("Босс смотрит на игрока: %.0f° от прямого (%s). Игрок смотрит на босса: %.0f°",
                        cs.bossLooksAtPlayerDeg, cs.bossRelSideDeg < 0 ? "игрок левее" : "игрок правее", cs.playerLooksAtBossDeg);
            ImGui::TextDisabled("Встаньте перед боссом лицом к нему: оба угла «смотрит» должны быть близки к 0. Если нет, подберите facing_offset_deg.");
        } else {
            ImGui::TextDisabled("Координаты игрока/босса не читаются: нажмите «Автопоиск координат» (U) и пометьте босса NumPad 8.");
        }
    }
    if (g_cfg.bossesOnly) {
        ImGui::Text("Режим: только боссы. В списке боссов сейчас: %d (ручных меток: %d, entity ID прочитано: %d)",
                    g_bossInView.load(), g_markedCount.load(), g_idsRead.load());
        ImGui::TextDisabled("NumPad 8 — пометить/снять босса рядом, NumPad 7 — сбросить метки.");
        if (g_idsRead.load() == 0)
            ImGui::TextDisabled("enemy_id не задан: автоопределение по entity ID не работает, используйте ручную метку.");
        std::string st; { std::lock_guard<std::mutex> l(g_uiMx); st = g_uiStatus; }
        if (!st.empty()) ImGui::TextWrapped("%s", st.c_str());
    } else {
        ImGui::TextDisabled("Режим: все враги (bosses_only=0).");
    }
    ImGui::Separator();
    ImGui::Text("Авто-парирование боссов (Гвин): %s", g_parryOn ? "включено" : "выключено");
    ImGui::TextDisabled("F8 — переключение (по умолчанию выключено); работает на боссах из списка/отмеченных NumPad 8.");
    if (g_parryOn && g_parryState.load() == 1)
        ImGui::TextColored(ImVec4(1, 0.7f, 0.3f, 1), "Нет цепочек анимации врага: найдите anim_id и anim_time в калибраторе.");
    else if (g_parryOn)
        ImGui::TextDisabled("Нажатий парирования: %d (тайминги — parry_lead_ms в [auto_parry])", g_parryPresses.load());

}
