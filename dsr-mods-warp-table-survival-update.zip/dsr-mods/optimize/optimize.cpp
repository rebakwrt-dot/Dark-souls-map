// DSROptimize: лёгкие оптимизации рендера Dark Souls Remastered.
//  - ограничение анизотропной фильтрации (меньше нагрузка на GPU)
//  - пауза рендера, когда окно игры не в фокусе
//  - опциональное отключение VSync без изменения разрешения/эффектов
//  - необязательный точный лимитер кадров (fps_limit)
//  - путешествие между кострами с самого начала игры (выставляет флаг события «варп включён»)
#include <windows.h>

#include <cstdarg>
#include <cstring>
#include <cstdio>
#include <fstream>
#include <string>

#include "../common/dx11_hook.h"
#include "../common/mem.h"

static HMODULE g_self;
static int g_aniso = 2;
static int g_fps = 0;
static int g_fpsToggleValue = 30;  // на что переключает fps_toggle_key
static int g_fpsKey = 0x7A;        // F11
static bool g_prevFpsKey = false;
static bool g_bgSleep = true;
static bool g_disableVsync = false;
static ULONGLONG g_focusCheckAt = 0;
static bool g_isFocused = true;
static HANDLE g_timer = nullptr;
static LARGE_INTEGER g_freq, g_next;


// ---------- Путешествие между кострами с начала игры ----------
// В DS1 варп между кострами включается флагом события (по умолчанию 15). Флаги лежат в массиве битов,
// расположение бита считается по схеме из DSR-Gadget (группа/область/секция/номер).
static bool g_warp = true;
static std::vector<int> g_flags = {15};
static std::string g_flagAob = "48 8B 0D ? ? ? ? 99 33 C2 45 33 C0 2B C2 8D 50 F6";
static int g_flagDerefs = 2;          // сколько раз разыменовывать: [[static]+0] = 2, [static]+0 = 1
static std::string g_logPath;

static void Log(const char* fmt, ...) {
    if (g_logPath.empty()) return;
    FILE* f = fopen(g_logPath.c_str(), "a");
    if (!f) return;
    va_list a; va_start(a, fmt); vfprintf(f, fmt, a); va_end(a);
    fputc('\n', f); fclose(f);
}

static bool FlagBit(int id, int& offset, uint32_t& mask) {
    if (id < 0 || id > 99999999) return false;
    char s[16]; snprintf(s, sizeof(s), "%08d", id);
    static const struct { const char* k; int v; } groups[] = {{"0", 0x00000}, {"1", 0x00500}, {"5", 0x05F00}, {"6", 0x0B900}, {"7", 0x11300}};
    static const struct { const char* k; int v; } areas[] = {{"000", 0}, {"100", 1}, {"101", 2}, {"102", 3}, {"110", 4}, {"120", 5}, {"121", 6}, {"130", 7},
                                                             {"131", 8}, {"132", 9}, {"140", 10}, {"141", 11}, {"150", 12}, {"151", 13}, {"160", 14}, {"170", 15},
                                                             {"180", 16}, {"181", 17}};
    int g = -1, ar = -1;
    for (auto& x : groups) if (s[0] == x.k[0]) g = x.v;
    for (auto& x : areas) if (!strncmp(s + 1, x.k, 3)) ar = x.v;
    if (g < 0 || ar < 0) return false;
    int section = s[4] - '0';
    int number = atoi(s + 5);
    offset = g + ar * 0x500 + section * 128 + (number - number % 32) / 8;
    mask = 0x80000000u >> (number % 32);
    return true;
}

static std::vector<int> ParseAob(const std::string& s) {
    std::vector<int> r;
    size_t i = 0;
    while (i < s.size()) {
        while (i < s.size() && s[i] == ' ') ++i;
        size_t j = s.find(' ', i);
        if (j == std::string::npos) j = s.size();
        if (j > i) {
            std::string t = s.substr(i, j - i);
            r.push_back(t[0] == '?' ? -1 : (int)strtol(t.c_str(), nullptr, 16));
        }
        i = j + 1;
    }
    return r;
}

static uintptr_t FindFlagStatic() {
    static uintptr_t cached = 0;
    static ULONGLONG nextTry = 0;
    if (cached) return cached;
    const ULONGLONG now = GetTickCount64();
    if (now < nextTry) return 0;
    nextTry = now + 3000;
    std::vector<int> pat = ParseAob(g_flagAob);
    if (pat.size() < 8) return 0;
    const uintptr_t base = (uintptr_t)GetModuleHandleA(nullptr);
    const IMAGE_DOS_HEADER* dos = reinterpret_cast<const IMAGE_DOS_HEADER*>(base);
    if (!base || dos->e_magic != IMAGE_DOS_SIGNATURE) return 0;
    const IMAGE_NT_HEADERS* nt = reinterpret_cast<const IMAGE_NT_HEADERS*>(base + dos->e_lfanew);
    const uintptr_t end = base + nt->OptionalHeader.SizeOfImage;
    uintptr_t p = base;
    while (p < end) {
        MEMORY_BASIC_INFORMATION mbi{};
        if (!VirtualQuery(reinterpret_cast<void*>(p), &mbi, sizeof(mbi))) break;
        const uintptr_t rb = (uintptr_t)mbi.BaseAddress, re = rb + mbi.RegionSize;
        const bool exec = (mbi.Protect & (PAGE_EXECUTE_READ | PAGE_EXECUTE_READWRITE | PAGE_EXECUTE_WRITECOPY)) != 0;
        if (mbi.State == MEM_COMMIT && exec && !(mbi.Protect & (PAGE_GUARD | PAGE_NOACCESS))) {
            uintptr_t hit = ScanRegionForPattern(std::max(rb, base), std::min(re, end), pat.data(), pat.size());
            if (hit) {
                int32_t disp = 0;
                if (Rd(hit + 3, disp)) {
                    cached = hit + 7 + (intptr_t)disp;
                    Log("event flag static found: base+0x%llX", (unsigned long long)(cached - base));
                    return cached;
                }
            }
        }
        if (re <= p) break;
        p = re;
    }
    return 0;
}

static bool OrDword(uintptr_t a, uint32_t mask) {
    bool ok = false;
    __try {
        volatile uint32_t* v = reinterpret_cast<volatile uint32_t*>(a);
        if (!(*v & mask)) *v |= mask;
        ok = true;
    } __except (EXCEPTION_EXECUTE_HANDLER) {
    }
    return ok;
}

static void ApplyWarpFlags() {
    uintptr_t st = FindFlagStatic();
    if (!st) return;
    uintptr_t p = st;
    for (int i = 0; i < g_flagDerefs; ++i) {
        uintptr_t q = 0;
        if (!Rd(p, q) || !q) return;  // мир ещё не загружен
        p = q;
    }
    static bool logged = false;
    for (int id : g_flags) {
        int off; uint32_t mask;
        if (!FlagBit(id, off, mask)) continue;
        OrDword(p + off, mask);
    }
    if (!logged) { logged = true; Log("warp flags applied, array=%llX", (unsigned long long)p); }
}

static DWORD WINAPI WarpThread(LPVOID) {
    for (;;) {
        Sleep(1000);  // флаг пишем раз в секунду: после загрузки сохранения он мог сброситься
        if (g_warp) ApplyWarpFlags();
    }
}

static bool Focused() {
    const ULONGLONG now = GetTickCount64();
    if (now >= g_focusCheckAt) {
        HWND fg = GetForegroundWindow();
        DWORD pid = 0;
        if (fg) GetWindowThreadProcessId(fg, &pid);
        g_isFocused = (pid == GetCurrentProcessId());
        g_focusCheckAt = now + 250; // проверка фокуса 4 раза/с, а не на каждом кадре
    }
    return g_isFocused;
}

static void OnPresent(IDXGISwapChain*, UINT& sync) {
    // Не меняем графические эффекты или разрешение; убираем ожидание VSync.
    // Может дать больше FPS, если игра/драйвер ограничивали кадры VSync.
    if (g_disableVsync) sync = 0;
}

static void OnSampler(D3D11_SAMPLER_DESC& d) {
    // 0x40 — бит анизотропной фильтрации в D3D11_FILTER
    if (g_aniso > 0 && (d.Filter & 0x40) && d.MaxAnisotropy > (UINT)g_aniso) d.MaxAnisotropy = (UINT)g_aniso;
}

static void OnAfterPresent(IDXGISwapChain*) {
    if (g_bgSleep && !Focused()) Sleep(50);
    // клавиша переключения лимита кадров: выкл <-> fps_toggle_value (по умолчанию 30)
    bool k = g_fpsKey && Focused() && (GetAsyncKeyState(g_fpsKey) & 0x8000);
    if (k && !g_prevFpsKey) {
        g_fps = g_fps > 0 ? 0 : g_fpsToggleValue;
        g_next.QuadPart = 0;
    }
    g_prevFpsKey = k;
    if (g_fps <= 0) return;

    LARGE_INTEGER now;
    QueryPerformanceCounter(&now);
    long long interval = g_freq.QuadPart / g_fps;
    if (g_next.QuadPart == 0) g_next.QuadPart = now.QuadPart;
    g_next.QuadPart += interval;
    if (now.QuadPart > g_next.QuadPart + interval * 2) {  // отстали — сбрасываем
        g_next.QuadPart = now.QuadPart;
        return;
    }
    while (now.QuadPart < g_next.QuadPart) {
        double remainMs = (double)(g_next.QuadPart - now.QuadPart) * 1000.0 / (double)g_freq.QuadPart;
        if (remainMs > 2.0 && g_timer) {
            LARGE_INTEGER due;
            due.QuadPart = -(LONGLONG)((remainMs - 1.5) * 10000.0);
            SetWaitableTimer(g_timer, &due, 0, nullptr, nullptr, FALSE);
            WaitForSingleObject(g_timer, 20);
        } else {
            // Не крутить ядро в busy-wait: уступаем квант CPU.
            Sleep(1);
        }
        QueryPerformanceCounter(&now);
    }
}

static DWORD WINAPI Init(LPVOID) {
    char p[MAX_PATH];
    GetModuleFileNameA(g_self, p, MAX_PATH);
    std::string ini = p;
    ini = ini.substr(0, ini.find_last_of("\\/") + 1) + "DSROptimize.ini";
    if (GetFileAttributesA(ini.c_str()) == INVALID_FILE_ATTRIBUTES) {
        std::ofstream f(ini);
        f << "[optimize]\n"
             "; Максимум анизотропной фильтрации (0 = не трогать, 1/2/4/8/16)\n"
             "max_anisotropy=2\n"
             "; Отключить ожидание VSync (по умолчанию 0: DSR привязан к 60 кадрам, без VSync возможны рывки/ускорение; 1 только на свой риск)\n"
             "disable_vsync=0\n"
             "; Точный лимит FPS при запуске (0 = выключено, 30 = 30 кадров)\n"
             "fps_limit=30\n"
             "; Клавиша переключения лимита (VK-код, 0x7A = F11, 0 = нет) и значение лимита при включении\n"
             "fps_toggle_key=0x7A\n"
             "fps_toggle_value=30\n"
             "; Снижать нагрузку, когда окно игры не в фокусе\n"
             "background_sleep=1\n"
             "\n[bonfire_warp]\n"
             "; ОПАСНО: принудительно ставит флаг события (15) с начала игры. Этот флаг связан со сценарием, и при его включении возможны сломанные квесты и ложная концовка. По умолчанию выключено.\n"
             "force_flag_enabled=0\n"
             "; Флаг события «варп включён» (15) и любые дополнительные флаги через запятую\n"
             "flags=15\n"
             "; Сигнатура функции событий (? = любой байт) и число разыменований указателя\n"
             "flag_aob=48 8B 0D ? ? ? ? 99 33 C2 45 33 C0 2B C2 8D 50 F6\n"
             "flag_derefs=2\n";
    }
    g_aniso = GetPrivateProfileIntA("optimize", "max_anisotropy", 2, ini.c_str());
    if (g_aniso != 0 && g_aniso != 1 && g_aniso != 2 && g_aniso != 4 && g_aniso != 8 && g_aniso != 16)
        g_aniso = 2;
    g_fps = GetPrivateProfileIntA("optimize", "fps_limit", 0, ini.c_str());
    if (g_fps < 0 || g_fps > 240) g_fps = 0;
    g_fpsToggleValue = GetPrivateProfileIntA("optimize", "fps_toggle_value", 30, ini.c_str());
    if (g_fpsToggleValue < 10 || g_fpsToggleValue > 240) g_fpsToggleValue = 30;
    char kb[32] = {};
    GetPrivateProfileStringA("optimize", "fps_toggle_key", "0x7A", kb, sizeof(kb), ini.c_str());
    g_fpsKey = (int)strtol(kb, nullptr, 0);
    g_bgSleep = GetPrivateProfileIntA("optimize", "background_sleep", 1, ini.c_str()) != 0;
    g_disableVsync = GetPrivateProfileIntA("optimize", "disable_vsync", 0, ini.c_str()) != 0;
    g_logPath = ini.substr(0, ini.find_last_of("\\/") + 1) + "DSROptimize.warp.log";
    g_warp = GetPrivateProfileIntA("bonfire_warp", "force_flag_enabled", 0, ini.c_str()) != 0;
    g_flagDerefs = GetPrivateProfileIntA("bonfire_warp", "flag_derefs", 2, ini.c_str());
    if (g_flagDerefs < 1 || g_flagDerefs > 3) g_flagDerefs = 2;
    char fb[512] = {};
    GetPrivateProfileStringA("bonfire_warp", "flags", "15", fb, sizeof(fb), ini.c_str());
    g_flags.clear();
    for (char* t = strtok(fb, ", "); t; t = strtok(nullptr, ", ")) g_flags.push_back((int)strtol(t, nullptr, 10));
    char ab[256] = {};
    GetPrivateProfileStringA("bonfire_warp", "flag_aob", g_flagAob.c_str(), ab, sizeof(ab), ini.c_str());
    if (ab[0]) g_flagAob = ab;
    if (g_warp) CreateThread(nullptr, 0, WarpThread, nullptr, 0, nullptr);
    QueryPerformanceFrequency(&g_freq);
    // таймер нужен всегда: лимит можно включить клавишей уже в игре
    g_timer = CreateWaitableTimerExW(nullptr, nullptr, CREATE_WAITABLE_TIMER_HIGH_RESOLUTION, TIMER_ALL_ACCESS);

    dx11::Callbacks cb;
    cb.onPresent = OnPresent;
    cb.onAfterPresent = OnAfterPresent;
    cb.onCreateSampler = OnSampler;
    dx11::Install(cb);
    HANDLE ready = CreateEventA(nullptr, TRUE, FALSE, "Local\\DSRMods_DSROptimize_Ready");
    if (ready) { SetEvent(ready); CloseHandle(ready); }
    return 0;
}

BOOL APIENTRY DllMain(HMODULE m, DWORD reason, LPVOID) {
    if (reason == DLL_PROCESS_ATTACH) {
        g_self = m;
        DisableThreadLibraryCalls(m);
        CreateThread(nullptr, 0, Init, nullptr, 0, nullptr);
    }
    return TRUE;
}
