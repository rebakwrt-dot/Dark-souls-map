#define _CRT_SECURE_NO_WARNINGS
// DSRCombat: облегчённая оболочка для калибратора и кооператива.
// Боевые личные функции, кроме авто-переката (extras.cpp), отключены.
#include <windows.h>
#include <string>

#include "combat.h"

namespace {
HMODULE g_self = nullptr;

DWORD WINAPI Start(LPVOID) {
    // Калибратор нужен для настройки цепочек памяти, используемых авто-перекатом
    // и LAN-кооперативом. Сам цикл кооператива запускается в CoopStart().
    CalibStart(g_self);
    CoopStart();

    HANDLE ready = CreateEventA(nullptr, TRUE, FALSE, "Local\\DSRMods_DSRCombat_Ready");
    if (ready) {
        SetEvent(ready);
        CloseHandle(ready);
    }
    return 0;
}
}

std::string CombatIniPath() {
    char path[MAX_PATH]{};
    GetModuleFileNameA(g_self, path, MAX_PATH);
    std::string value = path;
    return value.substr(0, value.find_last_of("\\/") + 1) + "DSRCombat.ini";
}

void CombatReloadCfg() { CoopReloadCfg(); }

BOOL APIENTRY DllMain(HMODULE module, DWORD reason, LPVOID) {
    if (reason == DLL_PROCESS_ATTACH) {
        g_self = module;
        DisableThreadLibraryCalls(module);
        HANDLE thread = CreateThread(nullptr, 0, Start, nullptr, 0, nullptr);
        if (thread) CloseHandle(thread);
    }
    return TRUE;
}
