// Калибратор: оверлей поверх игры (клавиша U), упрощённый «Cheat Engine» только для чтения.
// Ищет значения в памяти (точное / изменилось / больше / меньше), по кнопке «Это оно»
// сам находит цепочку указателей от статической памяти exe и записывает её в DSRCombat.ini.
// Значения в игре калибратор НЕ меняет.
#define _CRT_SECURE_NO_WARNINGS
#include <windows.h>
#include <d3d11.h>
#include <dxgi.h>

#include <algorithm>
#include <atomic>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <mutex>
#include <string>
#include <thread>
#include <vector>

#include "backends/imgui_impl_dx11.h"
#include "backends/imgui_impl_win32.h"
#include "imgui.h"

#include "../common/dx11_hook.h"
#include "../common/mem.h"
#include "combat.h"

extern IMGUI_IMPL_API LRESULT ImGui_ImplWin32_WndProcHandler(HWND, UINT, WPARAM, LPARAM);

namespace {

// Адреса в наших структурах хранятся «замаскированными», чтобы сканер указателей
// не находил собственные векторы как ложные указатели.
constexpr uint64_t KEY = 0xA5A5A5A5A5A5A5A5ull;
inline uint64_t Enc(uintptr_t a) { return (uint64_t)a ^ KEY; }
inline uintptr_t Dec(uint64_t e) { return (uintptr_t)(e ^ KEY); }

enum class Type { I32, F32 };
enum class Mode { Exact, Changed, Unchanged, Inc, Dec };

struct Hit {
    uint64_t a;
    uint32_t prev;
};

struct Field {
    const char* key;
    const char* label;
    Type t;
    std::string chain;
    const char* hint = "";
};

Field F[] = {
    {"hp", "HP", Type::I32, ""},
    {"max_hp", "Макс. HP", Type::I32, ""},
    {"estus", "Эстус (кол-во)", Type::I32, ""},
    {"stamina", "Стамина", Type::I32, ""},
    {"anim_id", "ID анимации", Type::I32, ""},
    {"anim_time", "Время анимации (сек)", Type::F32, ""},
    {"pos_x", "Позиция X (Y и Z идут следом)", Type::F32, "",
     "Лучше кнопка «Найти позицию» ниже."},
    {"angle", "Угол поворота (рад)", Type::F32, "", "Кнопка «Найти угол» ниже (поворот на месте)."},
    {"area_id", "ID области (карта)", Type::I32, "",
     "Нужен, чтобы цепь не работала между разными областями. Скан: значение, сменить локацию, «Изменилось»."},
    {"parry_success", "Парри удалось (флаг/состояние)", Type::I32, "",
     "Скан «Не менялось» в покое, парируйте врага -> «Изменилось», дальше в покое -> «Не менялось»."},
    {"atk_right", "Атака (AR) правая рука", Type::I32, "", "Число AR с экрана персонажа. Меняйте оружие/улучшение для сужения."},
    {"atk_left", "Атака (AR) левая рука", Type::I32, "", "То же для левой руки."},
    {"dmg_mult", "Множитель урона (если найдёте)", Type::F32, "", "Необязательно."},
    {"souls_popup", "Попап душ: число (+N)", Type::I32, "",
     "Подберите души, пока попап на экране, введите показанное число. НЕ то, что у вас на счётчике душ!"},
    {"souls_popup_timer", "Попап душ: таймер показа", Type::F32, "",
     "Необязательно. Во время показа попапа «Меньше», когда исчез — «Не менялось»."},
    {"talk_state", "Диалог с NPC: состояние", Type::I32, "",
     "В покое 0 -> «Такое же» (0). Откройте диалог -> «Изменилось». Закройте -> «Такое же» (0)."},
};

// F[].chain пишет фоновый поток поиска и читает UI: доступ только через эти функции
std::mutex g_chMx;
std::string ChainStr(int i) {
    std::lock_guard<std::mutex> l(g_chMx);
    return F[i].chain;
}
void SetChainStr(int i, const std::string& s) {
    std::lock_guard<std::mutex> l(g_chMx);
    F[i].chain = s;
}
enum { I_HP, I_MAXHP, I_ESTUS, I_STAM, I_ANIM, I_ATIME, I_POSX, I_ANGLE };
constexpr int NF = sizeof(F) / sizeof(F[0]);

HMODULE g_self;
bool g_init = false, g_open = false, g_prevU = false;
HWND g_hwnd;
ID3D11Device* g_dev;
ID3D11DeviceContext* g_ctx;
WNDPROC g_oldProc;

std::vector<Hit> g_hits;
std::atomic<bool> g_busy{false};
std::atomic<float> g_progress{0};
std::mutex g_msx;
std::string g_status = "Выберите величину, введите её текущее значение и нажмите «Первый скан».";

int g_sel = 0, g_depth = 4, g_maxOff = 0x400;
char g_val[32] = "";

void SetStatus(const std::string& s) {
    std::lock_guard<std::mutex> l(g_msx);
    g_status = s;
}
std::string GetStatus() {
    std::lock_guard<std::mutex> l(g_msx);
    return g_status;
}

bool ReadU32(uintptr_t a, uint32_t& v) {
    SIZE_T got = 0;
    return ReadProcessMemory(GetCurrentProcess(), (LPCVOID)a, &v, 4, &got) && got == 4;
}

std::vector<std::pair<uintptr_t, size_t>> Regions() {
    std::vector<std::pair<uintptr_t, size_t>> r;
    SYSTEM_INFO si;
    GetSystemInfo(&si);
    uintptr_t a = (uintptr_t)si.lpMinimumApplicationAddress, end = (uintptr_t)si.lpMaximumApplicationAddress;
    MEMORY_BASIC_INFORMATION mbi;
    const DWORD wr = PAGE_READWRITE | PAGE_WRITECOPY | PAGE_EXECUTE_READWRITE | PAGE_EXECUTE_WRITECOPY;
    while (a < end && VirtualQuery((LPCVOID)a, &mbi, sizeof(mbi))) {
        if (mbi.State == MEM_COMMIT && mbi.Type != MEM_MAPPED && !(mbi.Protect & (PAGE_GUARD | PAGE_NOACCESS)) &&
            (mbi.Protect & wr))
            r.push_back({(uintptr_t)mbi.BaseAddress, (size_t)mbi.RegionSize});
        a = (uintptr_t)mbi.BaseAddress + mbi.RegionSize;
    }
    return r;
}

// fn(адрес_начала_куска, данные, размер) -> false = остановить
template <class Fn>
void ForEachMem(const std::vector<std::pair<uintptr_t, size_t>>& regs, Fn fn) {
    size_t total = 0, done = 0;
    for (auto& r : regs) total += r.second;
    if (!total) return;
    std::vector<uint8_t> buf(1 << 20);
    uintptr_t b0 = (uintptr_t)buf.data(), b1 = b0 + buf.size();
    for (auto& r : regs) {
        for (size_t off = 0; off < r.second; off += buf.size()) {
            size_t n = std::min(buf.size(), r.second - off);
            uintptr_t a = r.first + off;
            done += n;
            g_progress = (float)done / (float)total;
            if (a < b1 && a + n > b0) continue;  // не сканируем собственный буфер
            SIZE_T got = 0;
            ReadProcessMemory(GetCurrentProcess(), (LPCVOID)a, buf.data(), n, &got);
            if (got && !fn(a, buf.data(), (size_t)got)) return;
        }
    }
}

bool Cmp(Mode m, Type t, uint32_t prev, uint32_t cur, double val) {
    if (t == Type::I32) {
        int32_t p = (int32_t)prev, c = (int32_t)cur;
        switch (m) {
            case Mode::Exact: return c == (int32_t)val;
            case Mode::Changed: return c != p;
            case Mode::Unchanged: return c == p;
            case Mode::Inc: return c > p;
            case Mode::Dec: return c < p;
        }
    } else {
        float p, c;
        memcpy(&p, &prev, 4);
        memcpy(&c, &cur, 4);
        if (!std::isfinite(c)) return false;
        switch (m) {
            case Mode::Exact: return std::fabs(c - (float)val) <= 0.0005f;
            case Mode::Changed: return c != p;
            case Mode::Unchanged: return c == p;
            case Mode::Inc: return c > p;
            case Mode::Dec: return c < p;
        }
    }
    return false;
}

constexpr size_t MAXHITS = 4000000;
std::atomic<bool> g_trunc{false};

void FirstScan(Type t, double val) {
    std::vector<Hit> out;
    bool over = false;
    ForEachMem(Regions(), [&](uintptr_t base, const uint8_t* b, size_t n) {
        for (size_t i = 0; i + 4 <= n; i += 4) {
            uint32_t raw;
            memcpy(&raw, b + i, 4);
            if (Cmp(Mode::Exact, t, 0, raw, val)) {
                out.push_back({Enc(base + i), raw});
                if (out.size() > MAXHITS) { over = true; return false; }
            }
        }
        return true;
    });
    if (over) {
        out.clear();
        SetStatus("Слишком много совпадений. Возьмите более редкое значение (напр. HP не 100, а текущее точное).");
    } else {
        SetStatus("Найдено: " + std::to_string(out.size()) + ". Измените величину в игре и сделайте «Следующий скан».");
    }
    g_hits.swap(out);
}

void AroundScan(uintptr_t center, uintptr_t span) {
    std::vector<Hit> out;
    uintptr_t lo = (center - span) & ~3ull, hi = center + span;
    for (uintptr_t a = lo; a < hi; a += 4) {
        uint32_t v;
        if (ReadU32(a, v)) out.push_back({Enc(a), v});
    }
    SetStatus("Кандидатов рядом: " + std::to_string(out.size()) + ". Делайте «Следующий скан» (изменилось/больше/меньше).");
    g_hits.swap(out);
}

void NextScan(Mode m, Type t, double val) {
    std::vector<Hit> keep;
    keep.reserve(g_hits.size() / 4 + 16);
    size_t i = 0;
    for (auto& h : g_hits) {
        uint32_t cur;
        if (ReadU32(Dec(h.a), cur) && Cmp(m, t, h.prev, cur, val)) {
            Hit n = h;
            n.prev = cur;
            keep.push_back(n);
        }
        g_progress = (float)(++i) / (float)g_hits.size();
    }
    g_hits.swap(keep);
    SetStatus("Осталось: " + std::to_string(g_hits.size()) + (g_hits.size() <= 15 ? ". Выберите нужный и нажмите «Это оно»." : "."));
}

// Поиск цепочки указателей от статической памяти exe до адреса A.
bool g_truncated = false;

bool PtrScan(uintptr_t A, int maxDepth, uintptr_t maxOff, std::string& out) {
    g_truncated = false;
    uintptr_t base = (uintptr_t)GetModuleHandleA(nullptr);
    auto* nt = (IMAGE_NT_HEADERS*)(base + ((IMAGE_DOS_HEADER*)base)->e_lfanew);
    uintptr_t imgEnd = base + nt->OptionalHeader.SizeOfImage;

    struct Node { uint64_t slot; uint32_t off; int parent; };
    std::vector<Node> nodes;
    nodes.push_back({Enc(A), 0, -1});
    size_t lb = 0, le = 1;
    const size_t CAP = 400000;
    g_trunc = false;

    for (int d = 1; d <= maxDepth; ++d) {
        SetStatus("Поиск указателей, уровень " + std::to_string(d) + "/" + std::to_string(maxDepth) + "...");
        std::vector<std::pair<uint64_t, int>> T;
        for (size_t i = lb; i < le; ++i) T.push_back({(uint64_t)Dec(nodes[i].slot), (int)i});
        std::sort(T.begin(), T.end());
        uint64_t minT = T.front().first, maxT = T.back().first;
        uintptr_t tlo = (uintptr_t)T.data(), thi = tlo + T.size() * sizeof(T[0]);
        std::vector<Node> nn;
        nn.reserve(1024);

        ForEachMem(Regions(), [&](uintptr_t cb, const uint8_t* b, size_t n) {
            for (size_t i = 0; i + 8 <= n; i += 8) {
                uint64_t v;
                memcpy(&v, b + i, 8);
                if (v > maxT || v + maxOff < minT) continue;
                uintptr_t slot = cb + i;
                if (slot >= tlo && slot < thi) continue;
                auto it = std::lower_bound(T.begin(), T.end(), v,
                                           [](const std::pair<uint64_t, int>& p, uint64_t x) { return p.first < x; });
                if (it == T.end() || it->first - v > maxOff) continue;
                nn.push_back({Enc(slot), (uint32_t)(it->first - v), it->second});
                if (nn.size() >= CAP) { g_trunc = true; return false; }
            }
            return true;
        });

        for (auto& x : nn) {
            uintptr_t slot = Dec(x.slot);
            if (slot >= base && slot < imgEnd) {
                std::vector<uint32_t> offs{x.off};
                int p = x.parent;
                while (nodes[p].parent != -1) { offs.push_back(nodes[p].off); p = nodes[p].parent; }
                char buf[64];
                snprintf(buf, sizeof(buf), "0x%llX", (unsigned long long)(slot - base));
                out = buf;
                for (uint32_t o : offs) { snprintf(buf, sizeof(buf), ", 0x%X", o); out += buf; }
                return true;
            }
        }
        if (nn.empty()) break;
        lb = le;
        nodes.insert(nodes.end(), nn.begin(), nn.end());
        le = nodes.size();
    }
    return false;
}

void AssignAndFind(int fi, uintptr_t addr) {
    std::string chain;
    if (PtrScan(addr, g_depth, (uintptr_t)g_maxOff, chain)) {
        // проверка: цепочка должна приводить обратно к найденному адресу
        Chain c = ParseChain(chain);
        uintptr_t back = 0;
        bool ok = Resolve(c, (uintptr_t)GetModuleHandleA(nullptr), back) && back == addr;
        if (!ok) {
            SetStatus(std::string(F[fi].label) + ": найденная цепочка не прошла проверку и НЕ сохранена. Повторите поиск.");
            return;
        }
        SetChainStr(fi, chain);
        WritePrivateProfileStringA("offsets", F[fi].key, chain.c_str(), CombatIniPath().c_str());
        CombatReloadCfg();
        SetStatus(std::string(F[fi].label) + ": цепочка сохранена: " + chain);
    } else {
        SetStatus(std::string(F[fi].label) +
                  (g_truncated ? ": поиск оборван из-за лимита узлов, цепочка может быть пропущена. Возьмите меньшую глубину/смещение или найдите значение заново."
                               : ": статическая цепочка не найдена. Увеличьте глубину/макс. смещение и повторите, либо найдите значение заново."));
    }
}

template <class Fn>
void Async(Fn fn) {
    if (g_busy) return;
    g_busy = true;
    g_progress = 0;
    std::thread([fn]() {
        fn();
        g_busy = false;
    }).detach();
}

// ---------------------------------------------------------------- UI
std::string CurVal(int fi) {
    Chain c = ParseChain(ChainStr(fi));
    if (!c.valid()) return "-";
    uintptr_t base = (uintptr_t)GetModuleHandleA(nullptr);
    char b[32];
    if (F[fi].t == Type::I32) {
        int32_t v;
        if (!ReadChain(c, base, v)) return "ошибка";
        snprintf(b, sizeof(b), "%d", v);
    } else {
        float v;
        if (!ReadChain(c, base, v)) return "ошибка";
        snprintf(b, sizeof(b), "%.3f", v);
    }
    return b;
}

// ---------- Поиск позиции/угла: снимки до и после движения ----------
struct FSnap { std::vector<std::pair<uintptr_t, float>> v; };
FSnap g_fa;
bool g_haveA = false;
int g_up = 2;
std::vector<std::pair<uintptr_t, float>> g_fcand;  // адрес, оценка
bool g_fAngle = false;

bool EntityPtr(uintptr_t& E) {
    for (int k : {I_HP, I_ANIM, I_STAM}) {
        Chain c = ParseChain(ChainStr(k));
        if (c.v.size() <= (size_t)g_up) continue;
        c.v.resize(c.v.size() - g_up);
        uintptr_t slot = 0;
        if (Resolve(c, (uintptr_t)GetModuleHandleA(nullptr), slot) && Rd(slot, E) && E > 0x10000) return true;
    }
    E = ExtrasPlayerEntity();  // HP не задан: берём игрока напрямую из мира
    return E > 0x10000;
}

bool TakeSnap(FSnap& s) {
    s.v.clear();
    uintptr_t E = 0;
    if (!EntityPtr(E)) return false;
    auto add = [&](uintptr_t b, size_t bytes) {
        for (size_t o = 0; o < bytes; o += 4) {
            uint32_t u;
            if (!ReadU32(b + o, u)) break;
            float f;
            memcpy(&f, &u, 4);
            s.v.push_back({b + o, f});
        }
    };
    add(E, 0x300);
    for (size_t o = 0; o < 0x600; o += 8) {
        uintptr_t q = 0;
        if (!Rd(E + o, q)) break;
        if (q < 0x10000 || q > 0x7FFFFFFFFFFFull || q == E) continue;
        add(q, 0x300);
    }
    return !s.v.empty();
}

void CompareSnap(bool angle) {
    FSnap b;
    if (!TakeSnap(b)) { SetStatus("Игрока не найдено: зайдите в мир (не меню) или задайте HP."); return; }
    std::vector<std::pair<uintptr_t, float>> A = g_fa.v, B = b.v;
    auto cmp = [](const std::pair<uintptr_t, float>& x, const std::pair<uintptr_t, float>& y) { return x.first < y.first; };
    std::sort(A.begin(), A.end(), cmp);
    std::sort(B.begin(), B.end(), cmp);
    auto find = [&](const std::vector<std::pair<uintptr_t, float>>& V, uintptr_t a, float& out) {
        auto it = std::lower_bound(V.begin(), V.end(), std::make_pair(a, 0.0f), cmp);
        if (it == V.end() || it->first != a) return false;
        out = it->second;
        return true;
    };
    g_fcand.clear();
    g_fAngle = angle;
    for (auto& e : B) {
        float a0;
        if (!find(A, e.first, a0) || !std::isfinite(e.second) || !std::isfinite(a0)) continue;
        if (angle) {
            if (std::fabs(a0) < 3.3f && std::fabs(e.second) < 3.3f && std::fabs(e.second - a0) > 0.4f)
                g_fcand.push_back({e.first, std::fabs(e.second - a0)});
        } else {
            float ay, az, by, bz, a1, a2;
            if (!find(A, e.first + 4, a1) || !find(A, e.first + 8, a2) || !find(B, e.first + 4, by) || !find(B, e.first + 8, bz)) continue;
            ay = a1; az = a2;
            if (!std::isfinite(by) || !std::isfinite(bz) || !std::isfinite(ay) || !std::isfinite(az)) continue;
            if (std::fabs(e.second) > 1e5f || std::fabs(bz) > 1e5f) continue;
            float h = std::hypot(e.second - a0, bz - az), dy = std::fabs(by - ay);
            if (h > 0.5f && h < 80.0f && dy < 0.5f * h + 0.3f) g_fcand.push_back({e.first, h});
        }
    }
    std::sort(g_fcand.begin(), g_fcand.end(), [](const auto& x, const auto& y) { return x.second > y.second; });
    if (g_fcand.size() > 8) g_fcand.resize(8);
    SetStatus(g_fcand.empty() ? "Кандидатов нет: проверьте «уровней вверх» (2-3) и что движение было достаточным."
                              : "Кандидаты ниже. Реальная позиция меняется на величину вашего пути; проверьте и нажмите «Это оно».");
}

void DrawFinder(bool busy) {
    ImGui::Separator();
    ImGui::Text("Поиск позиции / угла (от сущности игрока)");
    ImGui::SliderInt("Уровней вверх от HP", &g_up, 1, 3);
    ImGui::BeginDisabled(busy);
    if (ImGui::Button("Автопоиск координат (без HP)")) {
        const std::string r = ExtrasAutoCoords();
        // подхватываем записанные цепочки в таблицу калибратора
        char buf[512];
        for (int i : {I_POSX, I_ANGLE}) {
            buf[0] = 0;
            GetPrivateProfileStringA("offsets", F[i].key, "", buf, sizeof(buf), CombatIniPath().c_str());
            SetChainStr(i, buf);
        }
        SetStatus(r);
    }
    ImGui::TextDisabled("Быстрее всего: нажмите кнопку выше. Ручной поиск ниже нужен, только если она не сработала.");
    if (ImGui::Button("Снимок A (стойте)")) {
        g_haveA = TakeSnap(g_fa);
        SetStatus(g_haveA ? "Снимок A сделан. Пройдите ~3-5 м (или повернитесь на месте для угла), затем сравните." : "Не нашёл игрока: зайдите в мир (не меню) или задайте HP.");
    }
    if (g_haveA) {
        ImGui::SameLine();
        if (ImGui::Button("Найти позицию")) CompareSnap(false);
        ImGui::SameLine();
        if (ImGui::Button("Найти угол")) CompareSnap(true);
    }
    for (size_t i = 0; i < g_fcand.size(); ++i) {
        uintptr_t a = g_fcand[i].first;
        uint32_t u = 0;
        ReadU32(a, u);
        float f;
        memcpy(&f, &u, 4);
        ImGui::PushID(1000 + (int)i);
        ImGui::Text("%p  = %.3f  (изм. %.2f)", (void*)a, f, g_fcand[i].second);
        ImGui::SameLine();
        if (ImGui::SmallButton("Это оно")) {
            int fi = g_fAngle ? I_ANGLE : I_POSX;
            Async([=]() { AssignAndFind(fi, a); });
        }
        ImGui::PopID();
    }
    ImGui::EndDisabled();
}

void DrawUI() {
    ImGui::SetNextWindowPos(ImVec2(30, 30), ImGuiCond_FirstUseEver);
    ImGui::SetNextWindowSize(ImVec2(580, 720), ImGuiCond_FirstUseEver);
    ImGui::Begin("Калибратор DSRCombat (U — закрыть)");
    bool busy = g_busy;

    ImGui::TextWrapped("%s", GetStatus().c_str());
    if (busy) ImGui::ProgressBar(g_progress, ImVec2(-1, 0));
    ImGui::Separator();

    ImGui::Text("Что ищем:");
    ImGui::SameLine();
    const char* cur = F[g_sel].label;
    if (ImGui::BeginCombo("##f", cur)) {
        for (int i = 0; i < NF; ++i)
            if (ImGui::Selectable(F[i].label, i == g_sel) && !busy) { g_sel = i; g_hits.clear(); }
        ImGui::EndCombo();
    }
    if (F[g_sel].hint[0]) ImGui::TextDisabled("%s", F[g_sel].hint);
    ImGui::InputText("Значение", g_val, sizeof(g_val), ImGuiInputTextFlags_CharsDecimal);
    double val = atof(g_val);
    Type t = F[g_sel].t;

    ImGui::BeginDisabled(busy);
    if (ImGui::Button("Первый скан (точное значение)")) Async([=]() { FirstScan(t, val); });
    ImGui::SameLine();
    if (ImGui::Button("Сброс") && !busy) { g_hits.clear(); SetStatus("Сброшено."); }
    if (!busy && !g_hits.empty()) {
        ImGui::Text("Следующий скан:");
        if (ImGui::Button("Такое же")) Async([=]() { NextScan(Mode::Exact, t, val); });
        ImGui::SameLine();
        if (ImGui::Button("Изменилось")) Async([=]() { NextScan(Mode::Changed, t, val); });
        ImGui::SameLine();
        if (ImGui::Button("Не менялось")) Async([=]() { NextScan(Mode::Unchanged, t, val); });
        ImGui::SameLine();
        if (ImGui::Button("Больше")) Async([=]() { NextScan(Mode::Inc, t, val); });
        ImGui::SameLine();
        if (ImGui::Button("Меньше")) Async([=]() { NextScan(Mode::Dec, t, val); });
    }
    // время анимации ищем рядом с ID анимации: оба лежат в одной структуре
    if (F[g_sel].t == Type::F32 && !ChainStr(4).empty()) {
        static uintptr_t aroundAddr = 0;
        static ULONGLONG nextAround = 0;
        if (GetTickCount64() >= nextAround) {
            nextAround = GetTickCount64() + 250;
            Chain c = ParseChain(ChainStr(4));
            if (!Resolve(c, (uintptr_t)GetModuleHandleA(nullptr), aroundAddr)) aroundAddr = 0;
        }
        if (aroundAddr && ImGui::Button("Искать рядом с ID анимации (±0x400)")) {
            const uintptr_t a = aroundAddr;
            Async([=]() { AroundScan(a, 0x400); });
        }
    }
    ImGui::EndDisabled();

    if (!g_hits.empty() && !busy && g_hits.size() <= 30) {
        ImGui::Separator();
        for (size_t i = 0; i < g_hits.size(); ++i) {
            uintptr_t a = Dec(g_hits[i].a);
            uint32_t v = 0;
            ReadU32(a, v);
            ImGui::PushID((int)i);
            if (t == Type::I32) ImGui::Text("%p  = %d", (void*)a, (int32_t)v);
            else { float f; memcpy(&f, &v, 4); ImGui::Text("%p  = %.3f", (void*)a, f); }
            ImGui::SameLine();
            if (ImGui::SmallButton("Это оно")) {
                int fi = g_sel;
                Async([=]() { AssignAndFind(fi, a); });
            }
            ImGui::PopID();
        }
    }

    DrawFinder(busy);
    ImGui::Separator();
    ImGui::SliderInt("Глубина указателей", &g_depth, 1, 5);
    ImGui::SliderInt("Макс. смещение", &g_maxOff, 0x100, 0x2000, "0x%X");
    ImGui::Separator();
    ImGui::Text("Сохранённые значения (живые):");
    // читаем память не чаще 4 раз в секунду: раньше это делалось каждый кадр для всех полей
    struct Live { bool set = false; std::string val = "-"; };
    static Live live[NF];
    static ULONGLONG nextRead = 0;
    if (GetTickCount64() >= nextRead) {
        nextRead = GetTickCount64() + 250;
        for (int i = 0; i < NF; ++i) {
            live[i].set = !ChainStr(i).empty();
            live[i].val = live[i].set ? CurVal(i) : "-";
        }
    }
    int resetIdx = -1;
    if (ImGui::BeginTable("t", 4, ImGuiTableFlags_Borders | ImGuiTableFlags_RowBg)) {
        for (int i = 0; i < NF; ++i) {
            ImGui::TableNextRow();
            ImGui::TableNextColumn(); ImGui::TextUnformatted(F[i].label);
            ImGui::TableNextColumn(); ImGui::TextUnformatted(live[i].set ? "задано" : "не задано");
            ImGui::TableNextColumn(); ImGui::TextUnformatted(live[i].val.c_str());
            ImGui::TableNextColumn();
            ImGui::BeginDisabled(!live[i].set);
            ImGui::PushID(i);
            if (ImGui::SmallButton("Сбросить")) resetIdx = i;
            ImGui::PopID();
            ImGui::EndDisabled();
        }
        ImGui::EndTable();
    }
    if (resetIdx >= 0) {
        // стираем одно значение: и в таблице, и в DSRCombat.ini
        SetChainStr(resetIdx, "");
        WritePrivateProfileStringA("offsets", F[resetIdx].key, "", CombatIniPath().c_str());
        if (resetIdx == I_POSX) {  // координаты: заодно убираем связанные цепочки врагов
            for (const char* k : {"enemy_x", "enemy_y", "enemy_z", "enemy_angle"})
                WritePrivateProfileStringA("offsets", k, "", CombatIniPath().c_str());
        }
        CombatReloadCfg();
        nextRead = 0;
        SetStatus(std::string("Сброшено: ") + F[resetIdx].label + ".");
    }
    if (ImGui::Button("Сбросить ВСЕ значения")) ImGui::OpenPopup("reset_all");
    if (ImGui::BeginPopup("reset_all")) {
        ImGui::Text("Стереть все найденные цепочки?");
        if (ImGui::Button("Да, стереть")) {
            for (int i = 0; i < NF; ++i) {
                SetChainStr(i, "");
                WritePrivateProfileStringA("offsets", F[i].key, "", CombatIniPath().c_str());
            }
            for (const char* k : {"enemy_x", "enemy_y", "enemy_z", "enemy_angle", "enemy_list", "enemy_count",
                                  "enemy_anim_id", "enemy_anim_time"})
                WritePrivateProfileStringA("offsets", k, "", CombatIniPath().c_str());
            CombatReloadCfg();
            nextRead = 0;
            SetStatus("Все значения сброшены. Координаты можно найти заново кнопкой «Автопоиск координат».");
            ImGui::CloseCurrentPopup();
        }
        ImGui::SameLine();
        if (ImGui::Button("Отмена")) ImGui::CloseCurrentPopup();
        ImGui::EndPopup();
    }
    ImGui::TextDisabled("Подсказки: HP/эстус/стамина: введите значение с экрана, потом получите урон/выпейте эстус/ударьте и");
    ImGui::TextDisabled("сделайте скан «Такое же» с новым значением. ID анимации: примите удар и введите ID (см. вики).");
    ImGui::TextDisabled("Время анимации: найдите ID, затем «искать рядом»; во время замаха — «Больше», в покое — «Не менялось».");
    CoopUI();
    ImGui::End();
}

LRESULT CALLBACK HkWndProc(HWND h, UINT m, WPARAM w, LPARAM l) {
    if (g_init && g_open) {
        ImGui_ImplWin32_WndProcHandler(h, m, w, l);
        if (m >= WM_MOUSEFIRST && m <= WM_MOUSELAST) return 0;
        if (ImGui::GetIO().WantTextInput &&
            (m == WM_KEYDOWN || m == WM_KEYUP || m == WM_CHAR || m == WM_SYSKEYDOWN || m == WM_SYSKEYUP))
            return 0;
    }
    return CallWindowProcW(g_oldProc, h, m, w, l);
}

void InitImGui(IDXGISwapChain* sc) {
    if (!sc) return;
    DXGI_SWAP_CHAIN_DESC d{};
    if (FAILED(sc->GetDesc(&d)) || !IsWindow(d.OutputWindow)) return;
    g_hwnd = d.OutputWindow;
    if (FAILED(sc->GetDevice(__uuidof(ID3D11Device), (void**)&g_dev)) || !g_dev) {
        g_dev = nullptr;
        return;
    }
    g_dev->GetImmediateContext(&g_ctx);
    if (!g_ctx) { g_dev->Release(); g_dev = nullptr; return; }

    ImGui::CreateContext();
    ImGuiIO& io = ImGui::GetIO();
    io.IniFilename = nullptr;
    const char* font = "C:\\Windows\\Fonts\\segoeui.ttf";
    if (GetFileAttributesA(font) != INVALID_FILE_ATTRIBUTES)
        io.Fonts->AddFontFromFileTTF(font, 16.f, nullptr, io.Fonts->GetGlyphRangesCyrillic());
    ImGui::StyleColorsDark();

    if (!ImGui_ImplWin32_Init(g_hwnd)) {
        ImGui::DestroyContext();
        g_ctx->Release(); g_ctx = nullptr;
        g_dev->Release(); g_dev = nullptr;
        return;
    }
    if (!ImGui_ImplDX11_Init(g_dev, g_ctx)) {
        ImGui_ImplWin32_Shutdown();
        ImGui::DestroyContext();
        g_ctx->Release(); g_ctx = nullptr;
        g_dev->Release(); g_dev = nullptr;
        return;
    }

    SetLastError(ERROR_SUCCESS);
    LONG_PTR prev = SetWindowLongPtrW(g_hwnd, GWLP_WNDPROC, (LONG_PTR)HkWndProc);
    if (!prev) {
        ImGui_ImplDX11_Shutdown();
        ImGui_ImplWin32_Shutdown();
        ImGui::DestroyContext();
        g_ctx->Release(); g_ctx = nullptr;
        g_dev->Release(); g_dev = nullptr;
        return;
    }
    g_oldProc = (WNDPROC)prev;
    g_init = true;
}

void OnPresent(IDXGISwapChain* sc, UINT&) {
    if (!g_init) InitImGui(sc);
    HotkeysPresent(g_init && g_open && ImGui::GetIO().WantTextInput);  // P / I работают и без калибратора
    if (!g_init) return;

    DWORD pid = 0;
    GetWindowThreadProcessId(GetForegroundWindow(), &pid);
    bool focused = pid == GetCurrentProcessId();
    bool u = focused && (GetAsyncKeyState('U') & 0x8000);
    if (u && !g_prevU && !(g_open && ImGui::GetIO().WantTextInput)) g_open = !g_open;
    g_prevU = u;
    if (!g_open && !HudActive() && !HotkeysOverlayActive()) return;

    ImGui_ImplDX11_NewFrame();
    ImGui_ImplWin32_NewFrame();
    ImGui::NewFrame();
    ImGui::GetIO().MouseDrawCursor = g_open;
    if (g_open) DrawUI();
    HudDraw();
    WorldHudDraw();
    HotkeysDraw();
    ImGui::Render();

    ID3D11Texture2D* bb = nullptr;
    ID3D11RenderTargetView* rtv = nullptr;
    if (SUCCEEDED(sc->GetBuffer(0, __uuidof(ID3D11Texture2D), (void**)&bb))) {
        g_dev->CreateRenderTargetView(bb, nullptr, &rtv);
        bb->Release();
    }
    if (rtv) {
        g_ctx->OMSetRenderTargets(1, &rtv, nullptr);
        ImGui_ImplDX11_RenderDrawData(ImGui::GetDrawData());
        rtv->Release();
    }
}

}  // namespace

void CalibStart(HMODULE self) {
    g_self = self;
    std::string ini = CombatIniPath();
    for (int i = 0; i < NF; ++i) {
        char buf[512] = {};
        GetPrivateProfileStringA("offsets", F[i].key, "", buf, sizeof(buf), ini.c_str());
        SetChainStr(i, buf);
    }
    dx11::Callbacks cb;
    cb.onPresent = OnPresent;
    cb.onAfterPresent = [](IDXGISwapChain*) { HotkeysAfterPresent(); };
    dx11::Install(cb);
}
