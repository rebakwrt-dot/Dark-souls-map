#define _CRT_SECURE_NO_WARNINGS
// DSRCombat / hotkeys.cpp: горячие клавиши, вызываются из потока рендера (Present).
//  P  — пауза игры: после показа кадра с надписью «ПАУЗА» поток рендера (он же главный поток игры)
//       ждёт повторного нажатия P, обслуживая оконные сообщения, чтобы Windows не считала окно зависшим.
//  I  — открыть инвентарь: эмулирует нажатие игровой клавиши меню (inventory_game_key, по умолчанию Esc).
//       Прямой переход на вкладку инвентаря потребовал бы адреса состояния меню — их в проекте нет.
// Настройки: DSRCombat.ini [hotkeys].
#include <windows.h>

#include <atomic>
#include <cstdlib>
#include <string>

#include "imgui.h"
#include "combat.h"
#include "../common/dx11_hook.h"

namespace {

struct HCfg {
    bool on = true, pauseInCoop = false;
    int pauseKey = 'P', invKey = 'I', invGameKey = VK_ESCAPE;
};
HCfg h;
bool g_loaded = false, g_prevP = false, g_prevI = false;
std::atomic<bool> g_pausePending{false};

std::string IniGet(const char* key, const char* def) {
    std::string ini = CombatIniPath();
    char b[64] = {};
    GetPrivateProfileStringA("hotkeys", key, "\x01", b, sizeof(b), ini.c_str());
    if (b[0] == '\x01') {
        WritePrivateProfileStringA("hotkeys", key, def, ini.c_str());
        return def;
    }
    return b;
}

void Load() {
    HCfg n;
    n.on = IniGet("enabled", "1") != "0";
    n.pauseKey = (int)strtol(IniGet("pause_key", "0x50").c_str(), nullptr, 0);
    n.invKey = (int)strtol(IniGet("inventory_key", "0x49").c_str(), nullptr, 0);
    n.invGameKey = (int)strtol(IniGet("inventory_game_key", "0x1B").c_str(), nullptr, 0);
    n.pauseInCoop = IniGet("pause_in_coop", "0") != "0";
    h = n;
    g_loaded = true;
}

bool Focused() {
    DWORD pid = 0;
    GetWindowThreadProcessId(GetForegroundWindow(), &pid);
    return pid == GetCurrentProcessId();
}
bool Down(int vk) { return vk && (GetAsyncKeyState(vk) & 0x8000); }

// нажатие клавиши игры через скан-код (DirectInput читает именно его); отпускаем в отдельном потоке
DWORD WINAPI Tap(LPVOID p) {
    int vk = (int)(INT_PTR)p;
    WORD sc = (WORD)MapVirtualKeyA((UINT)vk, MAPVK_VK_TO_VSC);
    INPUT in{};
    in.type = INPUT_KEYBOARD;
    in.ki.wScan = sc;
    in.ki.dwFlags = KEYEVENTF_SCANCODE;
    SendInput(1, &in, sizeof(in));
    Sleep(70);
    in.ki.dwFlags = KEYEVENTF_SCANCODE | KEYEVENTF_KEYUP;
    SendInput(1, &in, sizeof(in));
    return 0;
}

void PumpMessages() {
    MSG m;
    while (PeekMessageW(&m, nullptr, 0, 0, PM_REMOVE)) {
        if (m.message == WM_QUIT) { PostQuitMessage((int)m.wParam); return; }
        TranslateMessage(&m);
        DispatchMessageW(&m);
    }
}

void RunPause() {
    bool prev = true;  // клавиша паузы ещё зажата с момента нажатия: ждём отпускания
    while (true) {
        PumpMessages();
        bool d = Down(h.pauseKey) && Focused();
        if (d && !prev) break;
        prev = d || (prev && Down(h.pauseKey));
        Sleep(15);
    }
    dx11::SkipSlowLog();
}

}  // namespace

void HotkeysPresent(bool typing) {
    if (!g_loaded) Load();
    if (!h.on || !Focused()) { g_prevP = g_prevI = Down(h.pauseKey) || Down(h.invKey); return; }
    bool p = Down(h.pauseKey), i = Down(h.invKey);
    if (p && !g_prevP && !typing && (!CoopEnabled() || h.pauseInCoop)) g_pausePending = true;
    if (i && !g_prevI && !typing && h.invGameKey)
        if (HANDLE t = CreateThread(nullptr, 0, Tap, (LPVOID)(INT_PTR)h.invGameKey, 0, nullptr)) CloseHandle(t);
    g_prevP = p;
    g_prevI = i;
}

bool HotkeysOverlayActive() { return g_pausePending; }

void HotkeysDraw() {
    if (!g_pausePending) return;
    ImVec2 ds = ImGui::GetIO().DisplaySize;
    ImGui::GetForegroundDrawList()->AddText(ImVec2(ds.x * 0.5f - 90, ds.y * 0.45f), IM_COL32(255, 255, 255, 255),
                                            "ПАУЗА - P: продолжить");
}

// после оригинального Present: кадр с надписью уже показан
void HotkeysAfterPresent() {
    if (g_pausePending.exchange(false)) RunPause();
}
