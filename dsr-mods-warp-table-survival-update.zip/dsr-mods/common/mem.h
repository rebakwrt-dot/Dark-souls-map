#pragma once
#include <windows.h>
#include <cstdint>
#include <algorithm>
#include <atomic>
#include <cstdlib>
#include <string>
#include <vector>

#include "probe.h"

// Цепочка указателей: [первое число — смещение от старта (база exe или адрес сущности)],
// каждое следующее: прочитать указатель по текущему адресу и прибавить смещение.
// Первое «число» цепочки может быть словом @world: тогда старт — адрес статической переменной WorldChrBase,
// найденный сканированием exe по сигнатуре (как в DSR-Gadget). Пример: @world, 0x68, 0x68, 0x28, 0x10
struct Chain {
    std::vector<uintptr_t> v;
    bool aob = false;
    bool valid() const { return !v.empty(); }
};

inline Chain ParseChain(const std::string& s) {
    Chain c;
    size_t i = 0;
    while (i < s.size()) {
        size_t j = s.find(',', i);
        if (j == std::string::npos) j = s.size();
        std::string t = s.substr(i, j - i);
        size_t a = t.find_first_not_of(" \t");
        if (a != std::string::npos) {
            if (c.v.empty() && t.compare(a, 6, "@world") == 0) {
                c.aob = true;
                c.v.push_back(0);
                i = j + 1;
                continue;
            }
            char* end = nullptr;
            uintptr_t v = (uintptr_t)strtoull(t.c_str() + a, &end, 0);
            // мусор вместо числа («abc», «0x») -> цепочка считается невалидной и функция выключается
            if (end == t.c_str() + a) return Chain();
            c.v.push_back(v);
        }
        i = j + 1;
    }
    return c;
}

template <class T>
inline bool Rd(uintptr_t a, T& out) {
    if (a < 0x10000 || a > UINTPTR_MAX - sizeof(T)) return false;
    if (!probe::Allowed()) return false;  // бюджет исключений исчерпан (см. probe.h)
    probe::inProbe = true;
    bool ok = false;
    __try {
        out = *reinterpret_cast<const T*>(a);
        ok = true;
    } __except (EXCEPTION_EXECUTE_HANDLER) {
        probe::NoteFault();
    }
    probe::inProbe = false;
    return ok;
}

// Сканирование одного региона по маске (-1 — любой байт). Только простые типы: тут __try.
inline uintptr_t ScanRegionForPattern(uintptr_t lo, uintptr_t hi, const int* pat, size_t n) {
    __try {
        for (uintptr_t a = lo; a + n <= hi; ++a) {
            const unsigned char* m = reinterpret_cast<const unsigned char*>(a);
            size_t k = 0;
            while (k < n && (pat[k] < 0 || m[k] == (unsigned char)pat[k])) ++k;
            if (k == n) return a;
        }
    } __except (EXCEPTION_EXECUTE_HANDLER) {
    }
    return 0;
}

// Адрес статической переменной WorldChrBase (сигнатура из DSR-Gadget: mov rax,[rip+disp]).
// Кэшируется; при неудаче повтор не чаще раза в 2 секунды (код может ещё не быть распакован).
inline uintptr_t FindWorldChrStatic() {
    static std::atomic<uintptr_t> cached{0};
    static std::atomic<ULONGLONG> nextTry{0};
    if (uintptr_t c = cached.load()) return c;
    const ULONGLONG now = GetTickCount64();
    if (now < nextTry.load()) return 0;
    nextTry = now + 2000;
    static const int pat[] = {0x48, 0x8B, 0x05, -1, -1, -1, -1, 0x48, 0x8B, 0x48, 0x68, 0x48, 0x85, 0xC9,
                              0x0F, 0x84, -1, -1, -1, -1, 0x48, 0x39, 0x5E, 0x10, 0x0F, 0x84, -1, -1, -1, -1, 0x48};
    constexpr size_t N = sizeof(pat) / sizeof(pat[0]);
    const uintptr_t base = (uintptr_t)GetModuleHandleA(nullptr);
    const IMAGE_DOS_HEADER* dos = reinterpret_cast<const IMAGE_DOS_HEADER*>(base);
    if (!base || dos->e_magic != IMAGE_DOS_SIGNATURE) return 0;
    const IMAGE_NT_HEADERS* nt = reinterpret_cast<const IMAGE_NT_HEADERS*>(base + dos->e_lfanew);
    const uintptr_t end = base + nt->OptionalHeader.SizeOfImage;
    uintptr_t p = base;
    while (p < end) {
        MEMORY_BASIC_INFORMATION mbi{};
        if (!VirtualQuery(reinterpret_cast<void*>(p), &mbi, sizeof(mbi))) break;
        const uintptr_t rb = (uintptr_t)mbi.BaseAddress, re = rb + mbi.RegionSize;
        const bool exec = (mbi.Protect & (PAGE_EXECUTE_READ | PAGE_EXECUTE_READWRITE | PAGE_EXECUTE_WRITECOPY)) != 0;
        if (mbi.State == MEM_COMMIT && exec && !(mbi.Protect & (PAGE_GUARD | PAGE_NOACCESS))) {
            const uintptr_t hit = ScanRegionForPattern(std::max(rb, base), std::min(re, end), pat, N);
            if (hit) {
                const int32_t disp = *reinterpret_cast<const int32_t*>(hit + 3);
                const uintptr_t addr = hit + 7 + (intptr_t)disp;
                cached = addr;
                return addr;
            }
        }
        if (re <= p) break;
        p = re;
    }
    return 0;
}

inline bool Resolve(const Chain& c, uintptr_t start, uintptr_t& out) {
    if (c.v.empty()) return false;
    if (c.aob) {
        start = FindWorldChrStatic();
        if (!start) return false;
    }
    if (start > UINTPTR_MAX - c.v[0]) return false;
    uintptr_t p = start + c.v[0];
    for (size_t i = 1; i < c.v.size(); ++i) {
        uintptr_t q = 0;
        if (!Rd(p, q) || !q || q > UINTPTR_MAX - c.v[i]) return false;
        p = q + c.v[i];
    }
    out = p;
    return true;
}

template <class T>
inline bool ReadChain(const Chain& c, uintptr_t start, T& out) {
    uintptr_t a = 0;
    return Resolve(c, start, a) && Rd(a, out);
}
