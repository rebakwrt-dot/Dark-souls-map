#include "dx11_hook.h"
#include "probe.h"

#include <cstdarg>
#include <cstdio>
#include <algorithm>
#include <cstdint>
#include <cstring>
#include <string>
#include <vector>

namespace dx11 {

using PresentFn = HRESULT(STDMETHODCALLTYPE*)(IDXGISwapChain*, UINT, UINT);
using SamplerFn = HRESULT(STDMETHODCALLTYPE*)(ID3D11Device*, const D3D11_SAMPLER_DESC*, ID3D11SamplerState**);

static volatile LONG g_skipSlow = 0;

// ---- общее состояние хука на весь процесс ----
// ВАЖНО: раньше каждая DLL (DSROptimize, DSRCombat) создавала свою «пустышку»-swapchain и вешала свой
// Present-хук поверх общей vtable. Оверлей Steam перехватывает Present при создании каждого swapchain и
// запоминает то, что лежит в слоте, как «оригинал»; после второго мода получалось
// оверлей -> хук мода A -> оверлей -> хук мода A -> ... (бесконечная рекурсия, 0xC00000FD).
// Теперь хук ставит только первая DLL, остальные просто регистрируют свои колбэки в общей памяти.
constexpr int kMaxEntries = 8;
struct Entry {
    Callbacks cb;
    volatile LONG faults;
};
struct Shared {
    volatile LONG installed;  // 1, когда хук реально стоит
    volatile LONG count;      // сколько колбэков зарегистрировано
    PresentFn orig;           // то, что вызывает наш хук (значение слота до подмены)
    PresentFn clean;          // «чистый» dxgi Present (из файла dxgi.dll) или nullptr — запасной выход из петли
    SamplerFn origSampler;
    Entry entries[kMaxEntries];
};
static Shared* g_sh = nullptr;
static thread_local int t_depth = 0;  // >0, пока этот поток внутри нашего HkPresent

// ---- диагностика: DSRMods\<имя dll>.hook.log (дописывается; присылайте его при вылетах/фризах) ----
static LONG g_logLock = 0;
static void LogLine(const char* fmt, ...) {
    char msg[512];
    va_list ap;
    va_start(ap, fmt);
    vsnprintf(msg, sizeof(msg), fmt, ap);
    va_end(ap);
    while (InterlockedExchange(&g_logLock, 1)) Sleep(0);
    HMODULE self = nullptr;
    GetModuleHandleExA(GET_MODULE_HANDLE_EX_FLAG_FROM_ADDRESS | GET_MODULE_HANDLE_EX_FLAG_UNCHANGED_REFCOUNT, (LPCSTR)&LogLine, &self);
    char path[MAX_PATH]{};
    GetModuleFileNameA(self, path, MAX_PATH);
    std::string p = path;
    size_t dot = p.find_last_of('.');
    if (dot != std::string::npos) p.resize(dot);
    p += ".hook.log";
    HANDLE f = CreateFileA(p.c_str(), FILE_APPEND_DATA, FILE_SHARE_READ | FILE_SHARE_WRITE, nullptr, OPEN_ALWAYS, FILE_ATTRIBUTE_NORMAL, nullptr);
    if (f != INVALID_HANDLE_VALUE) {
        SYSTEMTIME t{};
        GetLocalTime(&t);
        char line[640];
        int n = snprintf(line, sizeof(line), "[%02u:%02u:%02u.%03u] %s\r\n", t.wHour, t.wMinute, t.wSecond, t.wMilliseconds, msg);
        DWORD w = 0;
        if (n > 0) WriteFile(f, line, (DWORD)n, &w, nullptr);
        CloseHandle(f);
    }
    InterlockedExchange(&g_logLock, 0);
}

static double Ms(LONGLONG a, LONGLONG b) {
    static LARGE_INTEGER fq = [] { LARGE_INTEGER q; QueryPerformanceFrequency(&q); return q; }();
    return (double)(b - a) * 1000.0 / (double)fq.QuadPart;
}
static LONGLONG Now() { LARGE_INTEGER q; QueryPerformanceCounter(&q); return q.QuadPart; }

// Фатальные исключения (не пробы чтения памяти) пишем в лог: по ним видно, где именно падает игра.
static LONG CALLBACK Veh(PEXCEPTION_POINTERS p) {
    DWORD code = p->ExceptionRecord->ExceptionCode;
    bool fatalish = code == EXCEPTION_ACCESS_VIOLATION || code == EXCEPTION_ILLEGAL_INSTRUCTION ||
                    code == EXCEPTION_STACK_OVERFLOW || code == EXCEPTION_INT_DIVIDE_BY_ZERO ||
                    code == 0xC0000374 /*heap corruption*/ || code == 0xC0000409 /*fail fast*/ ||
                    code == EXCEPTION_PRIV_INSTRUCTION || code == EXCEPTION_IN_PAGE_ERROR;
    if (!fatalish || probe::inProbe) return EXCEPTION_CONTINUE_SEARCH;
    static volatile LONG n = 0;
    if (InterlockedIncrement(&n) > 40) return EXCEPTION_CONTINUE_SEARCH;
    void* addr = p->ExceptionRecord->ExceptionAddress;
    char mod[MAX_PATH] = "?";
    HMODULE hm = nullptr;
    if (GetModuleHandleExA(GET_MODULE_HANDLE_EX_FLAG_FROM_ADDRESS | GET_MODULE_HANDLE_EX_FLAG_UNCHANGED_REFCOUNT, (LPCSTR)addr, &hm) && hm) {
        GetModuleFileNameA(hm, mod, MAX_PATH);
        const char* b = strrchr(mod, '\\');
        if (b) memmove(mod, b + 1, strlen(b));
    }
    unsigned long long info1 = p->ExceptionRecord->NumberParameters > 1 ? (unsigned long long)p->ExceptionRecord->ExceptionInformation[1] : 0;
    LogLine("EXCEPTION code=0x%08lX at %p (%s+0x%llX) tid=%lu info=%llX", code, addr, mod,
            (unsigned long long)((uintptr_t)addr - (uintptr_t)hm), GetCurrentThreadId(), info1);
    return EXCEPTION_CONTINUE_SEARCH;
}

static void SafeCallBefore(Entry& e, IDXGISwapChain* sc, UINT& sync) {
    __try { e.cb.onPresent(sc, sync); } __except (EXCEPTION_EXECUTE_HANDLER) { InterlockedIncrement(&e.faults); }
}
static void SafeCallAfter(Entry& e, IDXGISwapChain* sc) {
    __try { e.cb.onAfterPresent(sc); } __except (EXCEPTION_EXECUTE_HANDLER) { InterlockedIncrement(&e.faults); }
}

struct DepthGuard {
    DepthGuard() { ++t_depth; }
    ~DepthGuard() { --t_depth; }
};

static HRESULT STDMETHODCALLTYPE HkPresent(IDXGISwapChain* sc, UINT sync, UINT flags) {
    static volatile LONG slowLogs = 0;
    static volatile LONG loopLogs = 0;
    Shared* sh = g_sh;

    // Защита от рекурсии: если цепочка хуков (оверлей и т.п.) привела нас обратно в этот же хук
    // в том же потоке — не уходим в следующий виток, а вызываем «чистый» Present напрямую.
    if (t_depth > 0) {
        if (InterlockedIncrement(&loopLogs) <= 5)
            LogLine("Present вошёл в хук повторно (петля перехватов, напр. оверлей) — разорвано; clean=%p", sh ? (void*)sh->clean : nullptr);
        if (sh && sh->clean && (void*)sh->clean != (void*)HkPresent) return sh->clean(sc, sync, flags);
        return S_OK;  // хуже, чем потерять кадр, только вылет по переполнению стека
    }

    DepthGuard guard;
    const bool real = !(flags & DXGI_PRESENT_TEST);
    LONGLONG t0 = Now();
    const LONG n = sh->count;
    if (real)
        for (LONG i = 0; i < n; ++i) {
            Entry& e = sh->entries[i];
            if (e.cb.onPresent && e.faults < 5) SafeCallBefore(e, sc, sync);  // после нескольких сбоев колбэк отключается
        }
    LONGLONG t1 = Now();
    HRESULT hr = sh->orig(sc, sync, flags);
    LONGLONG t2 = Now();
    if (real)
        for (LONG i = 0; i < n; ++i) {
            Entry& e = sh->entries[i];
            if (e.cb.onAfterPresent && e.faults < 5) SafeCallAfter(e, sc);
        }
    LONGLONG t3 = Now();
    // «наш» код: до и после оригинального Present; сам Present (t1..t2) включает остальные хуки/VSync/GPU
    double mine = Ms(t0, t1) + Ms(t2, t3);
    if (InterlockedExchange(&g_skipSlow, 0)) return hr;  // кадр после паузы
    if ((mine > 8.0 || Ms(t1, t2) > 250.0) && InterlockedIncrement(&slowLogs) <= 25)
        LogLine("slow frame: our callbacks %.1f ms, Present %.1f ms (sync=%u flags=0x%X memFaults=%u)",
                mine, Ms(t1, t2), sync, flags, probe::totalFaults.load());
    return hr;
}

static HRESULT STDMETHODCALLTYPE HkSampler(ID3D11Device* dev, const D3D11_SAMPLER_DESC* d, ID3D11SamplerState** out) {
    Shared* sh = g_sh;
    if (d && sh) {
        D3D11_SAMPLER_DESC c = *d;
        bool changed = false;
        const LONG n = sh->count;
        for (LONG i = 0; i < n; ++i)
            if (sh->entries[i].cb.onCreateSampler) { sh->entries[i].cb.onCreateSampler(c); changed = true; }
        if (changed) return sh->origSampler(dev, &c, out);
    }
    return sh->origSampler(dev, d, out);
}

static bool Patch(void** slot, void* hook, void** orig) {
    DWORD old;
    if (!VirtualProtect(slot, sizeof(void*), PAGE_READWRITE, &old)) return false;
    *orig = *slot;
    *slot = hook;
    VirtualProtect(slot, sizeof(void*), old, &old);
    return true;
}

// Достаёт настоящий адрес IDXGISwapChain::Present из ФАЙЛА dxgi.dll на диске (vtable лежит в .rdata,
// в файле там значения без перехватов). Нужен только как аварийный выход из петли хуков.
static PresentFn FindCleanPresent(void** vt) {
    HMODULE hm = nullptr;
    if (!GetModuleHandleExW(GET_MODULE_HANDLE_EX_FLAG_FROM_ADDRESS | GET_MODULE_HANDLE_EX_FLAG_UNCHANGED_REFCOUNT, (LPCWSTR)vt, &hm) || !hm)
        return nullptr;
    wchar_t path[MAX_PATH]{};
    if (!GetModuleFileNameW(hm, path, MAX_PATH)) return nullptr;
    HANDLE f = CreateFileW(path, GENERIC_READ, FILE_SHARE_READ | FILE_SHARE_WRITE | FILE_SHARE_DELETE, nullptr, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, nullptr);
    if (f == INVALID_HANDLE_VALUE) return nullptr;
    LARGE_INTEGER sz{};
    if (!GetFileSizeEx(f, &sz) || sz.QuadPart < 0x1000 || sz.QuadPart > (64ll << 20)) { CloseHandle(f); return nullptr; }
    std::vector<unsigned char> buf((size_t)sz.QuadPart);
    DWORD rd = 0;
    const bool read = ReadFile(f, buf.data(), (DWORD)buf.size(), &rd, nullptr) && rd == buf.size();
    CloseHandle(f);
    if (!read) return nullptr;

    auto* dos = reinterpret_cast<IMAGE_DOS_HEADER*>(buf.data());
    if (dos->e_magic != IMAGE_DOS_SIGNATURE || dos->e_lfanew <= 0 || (size_t)dos->e_lfanew + sizeof(IMAGE_NT_HEADERS64) > buf.size()) return nullptr;
    auto* nt = reinterpret_cast<IMAGE_NT_HEADERS64*>(buf.data() + dos->e_lfanew);
    if (nt->Signature != IMAGE_NT_SIGNATURE || nt->OptionalHeader.Magic != IMAGE_NT_OPTIONAL_HDR64_MAGIC) return nullptr;
    const IMAGE_SECTION_HEADER* sec = IMAGE_FIRST_SECTION(nt);
    const unsigned nsec = nt->FileHeader.NumberOfSections;
    if ((const unsigned char*)(sec + nsec) > buf.data() + buf.size()) return nullptr;

    const uint64_t slotRva = (uint64_t)((uintptr_t)&vt[8] - (uintptr_t)hm);
    uint64_t value = 0;
    bool got = false;
    for (unsigned i = 0; i < nsec && !got; ++i) {
        const uint64_t va = sec[i].VirtualAddress, raw = sec[i].SizeOfRawData;
        if (slotRva >= va && slotRva + 8 <= va + raw && (uint64_t)sec[i].PointerToRawData + (slotRva - va) + 8 <= buf.size()) {
            memcpy(&value, buf.data() + sec[i].PointerToRawData + (slotRva - va), 8);
            got = true;
        }
    }
    if (!got || value < nt->OptionalHeader.ImageBase) return nullptr;
    const uint64_t rva = value - nt->OptionalHeader.ImageBase;
    if (rva >= nt->OptionalHeader.SizeOfImage) return nullptr;
    for (unsigned i = 0; i < nsec; ++i) {  // цель обязана лежать в исполняемой секции
        const uint64_t va = sec[i].VirtualAddress, vs = std::max<uint64_t>(sec[i].Misc.VirtualSize, sec[i].SizeOfRawData);
        if (rva >= va && rva < va + vs && (sec[i].Characteristics & IMAGE_SCN_MEM_EXECUTE))
            return reinterpret_cast<PresentFn>((uintptr_t)hm + (uintptr_t)rva);
    }
    return nullptr;
}

bool Install(const Callbacks& cb) {
    static bool vehOn = false;
    if (!vehOn) { vehOn = AddVectoredExceptionHandler(1, Veh) != nullptr; }
    LogLine("Install begin (onPresent=%d after=%d sampler=%d)", cb.onPresent != nullptr, cb.onAfterPresent != nullptr, cb.onCreateSampler != nullptr);
    // один установщик на весь процесс: имя общее для всех модов
    HANDLE mx = CreateMutexW(nullptr, FALSE, L"Local\\DSRMods_dx11_install");
    if (!mx) { LogLine("Install: CreateMutex failed %lu", GetLastError()); return false; }
    DWORD lockResult = WaitForSingleObject(mx, 10000);
    if (lockResult != WAIT_OBJECT_0 && lockResult != WAIT_ABANDONED) {
        LogLine("Install: mutex wait failed (%lu)", lockResult);
        CloseHandle(mx);
        return false;  // не трогаем общую DX11-таблицу без гарантированной блокировки
    }
    struct Rel { HANDLE m; ~Rel() { if (m) { ReleaseMutex(m); CloseHandle(m); } } } rel{mx};

    // Общая память процесса: колбэки всех модов + указатели оригиналов. Дескриптор и вид держим открытыми до конца процесса.
    HANDLE map = CreateFileMappingW(INVALID_HANDLE_VALUE, nullptr, PAGE_READWRITE, 0, (DWORD)sizeof(Shared), L"Local\\DSRMods_dx11_shared_v2");
    if (!map) { LogLine("Install: CreateFileMapping failed %lu", GetLastError()); return false; }
    Shared* sh = static_cast<Shared*>(MapViewOfFile(map, FILE_MAP_ALL_ACCESS, 0, 0, sizeof(Shared)));
    if (!sh) { LogLine("Install: MapViewOfFile failed %lu", GetLastError()); CloseHandle(map); return false; }
    g_sh = sh;

    if (sh->count >= kMaxEntries) { LogLine("Install: слишком много модов (%ld)", sh->count); return false; }
    Entry& e = sh->entries[sh->count];
    e.cb = cb;
    e.faults = 0;
    MemoryBarrier();
    InterlockedIncrement(&sh->count);  // публикуем запись после того, как она полностью заполнена

    if (sh->installed) {
        LogLine("Install: хук уже стоит (колбэков: %ld) — второй Present-хук и вторая пустышка-swapchain НЕ создаются", sh->count);
        return true;
    }

    WNDCLASSEXW wc{};
    wc.cbSize = sizeof(wc);
    wc.lpfnWndProc = DefWindowProcW;
    wc.hInstance = GetModuleHandleW(nullptr);
    wc.lpszClassName = L"DSRModsDummy";
    RegisterClassExW(&wc);
    HWND hwnd = CreateWindowW(wc.lpszClassName, L"", WS_OVERLAPPEDWINDOW, 0, 0, 100, 100, nullptr, nullptr, wc.hInstance, nullptr);

    DXGI_SWAP_CHAIN_DESC sd{};
    sd.BufferCount = 1;
    sd.BufferDesc.Format = DXGI_FORMAT_R8G8B8A8_UNORM;
    sd.BufferUsage = DXGI_USAGE_RENDER_TARGET_OUTPUT;
    sd.OutputWindow = hwnd;
    sd.SampleDesc.Count = 1;
    sd.Windowed = TRUE;
    sd.SwapEffect = DXGI_SWAP_EFFECT_DISCARD;

    ID3D11Device* dev = nullptr;
    ID3D11DeviceContext* ctx = nullptr;
    IDXGISwapChain* sc = nullptr;
    HRESULT hr = D3D11CreateDeviceAndSwapChain(nullptr, D3D_DRIVER_TYPE_HARDWARE, nullptr, 0, nullptr, 0,
                                               D3D11_SDK_VERSION, &sd, &sc, &dev, nullptr, &ctx);
    bool ok = false;
    if (SUCCEEDED(hr)) {
        void** scVt = *reinterpret_cast<void***>(sc);
        void** devVt = *reinterpret_cast<void***>(dev);
        void* prev = scVt[8];
        sh->clean = FindCleanPresent(scVt);
        ok = Patch(&scVt[8], (void*)HkPresent, (void**)&sh->orig);  // IDXGISwapChain::Present
        LogLine("Present patched ok=%d previous=%p clean=%p (если previous не в dxgi.dll — уже перехвачен другим модом/оверлеем)", ok, prev, (void*)sh->clean);
        if (ok) {
            bool sok = Patch(&devVt[23], (void*)HkSampler, (void**)&sh->origSampler);  // ID3D11Device::CreateSamplerState
            LogLine("CreateSamplerState patched ok=%d", sok);
            if (!sok) sh->origSampler = nullptr;
        }
        if (ok) { MemoryBarrier(); sh->installed = 1; }
    } else {
        LogLine("Install: D3D11CreateDeviceAndSwapChain failed hr=0x%08lX", (unsigned long)hr);
    }
    if (ctx) ctx->Release();
    if (dev) dev->Release();
    if (sc) sc->Release();
    DestroyWindow(hwnd);
    UnregisterClassW(wc.lpszClassName, wc.hInstance);
    LogLine("Install end ok=%d", ok);
    return ok;
}

void SkipSlowLog() { InterlockedExchange(&g_skipSlow, 1); }

}  // namespace dx11
