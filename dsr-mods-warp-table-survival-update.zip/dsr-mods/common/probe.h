#pragma once
// Защита от «шторма исключений». Чтение чужой памяти через __try/__except при невалидном
// указателе выбрасывает access violation; обработка стоит десятки микросекунд, а при наличии
// у игры/оверлеев своих VEH-обработчиков — миллисекунды. Цепочки в меню часто ведут в никуда,
// и такие чтения повторяются сотни раз в секунду -> фризы. Бюджет: не больше kMaxFaults
// реальных исключений в секунду на DLL; пока бюджет исчерпан, чтения просто возвращают false.
#include <windows.h>
#include <atomic>

namespace probe {
constexpr unsigned kMaxFaults = 12;
inline std::atomic<unsigned> faults{0};
inline std::atomic<ULONGLONG> windowStart{0};
inline std::atomic<unsigned> totalFaults{0};
inline thread_local bool inProbe = false;  // true, пока выполняется проба (VEH-диагностика её пропускает)

inline bool Allowed() {
    ULONGLONG now = GetTickCount64();
    ULONGLONG ws = windowStart.load(std::memory_order_relaxed);
    if (now - ws >= 1000) {
        windowStart.store(now, std::memory_order_relaxed);
        faults.store(0, std::memory_order_relaxed);
        return true;
    }
    return faults.load(std::memory_order_relaxed) < kMaxFaults;
}
inline void NoteFault() {
    faults.fetch_add(1, std::memory_order_relaxed);
    totalFaults.fetch_add(1, std::memory_order_relaxed);
}
}  // namespace probe
