#pragma once
#include <windows.h>
#include <d3d11.h>
#include <dxgi.h>

// Общий хук DX11 через подмену записей в vtable. Хук ставится ОДИН РАЗ на процесс (первой загруженной DLL),
// остальные моды только регистрируют свои колбэки в общей памяти (Local\\DSRMods_dx11_shared_v2).
// Так оверлей Steam/Discord не может замкнуть цепочку перехватов (раньше -> переполнение стека 0xC00000FD).
namespace dx11 {
struct Callbacks {
    void (*onPresent)(IDXGISwapChain*, UINT& syncInterval) = nullptr;  // до оригинального Present
    void (*onAfterPresent)(IDXGISwapChain*) = nullptr;                 // после
    void (*onCreateSampler)(D3D11_SAMPLER_DESC&) = nullptr;            // можно менять описание
};
bool Install(const Callbacks& cb);
void SkipSlowLog();  // не писать в лог текущий кадр как «медленный» (после паузы)
}  // namespace dx11
