// DSROptimize: лёгкие оптимизации рендера Dark Souls Remastered.
//  - ограничение анизотропной фильтрации (меньше нагрузка на GPU)
//  - пауза рендера, когда окно игры не в фокусе
//  - опциональное отключение VSync без изменения разрешения/эффектов
//  - необязательный точный лимитер кадров (fps_limit)
#include <windows.h>

#include <fstream>
#include <string>

#include "../common/dx11_hook.h"

static HMODULE g_self;
static int g_aniso = 2;
static int g_fps = 0;
static int g_fpsToggleValue = 30;  // на что переключает fps_toggle_key
static int g_fpsKey = 0x7A;        // F11
static bool g_prevFpsKey = false;
static bool g_bgSleep = true;
static bool g_disableVsync = false;
static ULONGLONG g_focusCheckAt = 0;
static bool g_isFocused = true;
static HANDLE g_timer = nullptr;
static LARGE_INTEGER g_freq, g_next;

static bool Focused() {
    const ULONGLONG now = GetTickCount64();
    if (now >= g_focusCheckAt) {
        HWND fg = GetForegroundWindow();
        DWORD pid = 0;
        if (fg) GetWindowThreadProcessId(fg, &pid);
        g_isFocused = (pid == GetCurrentProcessId());
        g_focusCheckAt = now + 250; // проверка фокуса 4 раза/с, а не на каждом кадре
    }
    return g_isFocused;
}

static void OnPresent(IDXGISwapChain*, UINT& sync) {
    // Не меняем графические эффекты или разрешение; убираем ожидание VSync.
    // Может дать больше FPS, если игра/драйвер ограничивали кадры VSync.
    if (g_disableVsync) sync = 0;
}

static void OnSampler(D3D11_SAMPLER_DESC& d) {
    // 0x40 — бит анизотропной фильтрации в D3D11_FILTER
    if (g_aniso > 0 && (d.Filter & 0x40) && d.MaxAnisotropy > (UINT)g_aniso) d.MaxAnisotropy = (UINT)g_aniso;
}

static void OnAfterPresent(IDXGISwapChain*) {
    if (g_bgSleep && !Focused()) Sleep(50);
    // клавиша переключения лимита кадров: выкл <-> fps_toggle_value (по умолчанию 30)
    bool k = g_fpsKey && Focused() && (GetAsyncKeyState(g_fpsKey) & 0x8000);
    if (k && !g_prevFpsKey) {
        g_fps = g_fps > 0 ? 0 : g_fpsToggleValue;
        g_next.QuadPart = 0;
    }
    g_prevFpsKey = k;
    if (g_fps <= 0) return;

    LARGE_INTEGER now;
    QueryPerformanceCounter(&now);
    long long interval = g_freq.QuadPart / g_fps;
    if (g_next.QuadPart == 0) g_next.QuadPart = now.QuadPart;
    g_next.QuadPart += interval;
    if (now.QuadPart > g_next.QuadPart + interval * 2) {  // отстали — сбрасываем
        g_next.QuadPart = now.QuadPart;
        return;
    }
    while (now.QuadPart < g_next.QuadPart) {
        double remainMs = (double)(g_next.QuadPart - now.QuadPart) * 1000.0 / (double)g_freq.QuadPart;
        if (remainMs > 2.0 && g_timer) {
            LARGE_INTEGER due;
            due.QuadPart = -(LONGLONG)((remainMs - 1.5) * 10000.0);
            SetWaitableTimer(g_timer, &due, 0, nullptr, nullptr, FALSE);
            WaitForSingleObject(g_timer, 20);
        } else {
            // Не крутить ядро в busy-wait: уступаем квант CPU.
            Sleep(1);
        }
        QueryPerformanceCounter(&now);
    }
}

static DWORD WINAPI Init(LPVOID) {
    char p[MAX_PATH];
    GetModuleFileNameA(g_self, p, MAX_PATH);
    std::string ini = p;
    ini = ini.substr(0, ini.find_last_of("\\/") + 1) + "DSROptimize.ini";
    if (GetFileAttributesA(ini.c_str()) == INVALID_FILE_ATTRIBUTES) {
        std::ofstream f(ini);
        f << "[optimize]\n"
             "; Максимум анизотропной фильтрации (0 = не трогать, 1/2/4/8/16)\n"
             "max_anisotropy=2\n"
             "; Отключить ожидание VSync (по умолчанию 0: DSR привязан к 60 кадрам, без VSync возможны рывки/ускорение; 1 только на свой риск)\n"
             "disable_vsync=0\n"
             "; Точный лимит FPS при запуске (0 = выключено, 30 = 30 кадров)\n"
             "fps_limit=30\n"
             "; Клавиша переключения лимита (VK-код, 0x7A = F11, 0 = нет) и значение лимита при включении\n"
             "fps_toggle_key=0x7A\n"
             "fps_toggle_value=30\n"
             "; Снижать нагрузку, когда окно игры не в фокусе\n"
             "background_sleep=1\n";
    }
    g_aniso = GetPrivateProfileIntA("optimize", "max_anisotropy", 2, ini.c_str());
    if (g_aniso != 0 && g_aniso != 1 && g_aniso != 2 && g_aniso != 4 && g_aniso != 8 && g_aniso != 16)
        g_aniso = 2;
    g_fps = GetPrivateProfileIntA("optimize", "fps_limit", 0, ini.c_str());
    if (g_fps < 0 || g_fps > 240) g_fps = 0;
    g_fpsToggleValue = GetPrivateProfileIntA("optimize", "fps_toggle_value", 30, ini.c_str());
    if (g_fpsToggleValue < 10 || g_fpsToggleValue > 240) g_fpsToggleValue = 30;
    char kb[32] = {};
    GetPrivateProfileStringA("optimize", "fps_toggle_key", "0x7A", kb, sizeof(kb), ini.c_str());
    g_fpsKey = (int)strtol(kb, nullptr, 0);
    g_bgSleep = GetPrivateProfileIntA("optimize", "background_sleep", 1, ini.c_str()) != 0;
    g_disableVsync = GetPrivateProfileIntA("optimize", "disable_vsync", 0, ini.c_str()) != 0;
    QueryPerformanceFrequency(&g_freq);
    // таймер нужен всегда: лимит можно включить клавишей уже в игре
    g_timer = CreateWaitableTimerExW(nullptr, nullptr, CREATE_WAITABLE_TIMER_HIGH_RESOLUTION, TIMER_ALL_ACCESS);

    dx11::Callbacks cb;
    cb.onPresent = OnPresent;
    cb.onAfterPresent = OnAfterPresent;
    cb.onCreateSampler = OnSampler;
    dx11::Install(cb);
    HANDLE ready = CreateEventA(nullptr, TRUE, FALSE, "Local\\DSRMods_DSROptimize_Ready");
    if (ready) { SetEvent(ready); CloseHandle(ready); }
    return 0;
}

BOOL APIENTRY DllMain(HMODULE m, DWORD reason, LPVOID) {
    if (reason == DLL_PROCESS_ATTACH) {
        g_self = m;
        DisableThreadLibraryCalls(m);
        CreateThread(nullptr, 0, Init, nullptr, 0, nullptr);
    }
    return TRUE;
}
