#define _CRT_SECURE_NO_WARNINGS
// DSRCombat / coop.cpp: кооператив по LAN + «твики», всё в одной DLL.
//  1) UDP-синхронизация двух игроков (позиция, угол, анимация, область, нажатие «говорить»).
//  2) Цепь: за soft метров скорость резко падает и игрока тянет к напарнику
//     (тем сильнее, чем быстрее бежит напарник); дальше hard метров не уйти.
//  3) Разговор с NPC только если оба нажали «взаимодействие» в окне ~3 с.
//  4) Парри: активное окно 6 -> 18 кадров, восстановление 18 -> 6; после успешного парри +20% урона на 5 с.
//  5) Убирает всплывающий баланс душ (попап +N).
// Адреса — цепочки в DSRCombat.ini [offsets] (ищутся калибратором, клавиша U).
#include <winsock2.h>
#include <ws2tcpip.h>
#include <windows.h>

#include <algorithm>
#include <atomic>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <mutex>
#include <string>
#include <vector>

#include "imgui.h"
#include "../common/mem.h"
#include "combat.h"

namespace {

struct Cfg {
    Chain px, ang, area, animId, animTime, parrySucc, atkR, atkL, dmgMult, popupV, popupT, talk, rest;
    bool coopOn = false;
    bool host = true;
    int port = 27015;
    std::string peer;
    float soft = 2.0f, hard = 3.0f, slowStart = 0.6f, pullBase = 0.4f, pullGain = 0.9f;
    int talkWindowMs = 3000;
    float angleSign = 1.0f, angleOff = 0.0f;
    bool parryOn = false;
    std::vector<std::pair<int, int>> parryAnims;
    float fps = 30.0f, activeEndFrame = 0.0f, extraFrames = 12.0f, skipFrames = 12.0f;
    float buffMul = 1.2f;
    int buffMs = 5000;
    bool popupOff = true;
};

Cfg c;
std::mutex g_mx;
uintptr_t g_base;

#pragma pack(push, 1)
struct Pkt {
    uint32_t magic;  // 'DSRC'
    uint32_t seq;
    int32_t area;
    float x, y, z, ang;
    int32_t anim;
    int32_t talkAgeMs;  // сколько мс назад игрок нажал «говорить» (большое число = не нажимал)
    int32_t restAgeMs;  // то же для «отдохнуть у костра»
    float spent;        // накопленная стамина, потраченная игроком самостоятельно (для цепи)
};
#pragma pack(pop)
constexpr uint32_t MAGIC = 0x43525344;
constexpr uint32_t WMAGIC = 0x57525344;  // 'DSRW': пакеты синхронизации мира (world.cpp)

// ---- состояние ----
Pkt g_me{};  // что отправляем
struct PeerState {
    bool ok = false;
    ULONGLONG rx = 0;
    Pkt p{};
    float speed = 0;
    ULONGLONG lastRx = 0;
    float lastX = 0, lastZ = 0;
    bool hasLast = false;
} g_peer;
ULONGLONG g_myTalk = 0;       // когда я нажал «говорить» (0 = нет)
ULONGLONG g_pendingTalk = 0;  // моё нажатие было заблокировано, ждём напарника
ULONGLONG g_myRest = 0, g_pendingRest = 0;  // то же для костра
float g_chainDist = -1;
ULONGLONG g_buffUntil = 0;
std::string g_netStatus = "выключено";
std::vector<std::vector<uint8_t>> g_outbox, g_inbox;  // пакеты мира: из/в world.cpp
std::atomic<bool> g_isHost{true}, g_coopOn{false};

// ---- запись в память ----
template <class T>
bool WrAt(uintptr_t a, T v) {
    if (a < 0x10000) return false;
    __try {
        *reinterpret_cast<T*>(a) = v;
        return true;
    } __except (EXCEPTION_EXECUTE_HANDLER) {
        return false;
    }
}
template <class T>
bool WrCh(const Chain& ch, T v) {
    uintptr_t a = 0;
    return Resolve(ch, g_base, a) && WrAt<T>(a, v);
}

std::string DirOf() {
    char p[MAX_PATH];
    HMODULE m = nullptr;
    GetModuleHandleExA(GET_MODULE_HANDLE_EX_FLAG_FROM_ADDRESS | GET_MODULE_HANDLE_EX_FLAG_UNCHANGED_REFCOUNT,
                       (LPCSTR)&DirOf, &m);
    GetModuleFileNameA(m, p, MAX_PATH);
    std::string s = p;
    return s.substr(0, s.find_last_of("\\/") + 1);
}

std::string IniStr(const std::string& ini, const char* sec, const char* key, const char* def) {
    char b[512] = {};
    GetPrivateProfileStringA(sec, key, "\x01", b, sizeof(b), ini.c_str());
    if (b[0] == '\x01') {  // ключа нет — создаём со значением по умолчанию, чтобы он был виден в файле
        WritePrivateProfileStringA(sec, key, def, ini.c_str());
        return def;
    }
    return b;
}
float IniF(const std::string& ini, const char* sec, const char* key, float def) {
    char d[32];
    snprintf(d, sizeof(d), "%g", def);
    return (float)atof(IniStr(ini, sec, key, d).c_str());
}

// Все цепочки читаются только из DSRCombat.ini.
Chain GetCh(const char* key, const char* mapKey = nullptr, int addToLast = 0) {
    std::string ini = CombatIniPath();
    char b[512] = {};
    GetPrivateProfileStringA("offsets", key, "", b, sizeof(b), ini.c_str());
    Chain ch = ParseChain(b);
    if (ch.valid() && addToLast) ch.v.back() += addToLast;
    return ch;
}

void LoadCfg() {
    std::string ini = CombatIniPath();
    Cfg n;
    n.px = GetCh("pos_x", "player_x");
    n.ang = GetCh("angle", "player_angle");
    n.area = GetCh("area_id", "area_id");
    n.animId = GetCh("anim_id");
    n.animTime = GetCh("anim_time");
    n.parrySucc = GetCh("parry_success");
    n.atkR = GetCh("atk_right");
    n.atkL = GetCh("atk_left");
    n.dmgMult = GetCh("dmg_mult");
    n.popupV = GetCh("souls_popup");
    n.popupT = GetCh("souls_popup_timer");
    n.talk = GetCh("talk_state");
    n.rest = GetCh("rest_state");

    n.coopOn = IniStr(ini, "coop", "enabled", "0") != "0";
    n.port = atoi(IniStr(ini, "coop", "port", "27015").c_str());
    n.peer = IniStr(ini, "coop", "peer_ip", "");
    // role: host = источник истины для врагов/боссов; client = принимает. auto: без peer_ip -> host
    std::string role = IniStr(ini, "coop", "role", "auto");
    n.host = role == "host" || (role != "client" && n.peer.empty());
    n.soft = IniF(ini, "coop", "chain_soft_m", 2.0f);
    n.hard = IniF(ini, "coop", "chain_hard_m", 3.0f);
    n.slowStart = IniF(ini, "coop", "chain_slow_start", 0.6f);
    n.pullBase = IniF(ini, "coop", "pull_base", 0.4f);
    n.pullGain = IniF(ini, "coop", "pull_per_partner_speed", 0.9f);
    n.talkWindowMs = (int)IniF(ini, "coop", "talk_window_ms", 3000);
    n.angleSign = IniF(ini, "coop", "angle_sign", 1.0f);
    n.angleOff = IniF(ini, "coop", "angle_offset", 0.0f);

    n.parryOn = IniStr(ini, "parry", "enabled", "0") != "0";
    n.fps = IniF(ini, "parry", "fps", 30.0f);
    // конец ОРИГИНАЛЬНОГО активного окна парри (кадр анимации). Берётся из TAE (см. документацию по TAE).
    n.activeEndFrame = IniF(ini, "parry", "active_end_frame", 0.0f);
    float oa = IniF(ini, "parry", "orig_active_frames", 6), na = IniF(ini, "parry", "new_active_frames", 18);
    float orc = IniF(ini, "parry", "orig_recovery_frames", 18), nrc = IniF(ini, "parry", "new_recovery_frames", 6);
    n.extraFrames = std::max(0.0f, na - oa);
    n.skipFrames = std::max(0.0f, orc - nrc);
    n.buffMul = IniF(ini, "parry", "buff_multiplier", 1.2f);
    n.buffMs = (int)(IniF(ini, "parry", "buff_seconds", 5.0f) * 1000);
    std::string pa = IniStr(ini, "parry", "anim_ranges", "");  // "8000-8099,9000-9010"
    size_t i = 0;
    while (i < pa.size()) {
        size_t j = pa.find(',', i);
        if (j == std::string::npos) j = pa.size();
        int lo = 0, hi = 0;
        std::string t = pa.substr(i, j - i);
        if (sscanf(t.c_str(), "%d-%d", &lo, &hi) == 2) n.parryAnims.push_back({lo, hi});
        else if (sscanf(t.c_str(), "%d", &lo) == 1) n.parryAnims.push_back({lo, lo});
        i = j + 1;
    }
    n.popupOff = IniStr(ini, "souls", "hide_popup", "1") != "0";
    n.soft = std::max(0.5f, n.soft);
    n.hard = std::max(n.soft + 0.2f, n.hard);

    std::lock_guard<std::mutex> l(g_mx);
    c = n;
    g_isHost = n.host;
    g_coopOn = n.coopOn;
}

// ---- чтение позиции ----
bool ReadPos(float& x, float& y, float& z) {
    uintptr_t a = 0;
    if (!Resolve(c.px, g_base, a)) return false;
    return Rd(a, x) && Rd(a + 4, y) && Rd(a + 8, z) && std::isfinite(x) && std::isfinite(y) && std::isfinite(z);
}
bool WritePosXZ(float x, float z) {
    uintptr_t a = 0;
    if (!Resolve(c.px, g_base, a)) return false;
    return WrAt<float>(a, x) && WrAt<float>(a + 8, z);
}

// ---- сеть ----
SOCKET g_sock = INVALID_SOCKET;
sockaddr_in g_to{};
bool g_haveTo = false;

void NetThread() {
    SetThreadPriority(GetCurrentThread(), THREAD_PRIORITY_BELOW_NORMAL);  // не отбираем CPU у потоков игры
    WSADATA w;
    WSAStartup(MAKEWORD(2, 2), &w);
    int boundPort = -1;
    uint32_t seq = 0;
    ULONGLONG nextSend = 0;
    while (true) {
        Sleep(10);  // сетевой статус не требует опроса 500 раз/с
        bool on;
        int port;
        std::string peer;
        {
            std::lock_guard<std::mutex> l(g_mx);
            on = c.coopOn;
            port = c.port;
            peer = c.peer;
        }
        if (!on || port != boundPort) {
            if (g_sock != INVALID_SOCKET) { closesocket(g_sock); g_sock = INVALID_SOCKET; }
            boundPort = -1;
            g_haveTo = false;
            std::lock_guard<std::mutex> l(g_mx);
            g_peer.ok = false;
            g_netStatus = on ? "ошибка сокета" : "выключено";
            if (!on) { Sleep(200); continue; }
        }
        if (g_sock == INVALID_SOCKET) {
            g_sock = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);
            sockaddr_in a{};
            a.sin_family = AF_INET;
            a.sin_addr.s_addr = INADDR_ANY;
            a.sin_port = htons((u_short)port);
            u_long nb = 1;
            if (g_sock == INVALID_SOCKET || bind(g_sock, (sockaddr*)&a, sizeof(a)) != 0 ||
                ioctlsocket(g_sock, FIONBIO, &nb) != 0) {
                if (g_sock != INVALID_SOCKET) { closesocket(g_sock); g_sock = INVALID_SOCKET; }
                std::lock_guard<std::mutex> l(g_mx);
                g_netStatus = "не удалось открыть порт " + std::to_string(port);
                Sleep(1000);
                continue;
            }
            boundPort = port;
            g_haveTo = false;
            if (!peer.empty()) {
                g_to = {};
                g_to.sin_family = AF_INET;
                g_to.sin_port = htons((u_short)port);
                g_haveTo = inet_pton(AF_INET, peer.c_str(), &g_to.sin_addr) == 1;
            }
        }
        // приём
        uint8_t buf[1500];
        sockaddr_in from{};
        int fl = sizeof(from);
        int rn;
        while ((rn = recvfrom(g_sock, (char*)buf, sizeof(buf), 0, (sockaddr*)&from, &fl)) > 0) {
            fl = sizeof(from);
            uint32_t mg = 0;
            if (rn >= 4) memcpy(&mg, buf, 4);
            if (mg == WMAGIC && rn >= 12) {  // синхронизация мира: кладём в очередь, разберёт world.cpp
                std::lock_guard<std::mutex> l(g_mx);
                if (g_inbox.size() < 512) g_inbox.emplace_back(buf, buf + rn);
                continue;
            }
            if (rn != (int)sizeof(Pkt) || mg != MAGIC) continue;
            Pkt p;
            memcpy(&p, buf, sizeof(p));
            if (!g_haveTo) {  // «хост» без peer_ip: запоминаем адрес первого пакета
                g_to = from;
                g_haveTo = true;
            }
            ULONGLONG now = GetTickCount64();
            std::lock_guard<std::mutex> l(g_mx);
            if (g_peer.hasLast && now > g_peer.lastRx) {
                float dt = (now - g_peer.lastRx) / 1000.0f;
                float d = std::hypot(p.x - g_peer.lastX, p.z - g_peer.lastZ);
                float sp = (d > 8.0f || p.area != g_peer.p.area) ? 0.0f : d / dt;  // скачок = телепорт/загрузка
                g_peer.speed = g_peer.speed * 0.7f + sp * 0.3f;
            }
            g_peer.p = p;
            g_peer.rx = now;
            g_peer.lastRx = now;
            g_peer.lastX = p.x;
            g_peer.lastZ = p.z;
            g_peer.hasLast = true;
            g_peer.ok = true;
        }
        // отправка (60 Гц)
        ULONGLONG now = GetTickCount64();
        if (g_haveTo && now >= nextSend) {
            nextSend = now + 16;
            Pkt s;
            {
                std::lock_guard<std::mutex> l(g_mx);
                s = g_me;
                s.talkAgeMs = g_myTalk ? (int32_t)std::min<ULONGLONG>(now - g_myTalk, 0x7FFFFFF0) : 0x7FFFFFF0;
                s.restAgeMs = g_myRest ? (int32_t)std::min<ULONGLONG>(now - g_myRest, 0x7FFFFFF0) : 0x7FFFFFF0;
                s.spent = ExtrasSpent();
                if (g_peer.ok && now - g_peer.rx > 1500) {
                    g_peer.ok = false;
                    g_peer.speed = 0;
                    g_peer.hasLast = false;
                }
                g_netStatus = g_peer.ok ? "напарник подключён" : "ждём напарника";
            }
            s.magic = MAGIC;
            s.seq = ++seq;
            sendto(g_sock, (const char*)&s, sizeof(s), 0, (sockaddr*)&g_to, sizeof(g_to));
        }
        {  // пакеты синхронизации мира (враги, боссы, урон)
            std::vector<std::vector<uint8_t>> ob;
            {
                std::lock_guard<std::mutex> l(g_mx);
                ob.swap(g_outbox);
            }
            if (g_haveTo)
                for (auto& m : ob) sendto(g_sock, (const char*)m.data(), (int)m.size(), 0, (sockaddr*)&g_to, sizeof(g_to));
        }
    }
}

// ---- цепь ----
std::atomic<bool> g_posOk{false};  // позиция читается (в меню/загрузке — false)
bool g_hasLast = false;
float g_lx, g_ly, g_lz;
ULONGLONG g_lastTick = 0;

void ChainTick() {
    float x, y, z;
    if (!ReadPos(x, y, z)) { g_posOk = false; g_hasLast = false; return; }
    g_posOk = true;
    int32_t area = -1;
    if (c.area.valid()) ReadChain(c.area, g_base, area);
    float ang = 0;
    if (c.ang.valid()) ReadChain(c.ang, g_base, ang);
    int32_t anim = -1;
    if (c.animId.valid()) ReadChain(c.animId, g_base, anim);
    g_me.area = area;
    g_me.x = x; g_me.y = y; g_me.z = z; g_me.ang = ang; g_me.anim = anim;

    ULONGLONG now = GetTickCount64();
    float dt = g_lastTick ? std::min(0.05f, std::max(0.001f, (now - g_lastTick) / 1000.0f)) : 0.008f;
    g_lastTick = now;
    g_chainDist = -1;
    if (!c.coopOn || !g_peer.ok) { g_hasLast = false; return; }
    const Pkt& p = g_peer.p;
    if (c.area.valid() && p.area != area) { g_hasLast = false; return; }  // разные области — цепь выключена
    if (!g_hasLast) { g_lx = x; g_ly = y; g_lz = z; g_hasLast = true; return; }

    float dx = x - g_lx, dz = z - g_lz;
    if (std::hypot(dx, dz) > 6.0f || std::fabs(y - g_ly) > 6.0f) {  // телепорт/загрузка
        g_lx = x; g_ly = y; g_lz = z;
        return;
    }
    float tx = p.x - x, tz = p.z - z;
    float d = std::hypot(tx, tz);
    g_chainDist = d;
    if (std::fabs(p.y - y) > 8.0f || d < 0.05f) { g_lx = x; g_ly = y; g_lz = z; return; }
    float ux = tx / d, uz = tz / d;
    float nx = x, nz = z;
    if (d > c.soft) {
        float t = std::min(1.0f, (d - c.soft) / (c.hard - c.soft));
        float outward = -(dx * ux + dz * uz);  // сколько прошли ОТ напарника с прошлого тика
        if (outward > 0) {
            float f = c.slowStart + (1.0f - c.slowStart) * t;  // резкое торможение сразу за soft
            nx += ux * outward * f;
            nz += uz * outward * f;
        }
        float pull = (c.pullBase + c.pullGain * g_peer.speed) * t * dt;  // чем быстрее напарник, тем сильнее тянет
        pull = std::min(pull, d - c.soft);
        nx += ux * pull;
        nz += uz * pull;
    }
    float rx = p.x - nx, rz = p.z - nz, nd = std::hypot(rx, rz);
    if (nd > c.hard) {  // жёсткий предел
        float k = (nd - c.hard) / nd;
        nx += rx * k;
        nz += rz * k;
    }
    if (nx != x || nz != z) WritePosXZ(nx, nz);
    g_lx = nx; g_ly = y; g_lz = nz;
}

// ---- разговор с NPC только вдвоём ----
// Общий «затвор»: действие (разговор, отдых у костра) разрешено, только если оба нажали в окне talk_window_ms.
struct Gate {
    int32_t prev = 0;
    bool prevOk = false;
    ULONGLONG mine = 0, pending = 0;
};
Gate g_talkGate, g_restGate;

void GateTick(const Chain& ch, Gate& g, int32_t peerAgeMs) {
    if (!c.coopOn || !ch.valid()) return;
    int32_t v = 0;
    if (!ReadChain(ch, g_base, v)) { g.prevOk = false; return; }
    ULONGLONG now = GetTickCount64();
    if (g.prevOk && g.prev == 0 && v != 0) {
        bool partnerRecent = g_peer.ok && peerAgeMs >= 0 &&
                             (ULONGLONG)peerAgeMs + (now - g_peer.rx) < (ULONGLONG)c.talkWindowMs;
        g.mine = now;
        if (partnerRecent) {
            g.pending = 0;  // оба нажали в окне — разрешено
        } else if (WrCh<int32_t>(ch, 0)) {  // закрываем диалог/отдых, ждём напарника
            g.pending = now;
            v = 0;
        }
    }
    g.prev = v;
    g.prevOk = true;
    if (g.mine && now - g.mine > (ULONGLONG)c.talkWindowMs + 500) g.mine = 0;
    if (g.pending && now - g.pending > (ULONGLONG)c.talkWindowMs) g.pending = 0;
}

void TalkTick() {
    GateTick(c.talk, g_talkGate, g_peer.p.talkAgeMs);
    g_myTalk = g_talkGate.mine;
    g_pendingTalk = g_talkGate.pending;
    GateTick(c.rest, g_restGate, g_peer.p.restAgeMs);
    g_myRest = g_restGate.mine;
    g_pendingRest = g_restGate.pending;
}

// ---- парри: окно 6 -> 18, восстановление 18 -> 6, бафф после успеха ----
int g_lastId = -1;
bool g_holding = false, g_holdDone = false;
ULONGLONG g_holdStart = 0;
int32_t g_lastSucc = 0;
bool g_succValid = false;

struct Buffed {
    bool active = false;
    int32_t oi[3] = {}, bi[3] = {};
    float of = 0, bf = 0;
} g_buff;

bool InParry(int id) {
    for (auto& r : c.parryAnims)
        if (id >= r.first && id <= r.second) return true;
    return false;
}

void ApplyBuff(ULONGLONG now) {
    g_buffUntil = now + c.buffMs;
    if (g_buff.active) return;  // уже активен — только продлеваем
    const Chain* ic[2] = {&c.atkR, &c.atkL};
    for (int i = 0; i < 2; ++i) {
        g_buff.oi[i] = g_buff.bi[i] = 0;
        int32_t v;
        if (ic[i]->valid() && ReadChain(*ic[i], g_base, v) && v > 0) {
            g_buff.oi[i] = v;
            g_buff.bi[i] = (int32_t)(v * c.buffMul + 0.5f);
            WrCh<int32_t>(*ic[i], g_buff.bi[i]);
        }
    }
    float f;
    g_buff.of = g_buff.bf = 0;
    if (c.dmgMult.valid() && ReadChain(c.dmgMult, g_base, f) && f > 0) {
        g_buff.of = f;
        g_buff.bf = f * c.buffMul;
        WrCh<float>(c.dmgMult, g_buff.bf);
    }
    g_buff.active = true;
}

void EndBuff() {
    const Chain* ic[2] = {&c.atkR, &c.atkL};
    for (int i = 0; i < 2; ++i) {
        int32_t v;
        if (g_buff.oi[i] && ic[i]->valid() && ReadChain(*ic[i], g_base, v) && v == g_buff.bi[i])
            WrCh<int32_t>(*ic[i], g_buff.oi[i]);
    }
    float f;
    if (g_buff.of > 0 && c.dmgMult.valid() && ReadChain(c.dmgMult, g_base, f) && std::fabs(f - g_buff.bf) < 1e-4f)
        WrCh<float>(c.dmgMult, g_buff.of);
    g_buff.active = false;
    g_buffUntil = 0;
}

void ParryTick() {
    ULONGLONG now = GetTickCount64();
    if (g_buff.active && now >= g_buffUntil) EndBuff();
    if (!c.parryOn) return;

    bool succ = false;
    if (c.parrySucc.valid()) {
        int32_t s;
        if (ReadChain(c.parrySucc, g_base, s)) {
            succ = g_succValid && s != g_lastSucc && s != 0;
            g_lastSucc = s;
            g_succValid = true;
        }
    }
    if (succ && !ExtrasNoDamageBuff()) ApplyBuff(now);

    if (!c.animId.valid() || !c.animTime.valid() || c.activeEndFrame <= 0) return;
    int32_t id = 0;
    float t = 0;
    if (!ReadChain(c.animId, g_base, id) || !ReadChain(c.animTime, g_base, t)) return;
    if (id != g_lastId) {
        g_lastId = id;
        g_holding = false;
        g_holdDone = false;
    }
    if (!InParry(id)) return;

    float endT = c.activeEndFrame / c.fps;
    if (!g_holding && !g_holdDone && t >= endT) {
        g_holding = true;
        g_holdStart = now;
    }
    if (g_holding) {
        if (succ) {  // парри удалось: окно держать больше не нужно
            g_holding = false;
            g_holdDone = true;
        } else if (now - g_holdStart >= (ULONGLONG)(c.extraFrames / c.fps * 1000.0f)) {
            g_holding = false;
            g_holdDone = true;
            WrCh<float>(c.animTime, (c.activeEndFrame + c.skipFrames) / c.fps);  // пропускаем часть восстановления
        } else {
            WrCh<float>(c.animTime, endT - 0.3f / c.fps);  // держим анимацию внутри активного окна
        }
    }
}

// ---- душа: убрать попап баланса ----
void SoulsTick() {
    if (!c.popupOff) return;
    if (c.popupV.valid()) WrCh<int32_t>(c.popupV, 0);
    if (c.popupT.valid()) WrCh<float>(c.popupT, 0.0f);
}

DWORD WINAPI Run(LPVOID) {
    g_base = (uintptr_t)GetModuleHandleA(nullptr);
    SetThreadPriority(GetCurrentThread(), THREAD_PRIORITY_BELOW_NORMAL);
    LoadCfg();
    CreateThread(nullptr, 0, [](LPVOID) -> DWORD { NetThread(); return 0; }, nullptr, 0, nullptr);
    while (true) {
        // Цикл не крутится впустую: если кооператив, парри, скрытие попапа душ и авто-перекат выключены или не
        // настроены, поток спит по 250 мс (или 40 мс, если нужен только опрос клавиши/перезагрузка настроек).
        bool fast;
        {
            std::lock_guard<std::mutex> l(g_mx);
            fast = c.coopOn || c.parryOn || g_buff.active || (c.popupOff && (c.popupV.valid() || c.popupT.valid()));
        }
        bool exFast = ExtrasWantsFast();
        int wait = (fast || exFast) ? (g_posOk ? 8 : 100)  // 125 Гц в игре; в меню/загрузке — 10 Гц
                                    : (ExtrasWantsPoll() ? 40 : 250);
        Sleep(wait);
        if (fast || exFast) {
            std::lock_guard<std::mutex> l(g_mx);
            ChainTick();
            TalkTick();
            ParryTick();
            SoulsTick();
        }
        if (g_coopOn && WorldActive()) WorldTick();  // враги/боссы/урон/напарник (вне блокировки g_mx)
        if (ExtrasWantsPoll()) ExtrasTick();         // авто-перекат (вне блокировки g_mx)
    }
    return 0;
}

}  // namespace

void CoopReloadCfg() { LoadCfg(); WorldReloadCfg(); ExtrasReloadCfg(); }

void CoopStart() {
    WorldReloadCfg();
    CreateThread(nullptr, 0, Run, nullptr, 0, nullptr);
}

bool CoopEnabled() { return g_coopOn; }
bool CoopIsHost() { return g_isHost; }

static void FillView(PeerView& o, const Pkt& p, bool ok, float speed) {
    o.ok = ok; o.area = p.area; o.x = p.x; o.y = p.y; o.z = p.z; o.ang = p.ang; o.anim = p.anim; o.speed = speed; o.spent = p.spent;
}
bool CoopPeerView(PeerView& o) {
    std::lock_guard<std::mutex> l(g_mx);
    FillView(o, g_peer.p, g_peer.ok, g_peer.speed);
    return g_peer.ok;
}
bool CoopMyView(PeerView& o) {
    std::lock_guard<std::mutex> l(g_mx);
    FillView(o, g_me, c.px.valid(), 0);
    return c.px.valid();
}
bool CoopMyPosition(PeerView& o) {
    std::lock_guard<std::mutex> l(g_mx);
    o = PeerView{};
    if (!c.px.valid() || !ReadPos(o.x, o.y, o.z)) return false;
    float angle = 0.0f;
    if (c.ang.valid()) ReadChain(c.ang, g_base, angle);
    if (!std::isfinite(angle)) angle = 0.0f;
    o.ang = angle;
    o.ok = true;
    return true;
}
void CoopSendWorld(const void* d, int n) {
    if (n <= 0 || n > 1400) return;
    std::lock_guard<std::mutex> l(g_mx);
    if (g_outbox.size() > 256) return;
    g_outbox.emplace_back((const uint8_t*)d, (const uint8_t*)d + n);
}
bool CoopPopWorld(std::vector<uint8_t>& out) {
    std::lock_guard<std::mutex> l(g_mx);
    if (g_inbox.empty()) return false;
    out = std::move(g_inbox.front());
    g_inbox.erase(g_inbox.begin());
    return true;
}

bool HudActive() {
    // вызывается из потока рендера: не ждём мьютекс, при занятости берём прошлое значение
    static std::atomic<bool> last{false};
    {
        std::unique_lock<std::mutex> l(g_mx, std::try_to_lock);
        if (l.owns_lock()) last = c.coopOn || g_buff.active;
    }
    return last || WorldHudActive() || ExtrasDebugActive();
}

void HudDraw() {
    ExtrasDrawDebug();
    std::unique_lock<std::mutex> l(g_mx, std::try_to_lock);
    if (!l.owns_lock()) return;  // поток рендера не ждёт логику: пропускаем кадр HUD
    ImDrawList* dl = ImGui::GetForegroundDrawList();
    ImVec2 ds = ImGui::GetIO().DisplaySize;
    float cx = ds.x * 0.5f, y = 60.0f;
    ULONGLONG now = GetTickCount64();
    char b[160];
    if (g_buff.active && g_buffUntil > now) {
        snprintf(b, sizeof(b), "ПАРРИ: +%d%% урона  %.1f c", (int)((c.buffMul - 1.0f) * 100 + 0.5f), (g_buffUntil - now) / 1000.0f);
        dl->AddText(ImVec2(cx - 90, y), IM_COL32(255, 210, 80, 255), b);
        y += 20;
    }
    if (!c.coopOn) return;
    if (!g_peer.ok) {
        snprintf(b, sizeof(b), "Кооператив: %s", g_netStatus.c_str());
        dl->AddText(ImVec2(cx - 100, y), IM_COL32(200, 200, 200, 255), b);
        return;
    }
    if (g_chainDist >= 0) {
        float k = std::min(1.0f, std::max(0.0f, (g_chainDist - c.soft) / (c.hard - c.soft)));
        ImU32 col = IM_COL32((int)(120 + 135 * k), (int)(255 - 155 * k), 120, 255);
        snprintf(b, sizeof(b), "Цепь: %.1f м", g_chainDist);
        dl->AddText(ImVec2(cx - 40, y), col, b);
        // стрелка на напарника (вверх = куда смотрит персонаж)
        float tx = g_peer.p.x - g_me.x, tz = g_peer.p.z - g_me.z;
        float rel = std::atan2(tx, tz) - g_me.ang * c.angleSign - c.angleOff;
        ImVec2 o(cx, y + 50), dir(std::sin(rel), -std::cos(rel)), side(-dir.y, dir.x);
        ImVec2 tip(o.x + dir.x * 22, o.y + dir.y * 22), l1(o.x - dir.x * 12 + side.x * 12, o.y - dir.y * 12 + side.y * 12),
            l2(o.x - dir.x * 12 - side.x * 12, o.y - dir.y * 12 - side.y * 12);
        dl->AddTriangleFilled(tip, l1, l2, col);
        y += 90;
    }
    if (g_pendingTalk && now - g_pendingTalk < (ULONGLONG)c.talkWindowMs) {
        snprintf(b, sizeof(b), "Ждём напарника: нажмите «говорить» вместе (%.1f c)", (c.talkWindowMs - (now - g_pendingTalk)) / 1000.0f);
        dl->AddText(ImVec2(cx - 190, y), IM_COL32(255, 255, 255, 255), b);
    } else if (g_peer.p.talkAgeMs >= 0 && (ULONGLONG)g_peer.p.talkAgeMs + (now - g_peer.rx) < (ULONGLONG)c.talkWindowMs) {
        dl->AddText(ImVec2(cx - 150, y), IM_COL32(255, 255, 255, 255), "Напарник у NPC: нажмите «говорить»");
    }
    y += 20;
    if (g_pendingRest && now - g_pendingRest < (ULONGLONG)c.talkWindowMs) {
        snprintf(b, sizeof(b), "Ждём напарника: отдохните у костра вместе (%.1f c)", (c.talkWindowMs - (now - g_pendingRest)) / 1000.0f);
        dl->AddText(ImVec2(cx - 190, y), IM_COL32(255, 200, 120, 255), b);
    } else if (g_peer.p.restAgeMs >= 0 && (ULONGLONG)g_peer.p.restAgeMs + (now - g_peer.rx) < (ULONGLONG)c.talkWindowMs) {
        dl->AddText(ImVec2(cx - 150, y), IM_COL32(255, 200, 120, 255), "Напарник у костра: отдохните вместе");
    }
}

void CoopUI() {
    ImGui::Separator();
    ImGui::Text("Кооператив / твики (DSRCombat.ini)");
    std::string ini = CombatIniPath();
    static bool init = false;
    static bool en, par, pop;
    static char ip[64];
    if (!init) {
        init = true;
        en = IniStr(ini, "coop", "enabled", "0") != "0";
        par = IniStr(ini, "parry", "enabled", "0") != "0";
        pop = IniStr(ini, "souls", "hide_popup", "1") != "0";
        snprintf(ip, sizeof(ip), "%s", IniStr(ini, "coop", "peer_ip", "").c_str());
    }
    bool ch = false;
    int mode = en ? 1 : 0;
    const char* modes[] = { "Одиночная игра", "LAN-кооператив" };
    if (ImGui::Combo("Режим игры", &mode, modes, IM_ARRAYSIZE(modes))) {
        en = (mode == 1);
        ch = true;
    }
    ImGui::TextDisabled(en
        ? "Кооператив включён: укажите IP напарника или оставьте поле пустым."
        : "Одиночный режим: сетевой обмен и цепь отключены.");
    ch |= ImGui::Checkbox("Парри 6->18 / восстановление 18->6 / бафф", &par);
    ch |= ImGui::Checkbox("Скрывать попап душ", &pop);
    ImGui::InputText("IP напарника (пусто = ждать входящий)", ip, sizeof(ip));
    if (ImGui::Button("Применить")) ch = true;
    if (ch) {
        WritePrivateProfileStringA("coop", "enabled", en ? "1" : "0", ini.c_str());
        WritePrivateProfileStringA("coop", "peer_ip", ip, ini.c_str());
        WritePrivateProfileStringA("parry", "enabled", par ? "1" : "0", ini.c_str());
        WritePrivateProfileStringA("souls", "hide_popup", pop ? "1" : "0", ini.c_str());
        LoadCfg();
    }
    ExtrasUI();
    WorldUI();  // до блокировки g_mx: world.cpp сам обращается к coop
    std::lock_guard<std::mutex> l(g_mx);
    ImGui::TextDisabled("Сеть: %s (порт %d), роль: %s", g_netStatus.c_str(), c.port, c.host ? "хост" : "клиент");
    if (c.parryOn && c.activeEndFrame <= 0)
        ImGui::TextColored(ImVec4(1, 0.7f, 0.3f, 1), "Парри: задайте active_end_frame и anim_ranges в [parry]");
}
