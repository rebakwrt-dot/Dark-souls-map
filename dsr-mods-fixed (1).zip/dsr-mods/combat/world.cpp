#define _CRT_SECURE_NO_WARNINGS
// DSRCombat / world.cpp: синхронизация мира в кооперативе.
//  1) Враги: хост (role=host) — источник истины. Раз в ~33 мс шлёт позиции, углы, анимации и HP ближних
//     врагов; клиент подставляет их в своих одноимённых врагах и отключает им ИИ (иначе у каждого свой мир).
//  2) Боссы: то же, но всегда включены в пакеты первыми (boss_ids), плюс синхронизация флагов событий
//     ([sync_vars]: бой начался / босс убит / туман) — хост -> клиент при изменении.
//  3) Урон: клиент замечает падение HP врага от своих ударов и шлёт «дельту» хосту (с подтверждением и
//     повтором); хост вычитает её у себя. Действия врагов (анимации атак) приходят вместе с анимацией хоста,
//     поэтому хитбоксы работают и на клиенте.
//  4) Напарник: (а) «призрак» — 3D-фигура в мире, рисуется поверх кадра по матрице камеры;
//     (б) «подмена сущности» — реальная модель игры (заранее существующий NPC) ставится в позицию напарника.
// Все адреса задаются цепочками в DSRCombat.ini ([offsets], секции [world], [partner], [sync_vars]).
#include <windows.h>

#include <algorithm>
#include <atomic>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <mutex>
#include <set>
#include <string>
#include <unordered_map>
#include <vector>

#include "imgui.h"
#include "../common/mem.h"
#include "combat.h"

namespace {

// ---------- пакеты ----------
#pragma pack(push, 1)
struct WHdr {
    uint32_t magic;  // 'DSRW'
    uint8_t type;    // 1 враги, 2 урон, 3 подтверждение урона, 4 флаги
    uint8_t n;
    uint16_t pad;
    uint32_t seq;
    int32_t area;
};
struct WEnt {
    int32_t key;
    uint8_t flags;  // бит0 — босс
    float x, y, z, ang;
    int32_t hp, anim;
    float atime;
};
struct WDmg {
    int32_t key;
    int32_t delta;
    uint32_t id;
};
struct WVar {
    int32_t idx;
    uint32_t val;
};
#pragma pack(pop)
constexpr uint32_t WMAGIC = 0x57525344;
enum { T_ENT = 1, T_DMG = 2, T_ACK = 3, T_VAR = 4 };

// ---------- конфиг ----------
struct VarCfg {
    Chain ch;
    uint32_t mask = 0xFFFFFFFFu;
};
struct WCfg {
    bool on = false;
    Chain list, count;
    int stride = 8;
    bool skipFirst = true;
    Chain ex, ey, ez, ehp, eid, eang, eanim, eanimReq, eanimTime, eAi;
    bool matchId = false;
    float radius = 60.0f, smooth = 0.3f, snap = 3.0f;
    int aiOff = 1, aiOn = 0;
    int rateMs = 33;
    std::set<int> bosses;
    int pmode = 1;  // 0 выкл, 1 призрак, 2 подмена сущности, 3 оба
    Chain pEntity;
    int pIndex = -1;
    float pYOff = 0.0f, pAngSign = 1.0f, pAngOff = 0.0f;
    Chain cam;
    bool camT = false;
    std::vector<VarCfg> vars;
};

WCfg W;
std::mutex g_wmx;
uintptr_t g_base = 0;
std::atomic<bool> g_active{false}, g_ghost{false};
std::string g_status = "выключено";
int g_nSynced = 0, g_nLocal = 0;

// ---------- ini ----------
std::string IniStr(const std::string& ini, const char* sec, const char* key, const char* def) {
    char b[512] = {};
    GetPrivateProfileStringA(sec, key, "\x01", b, sizeof(b), ini.c_str());
    if (b[0] == '\x01') {
        WritePrivateProfileStringA(sec, key, def, ini.c_str());
        return def;
    }
    return b;
}
float IniF(const std::string& ini, const char* sec, const char* key, float def) {
    char d[32];
    snprintf(d, sizeof(d), "%g", def);
    return (float)atof(IniStr(ini, sec, key, d).c_str());
}
std::string DirOfIni() {
    std::string s = CombatIniPath();
    return s.substr(0, s.find_last_of("\\/") + 1);
}
// Цепочки берутся только из DSRCombat.ini [offsets].
Chain GetCh(const char* key, const char* mapKey = nullptr) {
    char b[512] = {};
    std::string ini = CombatIniPath();
    GetPrivateProfileStringA("offsets", key, "\x01", b, sizeof(b), ini.c_str());
    if (b[0] == '\x01') WritePrivateProfileStringA("offsets", key, "", ini.c_str());  // создать пустой ключ
    Chain ch = b[0] == '\x01' ? Chain() : ParseChain(b);
    return ch;
}
int GetIntFallback(const char* key, int def) {
    int v = GetPrivateProfileIntA("offsets", key, -12345, CombatIniPath().c_str());
    if (v != -12345) return v;
    return def;
}

void LoadCfg() {
    std::string ini = CombatIniPath();
    WCfg n;
    n.on = IniStr(ini, "world", "enabled", "0") != "0";
    n.matchId = IniStr(ini, "world", "match", "index") == "id";
    n.radius = IniF(ini, "world", "sync_radius", 60.0f);
    n.smooth = std::min(1.0f, std::max(0.05f, IniF(ini, "world", "smooth", 0.3f)));
    n.snap = IniF(ini, "world", "snap_dist", 3.0f);
    n.aiOff = (int)IniF(ini, "world", "ai_off_value", 1);
    n.aiOn = (int)IniF(ini, "world", "ai_on_value", 0);
    n.rateMs = std::max(16, (int)IniF(ini, "world", "send_interval_ms", 33));
    std::string bl = IniStr(ini, "world", "boss_ids", "");  // "3000,3010" (id или индекс — по match)
    for (size_t i = 0; i < bl.size();) {
        size_t j = bl.find(',', i);
        if (j == std::string::npos) j = bl.size();
        int v = atoi(bl.substr(i, j - i).c_str());
        if (v != 0 || bl[i] == '0') n.bosses.insert(v);
        i = j + 1;
    }
    n.list = GetCh("enemy_list", "enemy_list");
    n.count = GetCh("enemy_count", "enemy_count");
    n.ex = GetCh("enemy_x", "enemy_x");
    n.ey = GetCh("enemy_y", "enemy_y");
    n.ez = GetCh("enemy_z", "enemy_z");
    n.ehp = GetCh("enemy_hp", "enemy_hp");
    n.eid = GetCh("enemy_id");
    n.eang = GetCh("enemy_angle");
    n.eanim = GetCh("enemy_anim_id");
    n.eanimReq = GetCh("enemy_anim_req");
    n.eanimTime = GetCh("enemy_anim_time");
    n.eAi = GetCh("enemy_ai_off");
    n.stride = GetIntFallback("enemy_stride", 8);
    n.skipFirst = GetIntFallback("enemy_skip_first", 1) != 0;

    std::string pm = IniStr(ini, "partner", "mode", "ghost");  // off | ghost | entity | both
    n.pmode = pm == "off" ? 0 : pm == "entity" ? 2 : pm == "both" ? 3 : 1;
    n.pIndex = (int)IniF(ini, "partner", "entity_index", -1);
    n.pYOff = IniF(ini, "partner", "y_offset", 0.0f);
    n.pAngSign = IniF(ini, "partner", "angle_sign", 1.0f);
    n.pAngOff = IniF(ini, "partner", "angle_offset", 0.0f);
    n.camT = IniStr(ini, "partner", "cam_matrix_transposed", "0") != "0";
    n.pEntity = GetCh("partner_entity");
    n.cam = GetCh("cam_matrix");

    for (int i = 1; i <= 8; ++i) {
        char k[32], km[40];
        snprintf(k, sizeof(k), "var%d", i);
        snprintf(km, sizeof(km), "var%d_mask", i);
        VarCfg v;
        v.ch = ParseChain(IniStr(ini, "sync_vars", k, ""));
        v.mask = (uint32_t)strtoull(IniStr(ini, "sync_vars", km, "0xFFFFFFFF").c_str(), nullptr, 0);
        n.vars.push_back(v);
    }
    std::lock_guard<std::mutex> l(g_wmx);
    W = n;
    g_active = n.on || n.pmode != 0;
    g_ghost = (n.pmode == 1 || n.pmode == 3) && n.cam.valid();
}

// ---------- запись в память ----------
template <class T>
bool WrW(uintptr_t a, T v) {
    if (a < 0x10000) return false;
    __try {
        *reinterpret_cast<T*>(a) = v;
        return true;
    } __except (EXCEPTION_EXECUTE_HANDLER) {
        return false;
    }
}
template <class T>
bool WrE(const Chain& c, uintptr_t e, T v) {
    uintptr_t a = 0;
    return c.valid() && Resolve(c, e, a) && WrW<T>(a, v);
}

// ---------- враги ----------
struct Ent {
    uintptr_t p = 0;
    int idx = 0;
    int32_t key = 0;
    bool boss = false;
    float x = 0, y = 0, z = 0, ang = 0, at = 0;
    int32_t hp = 1, anim = -1;
};

bool Collect(std::vector<Ent>& out) {
    out.clear();
    uintptr_t la = 0, arr = 0;
    int32_t cnt = 0;
    if (!W.list.valid() || !W.count.valid() || !W.ex.valid() || !W.ez.valid()) return false;
    if (!Resolve(W.list, g_base, la) || !Rd(la, arr) || !arr || !ReadChain(W.count, g_base, cnt)) return false;
    cnt = std::clamp<int32_t>(cnt, 0, 512);
    std::set<int32_t> seen;
    for (int i = W.skipFirst ? 1 : 0; i < cnt; ++i) {
        uintptr_t e = 0;
        if (!Rd(arr + (uintptr_t)i * W.stride, e) || !e) continue;
        Ent n;
        n.p = e;
        n.idx = i;
        if (!ReadChain(W.ex, e, n.x) || !ReadChain(W.ez, e, n.z)) continue;
        ReadChain(W.ey, e, n.y);
        if (!std::isfinite(n.x) || !std::isfinite(n.z)) continue;
        if (W.ehp.valid()) ReadChain(W.ehp, e, n.hp);
        ReadChain(W.eang, e, n.ang);
        ReadChain(W.eanim, e, n.anim);
        ReadChain(W.eanimTime, e, n.at);
        int32_t id = -1;
        if (W.matchId && W.eid.valid() && ReadChain(W.eid, e, id) && id > 0 && !seen.count(id)) n.key = id;
        else n.key = 0x40000000 | i;
        seen.insert(n.key);
        n.boss = W.bosses.count(W.matchId ? n.key : i) > 0;
        out.push_back(n);
    }
    return true;
}

// ---------- состояние ----------
struct Remote {
    WEnt e;
    ULONGLONG rx = 0;
};
struct CS {  // состояние клиента по врагу
    bool hasW = false, aiDone = false;
    int32_t lastW = 0, lastAnim = -2;
};
struct PD {  // неподтверждённый урон клиента
    uint32_t id;
    int32_t key, delta;
    ULONGLONG lastSend;
};
struct AD {  // подтверждённый, но ещё не отражённый в снимке хоста
    int32_t key, delta;
    ULONGLONG until;
};
std::unordered_map<int32_t, Remote> g_remote;
std::unordered_map<int32_t, CS> g_cs;
std::vector<PD> g_pd;
std::vector<AD> g_ad;
std::set<uint32_t> g_applied;  // хост: уже применённые id урона
uint32_t g_dmgId = 0, g_seq = 0;
int32_t g_remoteArea = -2;
ULONGLONG g_nextSend = 0, g_nextWork = 0, g_nextVarSend = 0;
std::unordered_map<int, uint32_t> g_lastVarSent, g_lastVarHost;
uintptr_t g_puppet = 0;
int32_t g_puppetAnim = -2;

void Send(const void* d, int n) { CoopSendWorld(d, n); }

void SendEnts(const std::vector<Ent>& ents, int32_t area) {
    size_t i = 0;
    while (i < ents.size()) {
        uint8_t buf[1400];
        WHdr h{WMAGIC, T_ENT, 0, 0, ++g_seq, area};
        int n = 0;
        uint8_t* w = buf + sizeof(h);
        while (i < ents.size() && n < 35) {
            const Ent& e = ents[i++];
            WEnt s{e.key, (uint8_t)(e.boss ? 1 : 0), e.x, e.y, e.z, e.ang, e.hp, e.anim, e.at};
            memcpy(w, &s, sizeof(s));
            w += sizeof(s);
            ++n;
        }
        h.n = (uint8_t)n;
        memcpy(buf, &h, sizeof(h));
        Send(buf, (int)(w - buf));
    }
}

void SendDmg(ULONGLONG now, bool force) {
    uint8_t buf[1400];
    WHdr h{WMAGIC, T_DMG, 0, 0, ++g_seq, 0};
    uint8_t* w = buf + sizeof(h);
    int n = 0;
    for (auto& d : g_pd) {
        if (n >= 60) break;
        if (!force && now - d.lastSend < 100) continue;
        d.lastSend = now;
        WDmg s{d.key, d.delta, d.id};
        memcpy(w, &s, sizeof(s));
        w += sizeof(s);
        ++n;
    }
    if (!n) return;
    h.n = (uint8_t)n;
    memcpy(buf, &h, sizeof(h));
    Send(buf, (int)(w - buf));
}

// ---------- применение пакетов ----------
void HandlePacket(const std::vector<uint8_t>& m, std::vector<Ent>& ents, ULONGLONG now) {
    if (m.size() < sizeof(WHdr)) return;
    WHdr h;
    memcpy(&h, m.data(), sizeof(h));
    const uint8_t* p = m.data() + sizeof(h);
    size_t left = m.size() - sizeof(h);
    bool host = CoopIsHost();
    if (h.type == T_ENT && !host) {
        g_remoteArea = h.area;
        for (int i = 0; i < h.n && left >= sizeof(WEnt); ++i, p += sizeof(WEnt), left -= sizeof(WEnt)) {
            WEnt e;
            memcpy(&e, p, sizeof(e));
            Remote r;
            r.e = e;
            r.rx = now;
            g_remote[e.key] = r;
        }
    } else if (h.type == T_DMG && host) {
        uint8_t ab[1400];
        WHdr ah{WMAGIC, T_ACK, 0, 0, ++g_seq, 0};
        uint8_t* aw = ab + sizeof(ah);
        int an = 0;
        for (int i = 0; i < h.n && left >= sizeof(WDmg); ++i, p += sizeof(WDmg), left -= sizeof(WDmg)) {
            WDmg d;
            memcpy(&d, p, sizeof(d));
            if (!g_applied.count(d.id)) {
                for (auto& e : ents) {
                    if (e.key != d.key) continue;
                    int32_t hp = 0;
                    if (ReadChain(W.ehp, e.p, hp)) {
                        int32_t nh = std::max(0, hp - std::max(0, d.delta));
                        WrE<int32_t>(W.ehp, e.p, nh);
                        e.hp = nh;
                    }
                    break;
                }
                g_applied.insert(d.id);
                if (g_applied.size() > 2048) g_applied.erase(g_applied.begin());
            }
            memcpy(aw, &d, sizeof(d));
            aw += sizeof(d);
            ++an;
        }
        if (an) {
            ah.n = (uint8_t)an;
            memcpy(ab, &ah, sizeof(ah));
            Send(ab, (int)(aw - ab));
        }
    } else if (h.type == T_ACK && !host) {
        for (int i = 0; i < h.n && left >= sizeof(WDmg); ++i, p += sizeof(WDmg), left -= sizeof(WDmg)) {
            WDmg d;
            memcpy(&d, p, sizeof(d));
            for (size_t k = 0; k < g_pd.size(); ++k)
                if (g_pd[k].id == d.id) {
                    g_ad.push_back({g_pd[k].key, g_pd[k].delta, now + 400});
                    g_pd.erase(g_pd.begin() + k);
                    break;
                }
        }
    } else if (h.type == T_VAR && !host) {
        for (int i = 0; i < h.n && left >= sizeof(WVar); ++i, p += sizeof(WVar), left -= sizeof(WVar)) {
            WVar v;
            memcpy(&v, p, sizeof(v));
            if (v.idx < 0 || v.idx >= (int)W.vars.size() || !W.vars[v.idx].ch.valid()) continue;
            auto it = g_lastVarHost.find(v.idx);
            bool first = it == g_lastVarHost.end();
            if (!first && it->second == v.val) continue;
            g_lastVarHost[v.idx] = v.val;
            if (first) continue;  // первое значение только запоминаем, чтобы не перетереть чужие флаги
            uintptr_t a = 0;
            uint32_t cur = 0;
            if (Resolve(W.vars[v.idx].ch, g_base, a) && Rd(a, cur)) {
                uint32_t mk = W.vars[v.idx].mask;
                WrW<uint32_t>(a, (cur & ~mk) | (v.val & mk));
            }
        }
    }
}

// ---------- хост ----------
void HostTick(ULONGLONG now, std::vector<Ent>& ents, const PeerView& me, const PeerView& pe) {
    if (now >= g_nextSend) {
        g_nextSend = now + W.rateMs;
        std::vector<std::pair<float, Ent>> sel;
        float r2 = W.radius * W.radius;
        for (auto& e : ents) {
            float d1 = (e.x - me.x) * (e.x - me.x) + (e.z - me.z) * (e.z - me.z);
            float d2 = (e.x - pe.x) * (e.x - pe.x) + (e.z - pe.z) * (e.z - pe.z);
            float d = std::min(d1, d2);
            if (e.boss) d = -1.0f;  // боссы всегда первыми и вне радиуса
            else if (d > r2) continue;
            sel.push_back({d, e});
        }
        std::sort(sel.begin(), sel.end(), [](const auto& a, const auto& b) { return a.first < b.first; });
        if (sel.size() > 70) sel.resize(70);
        std::vector<Ent> out;
        for (auto& s : sel) out.push_back(s.second);
        SendEnts(out, me.area);
        g_nSynced = (int)out.size();
    }
    // флаги событий (бой с боссом, убийство босса и т.п.): при изменении и раз в 0,5 с
    bool all = now >= g_nextVarSend;
    if (all) g_nextVarSend = now + 500;
    uint8_t buf[512];
    WHdr h{WMAGIC, T_VAR, 0, 0, ++g_seq, me.area};
    uint8_t* w = buf + sizeof(h);
    int n = 0;
    for (int i = 0; i < (int)W.vars.size(); ++i) {
        uint32_t v = 0;
        if (!W.vars[i].ch.valid() || !ReadChain(W.vars[i].ch, g_base, v)) continue;
        v &= W.vars[i].mask;
        auto it = g_lastVarSent.find(i);
        if (!all && it != g_lastVarSent.end() && it->second == v) continue;
        g_lastVarSent[i] = v;
        WVar s{i, v};
        memcpy(w, &s, sizeof(s));
        w += sizeof(s);
        ++n;
    }
    if (n) {
        h.n = (uint8_t)n;
        memcpy(buf, &h, sizeof(h));
        Send(buf, (int)(w - buf));
    }
}

// ---------- клиент ----------
void ClientTick(ULONGLONG now, std::vector<Ent>& ents, const PeerView& me) {
    // убрать просроченные записи об уроне
    g_ad.erase(std::remove_if(g_ad.begin(), g_ad.end(), [&](const AD& a) { return a.until < now; }), g_ad.end());
    int applied = 0;
    for (auto& e : ents) {
        auto it = g_remote.find(e.key);
        CS& cs = g_cs[e.key];
        if (it == g_remote.end() || now - it->second.rx > 1500 || g_remoteArea != me.area) {
            if (cs.aiDone) {  // связь с хостом потеряна: вернуть ИИ
                WrE<int32_t>(W.eAi, e.p, W.aiOn);
                cs.aiDone = false;
            }
            cs.hasW = false;
            continue;
        }
        const WEnt& r = it->second.e;
        ++applied;
        // ИИ клиента выключен: врагом управляет хост
        WrE<int32_t>(W.eAi, e.p, W.aiOff);
        cs.aiDone = true;
        // позиция и угол
        float dx = r.x - e.x, dz = r.z - e.z;
        float d = std::hypot(dx, dz);
        float k = d > W.snap ? 1.0f : W.smooth;
        WrE<float>(W.ex, e.p, e.x + dx * k);
        WrE<float>(W.ez, e.p, e.z + dz * k);
        if (W.ey.valid()) WrE<float>(W.ey, e.p, e.y + (r.y - e.y) * k);
        if (W.eang.valid()) WrE<float>(W.eang, e.p, r.ang);
        // анимация (действия врага)
        if (r.anim != cs.lastAnim) {
            cs.lastAnim = r.anim;
            if (W.eanimReq.valid()) WrE<int32_t>(W.eanimReq, e.p, r.anim);
        } else if (W.eanimTime.valid() && std::fabs(e.at - r.atime) > 0.25f) {
            WrE<float>(W.eanimTime, e.p, r.atime);
        }
        // HP и урон от нашего игрока
        if (W.ehp.valid()) {
            int32_t cur = e.hp;
            if (cs.hasW && cur < cs.lastW) {  // это мы ударили врага -> сообщаем хосту
                PD d2{++g_dmgId, e.key, cs.lastW - cur, 0};
                g_pd.push_back(d2);
            }
            int32_t pend = 0;
            for (auto& p : g_pd) if (p.key == e.key) pend += p.delta;
            for (auto& a : g_ad) if (a.key == e.key) pend += a.delta;
            int32_t target = std::max(0, r.hp - pend);
            if (target != cur) WrE<int32_t>(W.ehp, e.p, target);
            cs.lastW = target;
            cs.hasW = true;
        }
    }
    g_nSynced = applied;
    if (!g_pd.empty()) SendDmg(now, false);
}

// ---------- напарник: подмена сущности ----------
void PuppetTick(const PeerView& pe, std::vector<Ent>& ents) {
    g_puppet = 0;
    if (W.pmode != 2 && W.pmode != 3) return;
    uintptr_t p = 0;
    if (W.pEntity.valid()) {
        uintptr_t a = 0;
        if (Resolve(W.pEntity, g_base, a)) Rd(a, p);
    } else if (W.pIndex >= 0) {
        for (auto& e : ents)
            if (e.idx == W.pIndex) { p = e.p; break; }
    }
    if (!p) return;
    g_puppet = p;
    ents.erase(std::remove_if(ents.begin(), ents.end(), [&](const Ent& e) { return e.p == p; }), ents.end());
    if (!pe.ok) return;
    WrE<float>(W.ex, p, pe.x);
    WrE<float>(W.ey, p, pe.y + W.pYOff);
    WrE<float>(W.ez, p, pe.z);
    if (W.eang.valid()) WrE<float>(W.eang, p, pe.ang);
    WrE<int32_t>(W.eAi, p, W.aiOff);
    if (pe.anim != g_puppetAnim) {
        g_puppetAnim = pe.anim;
        if (W.eanimReq.valid() && pe.anim >= 0) WrE<int32_t>(W.eanimReq, p, pe.anim);
    }
}

}  // namespace

// ================= публичный интерфейс =================
void WorldReloadCfg() {
    g_base = (uintptr_t)GetModuleHandleA(nullptr);
    if (!g_dmgId) g_dmgId = (uint32_t)GetTickCount();  // id урона уникальны между запусками
    LoadCfg();
}

void WorldTick() {
    if (!g_active) { Sleep(20); return; }
    ULONGLONG now = GetTickCount64();
    if (now < g_nextWork) return;
    g_nextWork = now + 16;

    std::lock_guard<std::mutex> l(g_wmx);
    PeerView me, pe;
    bool havePeer = CoopEnabled() && CoopPeerView(pe);
    CoopMyView(me);
    std::vector<uint8_t> m;
    std::vector<Ent> ents;
    bool listOk = Collect(ents);
    g_nLocal = (int)ents.size();

    // подмена сущности напарником (до синхронизации: эта сущность в обмене не участвует)
    if (listOk || W.pEntity.valid()) PuppetTick(pe, ents);

    if (!CoopEnabled()) { g_status = "кооператив выключен"; while (CoopPopWorld(m)) {} return; }
    if (!havePeer) { g_status = "ждём напарника"; while (CoopPopWorld(m)) {} return; }
    if (!W.on) { g_status = "синхронизация мира выключена"; while (CoopPopWorld(m)) {} return; }
    if (!listOk) { g_status = "не заданы enemy_list/enemy_count/enemy_x/enemy_z"; while (CoopPopWorld(m)) {} return; }
    while (CoopPopWorld(m)) HandlePacket(m, ents, now);
    if (me.area != pe.area) { g_status = "напарник в другой области"; return; }

    if (CoopIsHost()) {
        HostTick(now, ents, me, pe);
        g_status = "хост: враги/боссы синхронизируются";
    } else {
        if (!W.ehp.valid()) g_status = "клиент: нет enemy_hp (урон не передаётся)";
        else g_status = "клиент: принимаем мир хоста";
        ClientTick(now, ents, me);
    }
}

bool WorldEnemies(std::vector<EnemyView>& out) {
    out.clear();
    if (!g_base) g_base = (uintptr_t)GetModuleHandleA(nullptr);
    std::lock_guard<std::mutex> l(g_wmx);
    std::vector<Ent> e;
    if (!Collect(e)) return false;
    for (auto& n : e) {
        EnemyView v;
        v.x = n.x; v.y = n.y; v.z = n.z; v.ang = n.ang; v.animTime = n.at; v.anim = n.anim; v.ptr = n.p;
        out.push_back(v);
    }
    return true;
}
bool WorldEnemyPositions(std::vector<EnemyView>& out) {
    out.clear();
    if (!g_base) g_base = (uintptr_t)GetModuleHandleA(nullptr);
    std::lock_guard<std::mutex> l(g_wmx);
    uintptr_t listAddress = 0, array = 0;
    int32_t count = 0;
    // enemy_count не задан числовой цепочкой (например «scan») — режим сканирования: читаем массив,
    // пока подряд не встретится 8 непригодных элементов.
    const bool scan = !W.count.valid();
    if (!W.list.valid() || !W.ex.valid() || !W.ez.valid()) return false;
    if (!Resolve(W.list, g_base, listAddress) || !Rd(listAddress, array) || !array) return false;
    if (scan) count = 512;
    else if (!ReadChain(W.count, g_base, count)) return false;
    count = std::clamp<int32_t>(count, 0, 512);
    const int stride = std::clamp(W.stride, 4, 256);
    int bad = 0;
    for (int i = W.skipFirst ? 1 : 0; i < count; ++i) {
        uintptr_t entity = 0;
        if (!Rd(array + (uintptr_t)i * (uintptr_t)stride, entity)) { if (scan) break; continue; }
        EnemyView v{};
        v.ptr = entity;
        v.anim = -1; // намеренно не читаем animation ID/time
        bool ok = entity >= 0x10000 && ReadChain(W.ex, entity, v.x) && ReadChain(W.ez, entity, v.z);
        if (ok) {
            v.hasY = W.ey.valid() && ReadChain(W.ey, entity, v.y);
            if (W.eang.valid()) ReadChain(W.eang, entity, v.ang);
            if (W.eid.valid()) { int32_t id = -1; if (ReadChain(W.eid, entity, id)) v.entityId = id; }
            ok = std::isfinite(v.x) && std::isfinite(v.y) && std::isfinite(v.z) && std::isfinite(v.ang) &&
                 std::fabs(v.x) < 1e5f && std::fabs(v.z) < 1e5f;
        }
        if (!ok) { if (scan && ++bad >= 8) break; continue; }
        bad = 0;
        out.push_back(v);
    }
    return true;
}

bool WorldEnemyWriteAnim(uintptr_t ptr, int32_t anim) {
    std::lock_guard<std::mutex> l(g_wmx);
    return WrE<int32_t>(W.eanimReq, ptr, anim);
}

bool WorldHudActive() { return g_ghost; }
bool WorldActive() { return g_active; }

static bool W2S(const float* m, bool T, float x, float y, float z, ImVec2 ds, ImVec2& out) {
    float cx, cy, cw;
    if (!T) {
        cx = m[0] * x + m[1] * y + m[2] * z + m[3];
        cy = m[4] * x + m[5] * y + m[6] * z + m[7];
        cw = m[12] * x + m[13] * y + m[14] * z + m[15];
    } else {
        cx = m[0] * x + m[4] * y + m[8] * z + m[12];
        cy = m[1] * x + m[5] * y + m[9] * z + m[13];
        cw = m[3] * x + m[7] * y + m[11] * z + m[15];
    }
    if (!(cw > 0.05f)) return false;
    out = ImVec2((cx / cw * 0.5f + 0.5f) * ds.x, (0.5f - cy / cw * 0.5f) * ds.y);
    return std::isfinite(out.x) && std::isfinite(out.y);
}

// «Призрак» напарника: 3D-фигура по матрице камеры (не модель игры, но стоит в мире и двигается)
void WorldHudDraw() {
    if (!g_ghost) return;
    std::unique_lock<std::mutex> l(g_wmx, std::try_to_lock);
    if (!l.owns_lock()) return;  // WorldTick держит мьютекс — не блокируем рендер
    if (!CoopEnabled()) return;
    PeerView pe, me;
    if (!CoopPeerView(pe)) return;
    CoopMyView(me);
    if (pe.area != me.area) return;

    float m[16];
    uintptr_t a = 0;
    if (!Resolve(W.cam, g_base, a)) return;
    for (int i = 0; i < 16; ++i)
        if (!Rd(a + 4 * i, m[i]) || !std::isfinite(m[i])) return;

    ImDrawList* dl = ImGui::GetForegroundDrawList();
    ImVec2 ds = ImGui::GetIO().DisplaySize;
    float ang = pe.ang * W.pAngSign + W.pAngOff;
    float fx = std::sin(ang), fz = std::cos(ang), sx = fz, sz = -fx;  // вперёд и вправо
    float t = (float)ImGui::GetTime();
    float mv = std::min(1.0f, pe.speed / 4.0f);
    float sw = std::sin(t * 7.0f) * 0.32f * mv;
    float by = pe.y + W.pYOff;

    struct J { float s, u, f; };
    auto P = [&](J j, ImVec2& o) { return W2S(m, W.camT, pe.x + sx * j.s + fx * j.f, by + j.u, pe.z + sz * j.s + fz * j.f, ds, o); };
    ImVec2 head, neck, shL, shR, hipL, hipR, hdL, hdR, ftL, ftR, kL, kR, top, bot;
    bool ok = P({0, 1.68f, 0}, head) && P({0, 1.48f, 0}, neck) && P({-0.22f, 1.45f, 0}, shL) && P({0.22f, 1.45f, 0}, shR) &&
              P({-0.13f, 0.95f, 0}, hipL) && P({0.13f, 0.95f, 0}, hipR) && P({-0.3f, 0.95f, sw}, hdL) &&
              P({0.3f, 0.95f, -sw}, hdR) && P({-0.13f, 0.0f, -sw}, ftL) && P({0.13f, 0.0f, sw}, ftR) &&
              P({-0.13f, 0.5f, -sw * 0.5f}, kL) && P({0.13f, 0.5f, sw * 0.5f}, kR) && P({0, 1.85f, 0}, top) && P({0, 0, 0}, bot);
    if (!ok) return;
    float h = std::fabs(bot.y - top.y);
    if (h < 6.0f || h > ds.y * 3.0f) return;
    float th = std::max(2.0f, h * 0.07f);
    ImU32 col = IM_COL32(120, 220, 255, 210), fill = IM_COL32(120, 220, 255, 70);
    ImVec2 body[4] = {shL, shR, hipR, hipL};
    dl->AddConvexPolyFilled(body, 4, fill);
    dl->AddQuad(shL, shR, hipR, hipL, col, 2.0f);
    dl->AddCircleFilled(head, h * 0.065f, fill);
    dl->AddCircle(head, h * 0.065f, col, 16, 2.0f);
    dl->AddLine(neck, ImVec2((shL.x + shR.x) * 0.5f, (shL.y + shR.y) * 0.5f), col, th);
    dl->AddLine(shL, hdL, col, th * 0.8f);
    dl->AddLine(shR, hdR, col, th * 0.8f);
    dl->AddLine(hipL, kL, col, th);
    dl->AddLine(kL, ftL, col, th);
    dl->AddLine(hipR, kR, col, th);
    dl->AddLine(kR, ftR, col, th);
    char b[64];
    float dist = std::hypot(pe.x - me.x, pe.z - me.z);
    snprintf(b, sizeof(b), "Напарник  %.1f м", dist);
    ImVec2 ts = ImGui::CalcTextSize(b);
    dl->AddText(ImVec2(top.x - ts.x * 0.5f, top.y - ts.y - 6), IM_COL32(255, 255, 255, 255), b);
}

void WorldUI() {
    std::lock_guard<std::mutex> l(g_wmx);
    ImGui::Separator();
    ImGui::Text("Мир: враги / боссы / урон / напарник (DSRCombat.ini)");
    std::string ini = CombatIniPath();
    static bool init = false, on = false;
    static int pm = 1;
    if (!init) {
        init = true;
        on = W.on;
        pm = W.pmode;
    }
    bool ch = ImGui::Checkbox("Синхронизация врагов и боссов (хост — источник)", &on);
    const char* modes[] = {"выкл", "призрак (3D по камере)", "подмена сущности игры", "оба"};
    ch |= ImGui::Combo("Напарник в мире", &pm, modes, 4);
    if (ch) {
        WritePrivateProfileStringA("world", "enabled", on ? "1" : "0", ini.c_str());
        const char* pn[] = {"off", "ghost", "entity", "both"};
        WritePrivateProfileStringA("partner", "mode", pn[pm], ini.c_str());
        // LoadCfg берёт g_wmx сам — освободим блокировку нельзя внутри UI, поэтому применим сразу к копии
        W.on = on;
        W.pmode = pm;
        g_active = W.on || W.pmode != 0;
        g_ghost = (W.pmode == 1 || W.pmode == 3) && W.cam.valid();
    }
    ImGui::TextDisabled("Статус: %s", g_status.c_str());
    ImGui::TextDisabled("Врагов в списке: %d, синхронизируется: %d, неподтверждённого урона: %d", g_nLocal, g_nSynced,
                        (int)g_pd.size());
    if ((W.pmode == 1 || W.pmode == 3) && !W.cam.valid())
        ImGui::TextColored(ImVec4(1, 0.7f, 0.3f, 1), "Призрак: задайте cam_matrix (16 float) в [offsets]");
    if ((W.pmode == 2 || W.pmode == 3) && !W.pEntity.valid() && W.pIndex < 0)
        ImGui::TextColored(ImVec4(1, 0.7f, 0.3f, 1), "Подмена: задайте partner_entity или [partner] entity_index");
}
