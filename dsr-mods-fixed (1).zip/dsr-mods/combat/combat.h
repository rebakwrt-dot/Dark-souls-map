#pragma once
#include <windows.h>
#include <dxgi.h>

#include <cstdint>
#include <string>
#include <vector>

// Общий интерфейс между combat.cpp (логика модов) и calib.cpp (оверлей-калибратор).
std::string CombatIniPath();
void CombatReloadCfg();     // перечитать DSRCombat.ini (после записи цепочек калибратором)
void CalibStart(HMODULE self);  // запуск оверлея калибровки (клавиша U)

// Кооператив / твики (coop.cpp)
void CoopStart();
void CoopReloadCfg();
bool HudActive();
void HudDraw();
void CoopUI();

// Данные игрока/напарника для world.cpp
struct PeerView {
    bool ok = false;
    int32_t area = -1;
    float x = 0, y = 0, z = 0, ang = 0;
    int32_t anim = -1;
    float speed = 0;
    float spent = 0;  // накопленная самостоятельно потраченная стамина
};
bool CoopEnabled();
bool CoopIsHost();
bool CoopPeerView(PeerView& out);  // false, если напарника нет
bool CoopMyView(PeerView& out);
bool CoopMyPosition(PeerView& out); // только координаты и угол, без анимационных полей
void CoopSendWorld(const void* data, int n);  // в очередь отправки (UDP)
bool CoopPopWorld(std::vector<uint8_t>& out);  // принятые пакеты мира

// Мир: синхронизация врагов/боссов/урона, 3D-напарник (world.cpp)
void WorldReloadCfg();
void WorldTick();
bool WorldHudActive();
bool WorldActive();  // нужна ли синхронизация мира (иначе цикл логики её не вызывает)
void WorldHudDraw();
void WorldUI();

// Сюжетные роли и твики (extras.cpp): человек (хост) / красный фантом (клиент)
void ExtrasTick();
void ExtrasReloadCfg();
bool ExtrasNoDamageBuff();
bool ExtrasDebugActive();  // нужна ли отрисовка отладки (поток рендера)
void ExtrasDrawDebug();    // рисует снимок отладки; только из потока рендера  // true: у человека парри не даёт +урон (вместо него бафф стамины)
float ExtrasSpent();
void ExtrasUI();
struct EnemyView {
    float x = 0, y = 0, z = 0, ang = 0, animTime = 0;
    int32_t anim = -1;
    int32_t entityId = -1;  // Entity ID из enemy_id (если цепочка задана), иначе -1
    uintptr_t ptr = 0;
    bool hasY = false;
};
bool WorldEnemies(std::vector<EnemyView>& out);  // полный набор данных для синхронизации мира
bool WorldEnemyPositions(std::vector<EnemyView>& out); // только координаты/углы для геометрического прогнозирования
bool WorldEnemyWriteAnim(uintptr_t ptr, int32_t anim);

// Горячие клавиши: пауза (P), инвентарь (I) — hotkeys.cpp, только из потока рендера
void HotkeysPresent(bool typing);
bool HotkeysOverlayActive();
void HotkeysDraw();
void HotkeysAfterPresent();
bool ExtrasWantsFast();  // авто-перекат включён и настроен: нужен частый опрос
bool ExtrasWantsPoll();  // нужен хотя бы редкий опрос (клавиша переключения, перезагрузка настроек)
