// Калибратор: оверлей поверх игры (клавиша U), упрощённый «Cheat Engine» только для чтения.
// Ищет значения в памяти (точное / изменилось / больше / меньше), по кнопке «Это оно»
// сам находит цепочку указателей от статической памяти exe и записывает её в DSRCombat.ini.
// Значения в игре калибратор НЕ меняет.
#define _CRT_SECURE_NO_WARNINGS
#include <windows.h>
#include <d3d11.h>
#include <dxgi.h>

#include <algorithm>
#include <atomic>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <mutex>
#include <string>
#include <thread>
#include <vector>

#include "backends/imgui_impl_dx11.h"
#include "backends/imgui_impl_win32.h"
#include "imgui.h"

#include "../common/dx11_hook.h"
#include "../map/mem.h"
#include "combat.h"

extern IMGUI_IMPL_API LRESULT ImGui_ImplWin32_WndProcHandler(HWND, UINT, WPARAM, LPARAM);

namespace {

// Адреса в наших структурах хранятся «замаскированными», чтобы сканер указателей
// не находил собственные векторы как ложные указатели.
constexpr uint64_t KEY = 0xA5A5A5A5A5A5A5A5ull;
inline uint64_t Enc(uintptr_t a) { return (uint64_t)a ^ KEY; }
inline uintptr_t Dec(uint64_t e) { return (uintptr_t)(e ^ KEY); }

enum class Type { I32, F32 };
enum class Mode { Exact, Changed, Unchanged, Inc, Dec };

struct Hit {
    uint64_t a;
    uint32_t prev;
};

struct Field {
    const char* key;
    const char* label;
    Type t;
    std::string chain;
};

Field F[] = {
    {"hp", "HP", Type::I32, ""},
    {"max_hp", "Макс. HP", Type::I32, ""},
    {"estus", "Эстус (кол-во)", Type::I32, ""},
    {"stamina", "Стамина", Type::I32, ""},
    {"anim_id", "ID анимации", Type::I32, ""},
    {"anim_time", "Время анимации (сек)", Type::F32, ""},
};
constexpr int NF = sizeof(F) / sizeof(F[0]);

HMODULE g_self;
bool g_init = false, g_open = false, g_prevU = false;
HWND g_hwnd;
ID3D11Device* g_dev;
ID3D11DeviceContext* g_ctx;
WNDPROC g_oldProc;

std::vector<Hit> g_hits;
std::atomic<bool> g_busy{false};
std::atomic<float> g_progress{0};
std::mutex g_msx;
std::string g_status = "Выберите величину, введите её текущее значение и нажмите «Первый скан».";

int g_sel = 0, g_depth = 4, g_maxOff = 0x400;
char g_val[32] = "";

void SetStatus(const std::string& s) {
    std::lock_guard<std::mutex> l(g_msx);
    g_status = s;
}
std::string GetStatus() {
    std::lock_guard<std::mutex> l(g_msx);
    return g_status;
}

bool ReadU32(uintptr_t a, uint32_t& v) {
    SIZE_T got = 0;
    return ReadProcessMemory(GetCurrentProcess(), (LPCVOID)a, &v, 4, &got) && got == 4;
}

std::vector<std::pair<uintptr_t, size_t>> Regions() {
    std::vector<std::pair<uintptr_t, size_t>> r;
    SYSTEM_INFO si;
    GetSystemInfo(&si);
    uintptr_t a = (uintptr_t)si.lpMinimumApplicationAddress, end = (uintptr_t)si.lpMaximumApplicationAddress;
    MEMORY_BASIC_INFORMATION mbi;
    const DWORD wr = PAGE_READWRITE | PAGE_WRITECOPY | PAGE_EXECUTE_READWRITE | PAGE_EXECUTE_WRITECOPY;
    while (a < end && VirtualQuery((LPCVOID)a, &mbi, sizeof(mbi))) {
        if (mbi.State == MEM_COMMIT && mbi.Type != MEM_MAPPED && !(mbi.Protect & (PAGE_GUARD | PAGE_NOACCESS)) &&
            (mbi.Protect & wr))
            r.push_back({(uintptr_t)mbi.BaseAddress, (size_t)mbi.RegionSize});
        a = (uintptr_t)mbi.BaseAddress + mbi.RegionSize;
    }
    return r;
}

// fn(адрес_начала_куска, данные, размер) -> false = остановить
template <class Fn>
void ForEachMem(const std::vector<std::pair<uintptr_t, size_t>>& regs, Fn fn) {
    size_t total = 0, done = 0;
    for (auto& r : regs) total += r.second;
    if (!total) return;
    std::vector<uint8_t> buf(1 << 20);
    uintptr_t b0 = (uintptr_t)buf.data(), b1 = b0 + buf.size();
    for (auto& r : regs) {
        for (size_t off = 0; off < r.second; off += buf.size()) {
            size_t n = std::min(buf.size(), r.second - off);
            uintptr_t a = r.first + off;
            done += n;
            g_progress = (float)done / (float)total;
            if (a < b1 && a + n > b0) continue;  // не сканируем собственный буфер
            SIZE_T got = 0;
            ReadProcessMemory(GetCurrentProcess(), (LPCVOID)a, buf.data(), n, &got);
            if (got && !fn(a, buf.data(), (size_t)got)) return;
        }
    }
}

bool Cmp(Mode m, Type t, uint32_t prev, uint32_t cur, double val) {
    if (t == Type::I32) {
        int32_t p = (int32_t)prev, c = (int32_t)cur;
        switch (m) {
            case Mode::Exact: return c == (int32_t)val;
            case Mode::Changed: return c != p;
            case Mode::Unchanged: return c == p;
            case Mode::Inc: return c > p;
            case Mode::Dec: return c < p;
        }
    } else {
        float p, c;
        memcpy(&p, &prev, 4);
        memcpy(&c, &cur, 4);
        if (!std::isfinite(c)) return false;
        switch (m) {
            case Mode::Exact: return std::fabs(c - (float)val) <= 0.0005f;
            case Mode::Changed: return c != p;
            case Mode::Unchanged: return c == p;
            case Mode::Inc: return c > p;
            case Mode::Dec: return c < p;
        }
    }
    return false;
}

constexpr size_t MAXHITS = 4000000;

void FirstScan(Type t, double val) {
    std::vector<Hit> out;
    bool over = false;
    ForEachMem(Regions(), [&](uintptr_t base, const uint8_t* b, size_t n) {
        for (size_t i = 0; i + 4 <= n; i += 4) {
            uint32_t raw;
            memcpy(&raw, b + i, 4);
            if (Cmp(Mode::Exact, t, 0, raw, val)) {
                out.push_back({Enc(base + i), raw});
                if (out.size() > MAXHITS) { over = true; return false; }
            }
        }
        return true;
    });
    if (over) {
        out.clear();
        SetStatus("Слишком много совпадений. Возьмите более редкое значение (напр. HP не 100, а текущее точное).");
    } else {
        SetStatus("Найдено: " + std::to_string(out.size()) + ". Измените величину в игре и сделайте «Следующий скан».");
    }
    g_hits.swap(out);
}

void AroundScan(uintptr_t center, uintptr_t span) {
    std::vector<Hit> out;
    uintptr_t lo = (center - span) & ~3ull, hi = center + span;
    for (uintptr_t a = lo; a < hi; a += 4) {
        uint32_t v;
        if (ReadU32(a, v)) out.push_back({Enc(a), v});
    }
    SetStatus("Кандидатов рядом: " + std::to_string(out.size()) + ". Делайте «Следующий скан» (изменилось/больше/меньше).");
    g_hits.swap(out);
}

void NextScan(Mode m, Type t, double val) {
    std::vector<Hit> keep;
    keep.reserve(g_hits.size() / 4 + 16);
    size_t i = 0;
    for (auto& h : g_hits) {
        uint32_t cur;
        if (ReadU32(Dec(h.a), cur) && Cmp(m, t, h.prev, cur, val)) {
            Hit n = h;
            n.prev = cur;
            keep.push_back(n);
        }
        g_progress = (float)(++i) / (float)g_hits.size();
    }
    g_hits.swap(keep);
    SetStatus("Осталось: " + std::to_string(g_hits.size()) + (g_hits.size() <= 15 ? ". Выберите нужный и нажмите «Это оно»." : "."));
}

// Поиск цепочки указателей от статической памяти exe до адреса A.
bool PtrScan(uintptr_t A, int maxDepth, uintptr_t maxOff, std::string& out) {
    uintptr_t base = (uintptr_t)GetModuleHandleA(nullptr);
    auto* nt = (IMAGE_NT_HEADERS*)(base + ((IMAGE_DOS_HEADER*)base)->e_lfanew);
    uintptr_t imgEnd = base + nt->OptionalHeader.SizeOfImage;

    struct Node { uint64_t slot; uint32_t off; int parent; };
    std::vector<Node> nodes;
    nodes.push_back({Enc(A), 0, -1});
    size_t lb = 0, le = 1;
    const size_t CAP = 400000;

    for (int d = 1; d <= maxDepth; ++d) {
        SetStatus("Поиск указателей, уровень " + std::to_string(d) + "/" + std::to_string(maxDepth) + "...");
        std::vector<std::pair<uint64_t, int>> T;
        for (size_t i = lb; i < le; ++i) T.push_back({(uint64_t)Dec(nodes[i].slot), (int)i});
        std::sort(T.begin(), T.end());
        uint64_t minT = T.front().first, maxT = T.back().first;
        uintptr_t tlo = (uintptr_t)T.data(), thi = tlo + T.size() * sizeof(T[0]);
        std::vector<Node> nn;
        nn.reserve(1024);

        ForEachMem(Regions(), [&](uintptr_t cb, const uint8_t* b, size_t n) {
            for (size_t i = 0; i + 8 <= n; i += 8) {
                uint64_t v;
                memcpy(&v, b + i, 8);
                if (v > maxT || v + maxOff < minT) continue;
                uintptr_t slot = cb + i;
                if (slot >= tlo && slot < thi) continue;
                auto it = std::lower_bound(T.begin(), T.end(), v,
                                           [](const std::pair<uint64_t, int>& p, uint64_t x) { return p.first < x; });
                if (it == T.end() || it->first - v > maxOff) continue;
                nn.push_back({Enc(slot), (uint32_t)(it->first - v), it->second});
                if (nn.size() >= CAP) return false;
            }
            return true;
        });

        for (auto& x : nn) {
            uintptr_t slot = Dec(x.slot);
            if (slot >= base && slot < imgEnd) {
                std::vector<uint32_t> offs{x.off};
                int p = x.parent;
                while (nodes[p].parent != -1) { offs.push_back(nodes[p].off); p = nodes[p].parent; }
                char buf[64];
                snprintf(buf, sizeof(buf), "0x%llX", (unsigned long long)(slot - base));
                out = buf;
                for (uint32_t o : offs) { snprintf(buf, sizeof(buf), ", 0x%X", o); out += buf; }
                return true;
            }
        }
        if (nn.empty()) break;
        lb = le;
        nodes.insert(nodes.end(), nn.begin(), nn.end());
        le = nodes.size();
    }
    return false;
}

void AssignAndFind(int fi, uintptr_t addr) {
    std::string chain;
    if (PtrScan(addr, g_depth, (uintptr_t)g_maxOff, chain)) {
        // проверка: цепочка должна приводить обратно к найденному адресу
        Chain c = ParseChain(chain);
        uintptr_t back = 0;
        bool ok = Resolve(c, (uintptr_t)GetModuleHandleA(nullptr), back) && back == addr;
        F[fi].chain = chain;
        WritePrivateProfileStringA("offsets", F[fi].key, chain.c_str(), CombatIniPath().c_str());
        CombatReloadCfg();
        SetStatus(std::string(F[fi].label) + ": цепочка сохранена" + (ok ? "" : " (проверка не прошла, перезайдите в локацию и сверьте)") +
                  ": " + chain);
    } else {
        SetStatus(std::string(F[fi].label) +
                  ": статическая цепочка не найдена. Увеличьте глубину/макс. смещение и повторите, либо найдите значение заново.");
    }
}

template <class Fn>
void Async(Fn fn) {
    if (g_busy) return;
    g_busy = true;
    g_progress = 0;
    std::thread([fn]() {
        fn();
        g_busy = false;
    }).detach();
}

// ---------------------------------------------------------------- UI
std::string CurVal(int fi) {
    Chain c = ParseChain(F[fi].chain);
    if (!c.valid()) return "-";
    uintptr_t base = (uintptr_t)GetModuleHandleA(nullptr);
    char b[32];
    if (F[fi].t == Type::I32) {
        int32_t v;
        if (!ReadChain(c, base, v)) return "ошибка";
        snprintf(b, sizeof(b), "%d", v);
    } else {
        float v;
        if (!ReadChain(c, base, v)) return "ошибка";
        snprintf(b, sizeof(b), "%.3f", v);
    }
    return b;
}

void DrawUI() {
    ImGui::SetNextWindowPos(ImVec2(30, 30), ImGuiCond_FirstUseEver);
    ImGui::SetNextWindowSize(ImVec2(560, 620), ImGuiCond_FirstUseEver);
    ImGui::Begin("Калибратор DSRCombat (U — закрыть)");
    bool busy = g_busy;

    ImGui::TextWrapped("%s", GetStatus().c_str());
    if (busy) ImGui::ProgressBar(g_progress, ImVec2(-1, 0));
    ImGui::Separator();

    ImGui::Text("Что ищем:");
    ImGui::SameLine();
    const char* cur = F[g_sel].label;
    if (ImGui::BeginCombo("##f", cur)) {
        for (int i = 0; i < NF; ++i)
            if (ImGui::Selectable(F[i].label, i == g_sel) && !busy) { g_sel = i; g_hits.clear(); }
        ImGui::EndCombo();
    }
    ImGui::InputText("Значение", g_val, sizeof(g_val), ImGuiInputTextFlags_CharsDecimal);
    double val = atof(g_val);
    Type t = F[g_sel].t;

    ImGui::BeginDisabled(busy);
    if (ImGui::Button("Первый скан (точное значение)")) Async([=]() { FirstScan(t, val); });
    ImGui::SameLine();
    if (ImGui::Button("Сброс") && !busy) { g_hits.clear(); SetStatus("Сброшено."); }
    if (!busy && !g_hits.empty()) {
        ImGui::Text("Следующий скан:");
        if (ImGui::Button("Такое же")) Async([=]() { NextScan(Mode::Exact, t, val); });
        ImGui::SameLine();
        if (ImGui::Button("Изменилось")) Async([=]() { NextScan(Mode::Changed, t, val); });
        ImGui::SameLine();
        if (ImGui::Button("Не менялось")) Async([=]() { NextScan(Mode::Unchanged, t, val); });
        ImGui::SameLine();
        if (ImGui::Button("Больше")) Async([=]() { NextScan(Mode::Inc, t, val); });
        ImGui::SameLine();
        if (ImGui::Button("Меньше")) Async([=]() { NextScan(Mode::Dec, t, val); });
    }
    // время анимации ищем рядом с ID анимации: оба лежат в одной структуре
    if (F[g_sel].t == Type::F32 && !F[4].chain.empty()) {
        Chain c = ParseChain(F[4].chain);
        uintptr_t a = 0;
        if (Resolve(c, (uintptr_t)GetModuleHandleA(nullptr), a) && ImGui::Button("Искать рядом с ID анимации (±0x400)"))
            Async([=]() { AroundScan(a, 0x400); });
    }
    ImGui::EndDisabled();

    if (!g_hits.empty() && !busy && g_hits.size() <= 30) {
        ImGui::Separator();
        for (size_t i = 0; i < g_hits.size(); ++i) {
            uintptr_t a = Dec(g_hits[i].a);
            uint32_t v = 0;
            ReadU32(a, v);
            ImGui::PushID((int)i);
            if (t == Type::I32) ImGui::Text("%p  = %d", (void*)a, (int32_t)v);
            else { float f; memcpy(&f, &v, 4); ImGui::Text("%p  = %.3f", (void*)a, f); }
            ImGui::SameLine();
            if (ImGui::SmallButton("Это оно")) {
                int fi = g_sel;
                Async([=]() { AssignAndFind(fi, a); });
            }
            ImGui::PopID();
        }
    }

    ImGui::Separator();
    ImGui::SliderInt("Глубина указателей", &g_depth, 1, 5);
    ImGui::SliderInt("Макс. смещение", &g_maxOff, 0x100, 0x2000, "0x%X");
    ImGui::Separator();
    ImGui::Text("Сохранённые значения (живые):");
    if (ImGui::BeginTable("t", 3, ImGuiTableFlags_Borders | ImGuiTableFlags_RowBg)) {
        for (int i = 0; i < NF; ++i) {
            ImGui::TableNextRow();
            ImGui::TableNextColumn(); ImGui::TextUnformatted(F[i].label);
            ImGui::TableNextColumn(); ImGui::TextUnformatted(F[i].chain.empty() ? "не задано" : "задано");
            ImGui::TableNextColumn(); ImGui::TextUnformatted(CurVal(i).c_str());
        }
        ImGui::EndTable();
    }
    ImGui::TextDisabled("Подсказки: HP/эстус/стамина: введите значение с экрана, потом получите урон/выпейте эстус/ударьте и");
    ImGui::TextDisabled("сделайте скан «Такое же» с новым значением. ID анимации: примите удар и введите ID (см. вики).");
    ImGui::TextDisabled("Время анимации: найдите ID, затем «искать рядом»; во время замаха — «Больше», в покое — «Не менялось».");
    ImGui::End();
}

LRESULT CALLBACK HkWndProc(HWND h, UINT m, WPARAM w, LPARAM l) {
    if (g_init && g_open) {
        ImGui_ImplWin32_WndProcHandler(h, m, w, l);
        if (m >= WM_MOUSEFIRST && m <= WM_MOUSELAST) return 0;
        if (ImGui::GetIO().WantTextInput &&
            (m == WM_KEYDOWN || m == WM_KEYUP || m == WM_CHAR || m == WM_SYSKEYDOWN || m == WM_SYSKEYUP))
            return 0;
    }
    return CallWindowProcW(g_oldProc, h, m, w, l);
}

void InitImGui(IDXGISwapChain* sc) {
    DXGI_SWAP_CHAIN_DESC d;
    sc->GetDesc(&d);
    g_hwnd = d.OutputWindow;
    if (FAILED(sc->GetDevice(__uuidof(ID3D11Device), (void**)&g_dev))) return;
    g_dev->GetImmediateContext(&g_ctx);
    ImGui::CreateContext();
    ImGuiIO& io = ImGui::GetIO();
    io.IniFilename = nullptr;
    const char* font = "C:\\Windows\\Fonts\\segoeui.ttf";
    if (GetFileAttributesA(font) != INVALID_FILE_ATTRIBUTES)
        io.Fonts->AddFontFromFileTTF(font, 16.f, nullptr, io.Fonts->GetGlyphRangesCyrillic());
    ImGui::StyleColorsDark();
    ImGui_ImplWin32_Init(g_hwnd);
    ImGui_ImplDX11_Init(g_dev, g_ctx);
    g_oldProc = (WNDPROC)SetWindowLongPtrW(g_hwnd, GWLP_WNDPROC, (LONG_PTR)HkWndProc);
    g_init = true;
}

void OnPresent(IDXGISwapChain* sc, UINT&) {
    if (!g_init) { InitImGui(sc); if (!g_init) return; }

    DWORD pid = 0;
    GetWindowThreadProcessId(GetForegroundWindow(), &pid);
    bool focused = pid == GetCurrentProcessId();
    bool u = focused && (GetAsyncKeyState('U') & 0x8000);
    if (u && !g_prevU && !(g_open && ImGui::GetIO().WantTextInput)) g_open = !g_open;
    g_prevU = u;
    if (!g_open) return;

    ImGui_ImplDX11_NewFrame();
    ImGui_ImplWin32_NewFrame();
    ImGui::NewFrame();
    ImGui::GetIO().MouseDrawCursor = true;
    DrawUI();
    ImGui::Render();

    ID3D11Texture2D* bb = nullptr;
    ID3D11RenderTargetView* rtv = nullptr;
    if (SUCCEEDED(sc->GetBuffer(0, __uuidof(ID3D11Texture2D), (void**)&bb))) {
        g_dev->CreateRenderTargetView(bb, nullptr, &rtv);
        bb->Release();
    }
    if (rtv) {
        g_ctx->OMSetRenderTargets(1, &rtv, nullptr);
        ImGui_ImplDX11_RenderDrawData(ImGui::GetDrawData());
        rtv->Release();
    }
}

}  // namespace

void CalibStart(HMODULE self) {
    g_self = self;
    std::string ini = CombatIniPath();
    for (int i = 0; i < NF; ++i) {
        char buf[512] = {};
        GetPrivateProfileStringA("offsets", F[i].key, "", buf, sizeof(buf), ini.c_str());
        F[i].chain = buf;
    }
    dx11::Callbacks cb;
    cb.onPresent = OnPresent;
    dx11::Install(cb);
}
