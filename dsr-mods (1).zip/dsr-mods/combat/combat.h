#pragma once
#include <windows.h>

#include <string>

// Общий интерфейс между combat.cpp (логика модов) и calib.cpp (оверлей-калибратор).
std::string CombatIniPath();
void CombatReloadCfg();     // перечитать DSRCombat.ini (после записи цепочек калибратором)
void CalibStart(HMODULE self);  // запуск оверлея калибровки (клавиша U)
