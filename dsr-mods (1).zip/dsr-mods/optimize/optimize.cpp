// DSROptimize: лёгкие оптимизации рендера Dark Souls Remastered.
//  - ограничение анизотропной фильтрации (меньше нагрузка на GPU)
//  - пауза рендера, когда окно игры не в фокусе
//  - необязательный точный лимитер кадров (fps_limit)
#include <windows.h>

#include <fstream>
#include <string>

#include "../common/dx11_hook.h"

static HMODULE g_self;
static int g_aniso = 4;
static int g_fps = 0;
static bool g_bgSleep = true;
static HANDLE g_timer = nullptr;
static LARGE_INTEGER g_freq, g_next;

static bool Focused() {
    HWND fg = GetForegroundWindow();
    DWORD pid = 0;
    GetWindowThreadProcessId(fg, &pid);
    return pid == GetCurrentProcessId();
}

static void OnSampler(D3D11_SAMPLER_DESC& d) {
    // 0x40 — бит анизотропной фильтрации в D3D11_FILTER
    if (g_aniso > 0 && (d.Filter & 0x40) && d.MaxAnisotropy > (UINT)g_aniso) d.MaxAnisotropy = (UINT)g_aniso;
}

static void OnAfterPresent(IDXGISwapChain*) {
    if (g_bgSleep && !Focused()) Sleep(50);
    if (g_fps <= 0) return;

    LARGE_INTEGER now;
    QueryPerformanceCounter(&now);
    long long interval = g_freq.QuadPart / g_fps;
    if (g_next.QuadPart == 0) g_next.QuadPart = now.QuadPart;
    g_next.QuadPart += interval;
    if (now.QuadPart > g_next.QuadPart + interval * 2) {  // отстали — сбрасываем
        g_next.QuadPart = now.QuadPart;
        return;
    }
    while (now.QuadPart < g_next.QuadPart) {
        double remainMs = (double)(g_next.QuadPart - now.QuadPart) * 1000.0 / (double)g_freq.QuadPart;
        if (remainMs > 2.0 && g_timer) {
            LARGE_INTEGER due;
            due.QuadPart = -(LONGLONG)((remainMs - 1.5) * 10000.0);
            SetWaitableTimer(g_timer, &due, 0, nullptr, nullptr, FALSE);
            WaitForSingleObject(g_timer, 20);
        } else {
            YieldProcessor();
        }
        QueryPerformanceCounter(&now);
    }
}

static DWORD WINAPI Init(LPVOID) {
    char p[MAX_PATH];
    GetModuleFileNameA(g_self, p, MAX_PATH);
    std::string ini = p;
    ini = ini.substr(0, ini.find_last_of("\\/") + 1) + "DSROptimize.ini";
    if (GetFileAttributesA(ini.c_str()) == INVALID_FILE_ATTRIBUTES) {
        std::ofstream f(ini);
        f << "[optimize]\n"
             "; Максимум анизотропной фильтрации (0 = не трогать, 1/2/4/8/16)\n"
             "max_anisotropy=4\n"
             "; Точный лимит FPS (0 = выключено, игра и так держит 60)\n"
             "fps_limit=0\n"
             "; Снижать нагрузку, когда окно игры не в фокусе\n"
             "background_sleep=1\n";
    }
    g_aniso = GetPrivateProfileIntA("optimize", "max_anisotropy", 4, ini.c_str());
    g_fps = GetPrivateProfileIntA("optimize", "fps_limit", 0, ini.c_str());
    g_bgSleep = GetPrivateProfileIntA("optimize", "background_sleep", 1, ini.c_str()) != 0;
    QueryPerformanceFrequency(&g_freq);
    g_timer = CreateWaitableTimerExW(nullptr, nullptr, CREATE_WAITABLE_TIMER_HIGH_RESOLUTION, TIMER_ALL_ACCESS);

    dx11::Callbacks cb;
    cb.onAfterPresent = OnAfterPresent;
    cb.onCreateSampler = OnSampler;
    dx11::Install(cb);
    return 0;
}

BOOL APIENTRY DllMain(HMODULE m, DWORD reason, LPVOID) {
    if (reason == DLL_PROCESS_ATTACH) {
        g_self = m;
        DisableThreadLibraryCalls(m);
        CreateThread(nullptr, 0, Init, nullptr, 0, nullptr);
    }
    return TRUE;
}
