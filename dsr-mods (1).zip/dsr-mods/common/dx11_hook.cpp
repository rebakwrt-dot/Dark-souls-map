#include "dx11_hook.h"

namespace dx11 {

using PresentFn = HRESULT(STDMETHODCALLTYPE*)(IDXGISwapChain*, UINT, UINT);
using SamplerFn = HRESULT(STDMETHODCALLTYPE*)(ID3D11Device*, const D3D11_SAMPLER_DESC*, ID3D11SamplerState**);

static Callbacks g_cb;
static PresentFn g_origPresent = nullptr;
static SamplerFn g_origSampler = nullptr;

static HRESULT STDMETHODCALLTYPE HkPresent(IDXGISwapChain* sc, UINT sync, UINT flags) {
    if (g_cb.onPresent && !(flags & DXGI_PRESENT_TEST)) g_cb.onPresent(sc, sync);
    HRESULT hr = g_origPresent(sc, sync, flags);
    if (g_cb.onAfterPresent && !(flags & DXGI_PRESENT_TEST)) g_cb.onAfterPresent(sc);
    return hr;
}

static HRESULT STDMETHODCALLTYPE HkSampler(ID3D11Device* dev, const D3D11_SAMPLER_DESC* d, ID3D11SamplerState** out) {
    if (d && g_cb.onCreateSampler) {
        D3D11_SAMPLER_DESC c = *d;
        g_cb.onCreateSampler(c);
        return g_origSampler(dev, &c, out);
    }
    return g_origSampler(dev, d, out);
}

static bool Patch(void** slot, void* hook, void** orig) {
    DWORD old;
    if (!VirtualProtect(slot, sizeof(void*), PAGE_READWRITE, &old)) return false;
    *orig = *slot;
    *slot = hook;
    VirtualProtect(slot, sizeof(void*), old, &old);
    return true;
}

bool Install(const Callbacks& cb) {
    g_cb = cb;

    WNDCLASSEXW wc{};
    wc.cbSize = sizeof(wc);
    wc.lpfnWndProc = DefWindowProcW;
    wc.hInstance = GetModuleHandleW(nullptr);
    wc.lpszClassName = L"DSRModsDummy";
    RegisterClassExW(&wc);
    HWND hwnd = CreateWindowW(wc.lpszClassName, L"", WS_OVERLAPPEDWINDOW, 0, 0, 100, 100, nullptr, nullptr, wc.hInstance, nullptr);

    DXGI_SWAP_CHAIN_DESC sd{};
    sd.BufferCount = 1;
    sd.BufferDesc.Format = DXGI_FORMAT_R8G8B8A8_UNORM;
    sd.BufferUsage = DXGI_USAGE_RENDER_TARGET_OUTPUT;
    sd.OutputWindow = hwnd;
    sd.SampleDesc.Count = 1;
    sd.Windowed = TRUE;
    sd.SwapEffect = DXGI_SWAP_EFFECT_DISCARD;

    ID3D11Device* dev = nullptr;
    ID3D11DeviceContext* ctx = nullptr;
    IDXGISwapChain* sc = nullptr;
    HRESULT hr = D3D11CreateDeviceAndSwapChain(nullptr, D3D_DRIVER_TYPE_HARDWARE, nullptr, 0, nullptr, 0,
                                               D3D11_SDK_VERSION, &sd, &sc, &dev, nullptr, &ctx);
    bool ok = false;
    if (SUCCEEDED(hr)) {
        void** scVt = *reinterpret_cast<void***>(sc);
        void** devVt = *reinterpret_cast<void***>(dev);
        ok = Patch(&scVt[8], (void*)HkPresent, (void**)&g_origPresent);  // IDXGISwapChain::Present
        if (ok && g_cb.onCreateSampler)
            Patch(&devVt[23], (void*)HkSampler, (void**)&g_origSampler);  // ID3D11Device::CreateSamplerState
    }
    if (ctx) ctx->Release();
    if (dev) dev->Release();
    if (sc) sc->Release();
    DestroyWindow(hwnd);
    UnregisterClassW(wc.lpszClassName, wc.hInstance);
    return ok;
}

}  // namespace dx11
