@echo off
chcp 65001 >nul
rem Использование: extract.bat "C:\Games\DARK SOULS REMASTERED"
if "%~1"=="" (
  echo Укажите папку игры: extract.bat "D:\Games\DARK SOULS REMASTERED"
  pause
  exit /b 1
)
"%~dp0tools\DSRExtract.exe" "%~1" "%~1\DSRMods\markers.json"
pause
