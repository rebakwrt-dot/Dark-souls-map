// DSRMap: большая карта по Tab + перетаскиваемая миникарта.
// Позиции игрока/врагов читаются из памяти игры (цепочки указателей в DSRMap.ini),
// лут и переходы берутся из markers.json (+ авто-переходы и ручные метки F8/F9).
#define IMGUI_DEFINE_MATH_OPERATORS
#include <windows.h>
#include <d3d11.h>
#include <dxgi.h>

#include <algorithm>
#include <cmath>
#include <fstream>
#include <string>
#include <unordered_map>
#include <vector>

#include "backends/imgui_impl_dx11.h"
#include "backends/imgui_impl_win32.h"
#include "imgui.h"
#include <nlohmann/json.hpp>

#include "../common/dx11_hook.h"
#include "mem.h"

extern IMGUI_IMPL_API LRESULT ImGui_ImplWin32_WndProcHandler(HWND, UINT, WPARAM, LPARAM);

using json = nlohmann::json;

// ---------------------------------------------------------------- данные
static HMODULE g_self;
static std::string g_dir;  // папка DSRMods\ (с завершающим слэшем)
static std::string g_ini;

struct Marker { std::string type, name; float x, y, z; };
struct Enemy { float x = 0, y = 0, z = 0, hp = 1; };
struct State {
    bool ok = false;
    float x = 0, y = 0, z = 0, ang = 0;
    int area = 0;
    std::vector<Enemy> en;
};

struct Cfg {
    Chain px, py, pz, pang, area, elist, ecount, epx, epy, epz, ehp;
    int estride = 8;
    bool skipFirst = true;
    int toggleKey = VK_TAB, editKey = VK_F7, lootKey = VK_F8, doorKey = VK_F9;
    float range = 40.f, mmX = 20.f, mmY = 20.f, mmSize = 220.f;
    bool flipX = false, flipZ = false, autoTrans = true;
} C;

static State S;
static std::unordered_map<std::string, std::vector<Marker>> g_markers;
static std::unordered_map<std::string, std::vector<float>> g_trail;  // x,z попарно; NaN,NaN = разрыв
static bool g_big = false, g_edit = false;
static bool g_showLoot = true, g_showEnemies = true, g_showTrans = true, g_showTrail = true;
static float g_zoom = 4.f;  // пикселей на метр
static ImVec2 g_pan(0, 0);

// ---------------------------------------------------------------- конфиг
static std::string IniStr(const char* sec, const char* key) {
    char b[512];
    GetPrivateProfileStringA(sec, key, "", b, sizeof(b), g_ini.c_str());
    return b;
}
static float IniF(const char* sec, const char* key, float def) {
    std::string s = IniStr(sec, key);
    return s.empty() ? def : (float)atof(s.c_str());
}
static int IniI(const char* sec, const char* key, int def) {
    return (int)GetPrivateProfileIntA(sec, key, def, g_ini.c_str());
}

static void WriteDefaultIni() {
    std::ofstream f(g_ini);
    f << "[offsets]\n"
         "; Цепочки указателей для DarkSoulsRemastered.exe (формат: 0x..., через запятую).\n"
         "; Первое число — смещение от базы exe, остальные — разыменование + смещение.\n"
         "; Значения нужно найти (Cheat Engine / исходники DSR-Gadget) под вашу версию игры.\n"
         "player_x=\nplayer_y=\nplayer_z=\nplayer_angle=\narea_id=\n"
         "; Враги: enemy_list -> адрес, где лежит указатель на массив указателей на сущности;\n"
         "; enemy_count -> int количество; enemy_* -> цепочки ОТНОСИТЕЛЬНО указателя сущности.\n"
         "enemy_list=\nenemy_count=\nenemy_stride=8\nenemy_x=\nenemy_y=\nenemy_z=\nenemy_hp=\n"
         "; Пропустить первую сущность в списке (обычно это игрок)\n"
         "enemy_skip_first=1\n\n"
         "[display]\n"
         "; Коды клавиш (decimal/hex): Tab=9, F7=118, F8=119, F9=120\n"
         "toggle_key=9\nedit_key=118\nloot_key=119\ndoor_key=120\n"
         "; Радиус миникарты в метрах\nminimap_range=40\n"
         "minimap_x=20\nminimap_y=20\nminimap_size=220\n"
         "; Если карта зеркальная — поменяйте оси\nflip_x=0\nflip_z=0\n"
         "; Автоматически ставить метки переходов при смене локации\nauto_transitions=1\n";
}

static void LoadConfig() {
    if (GetFileAttributesA(g_ini.c_str()) == INVALID_FILE_ATTRIBUTES) WriteDefaultIni();
    auto ch = [](const char* k) { return ParseChain(IniStr("offsets", k)); };
    C.px = ch("player_x"); C.py = ch("player_y"); C.pz = ch("player_z");
    C.pang = ch("player_angle"); C.area = ch("area_id");
    C.elist = ch("enemy_list"); C.ecount = ch("enemy_count");
    C.epx = ch("enemy_x"); C.epy = ch("enemy_y"); C.epz = ch("enemy_z"); C.ehp = ch("enemy_hp");
    C.estride = IniI("offsets", "enemy_stride", 8);
    C.skipFirst = IniI("offsets", "enemy_skip_first", 1) != 0;
    auto key = [](const char* k, int d) {
        std::string s = IniStr("display", k);
        return s.empty() ? d : (int)strtol(s.c_str(), nullptr, 0);
    };
    C.toggleKey = key("toggle_key", VK_TAB); C.editKey = key("edit_key", VK_F7);
    C.lootKey = key("loot_key", VK_F8); C.doorKey = key("door_key", VK_F9);
    C.range = IniF("display", "minimap_range", 40.f);
    C.mmX = IniF("display", "minimap_x", 20.f); C.mmY = IniF("display", "minimap_y", 20.f);
    C.mmSize = IniF("display", "minimap_size", 220.f);
    C.flipX = IniI("display", "flip_x", 0) != 0; C.flipZ = IniI("display", "flip_z", 0) != 0;
    C.autoTrans = IniI("display", "auto_transitions", 1) != 0;
}

static void SaveMinimapPos() {
    auto w = [](const char* k, float v) {
        WritePrivateProfileStringA("display", k, std::to_string((int)v).c_str(), g_ini.c_str());
    };
    w("minimap_x", C.mmX); w("minimap_y", C.mmY); w("minimap_size", C.mmSize);
}

// ---------------------------------------------------------------- маркеры / след
static void LoadMarkers() {
    std::ifstream f(g_dir + "markers.json");
    if (!f) return;
    try {
        json j = json::parse(f);
        for (auto& [k, v] : j.items())
            for (auto& m : v)
                g_markers[k].push_back({m.value("type", "loot"), m.value("name", ""),
                                        m.value("x", 0.f), m.value("y", 0.f), m.value("z", 0.f)});
    } catch (...) {}
}
static void SaveMarkers() {
    json j = json::object();
    for (auto& [k, v] : g_markers) {
        json a = json::array();
        for (auto& m : v)
            a.push_back({{"type", m.type}, {"name", m.name}, {"x", m.x}, {"y", m.y}, {"z", m.z}});
        j[k] = a;
    }
    std::ofstream(g_dir + "markers.json") << j.dump(1);
}
static void LoadTrails() {
    std::ifstream f(g_dir + "trails.json");
    if (!f) return;
    try {
        json j = json::parse(f);
        for (auto& [k, v] : j.items()) {
            auto& t = g_trail[k];
            for (auto& n : v) t.push_back(n.is_null() ? NAN : n.get<float>());
        }
    } catch (...) {}
}
static void SaveTrails() {
    json j = json::object();
    for (auto& [k, v] : g_trail) {
        json a = json::array();
        for (float n : v) a.push_back(std::isfinite(n) ? json(n) : json(nullptr));
        j[k] = a;
    }
    std::ofstream(g_dir + "trails.json") << j.dump();
}

static std::string Key(int a) { return std::to_string(a); }

static void AddMarker(const std::string& area, const char* type, const std::string& name, float x, float y, float z) {
    g_markers[area].push_back({type, name, x, y, z});
}
static void AddTransition(int area, float x, float y, float z, const std::string& name) {
    auto& v = g_markers[Key(area)];
    for (auto& m : v)
        if (m.type == "transition" && std::hypot(m.x - x, m.z - z) < 5.f) return;
    AddMarker(Key(area), "transition", name, x, y, z);
}

// ---------------------------------------------------------------- чтение памяти
static bool ReadState() {
    uintptr_t base = (uintptr_t)GetModuleHandleW(nullptr);
    State n;
    if (!ReadChain(C.px, base, n.x) || !ReadChain(C.pz, base, n.z)) return false;
    ReadChain(C.py, base, n.y);
    ReadChain(C.pang, base, n.ang);
    ReadChain(C.area, base, n.area);
    if (!std::isfinite(n.x) || !std::isfinite(n.z)) return false;

    uintptr_t la = 0, arr = 0;
    int cnt = 0;
    if (C.elist.valid() && C.ecount.valid() && Resolve(C.elist, base, la) && Rd(la, arr) && arr &&
        ReadChain(C.ecount, base, cnt)) {
        cnt = std::clamp(cnt, 0, 512);
        for (int i = C.skipFirst ? 1 : 0; i < cnt; ++i) {
            uintptr_t e = 0;
            if (!Rd(arr + (uintptr_t)i * C.estride, e) || !e) continue;
            Enemy en;
            if (!ReadChain(C.epx, e, en.x) || !ReadChain(C.epz, e, en.z)) continue;
            ReadChain(C.epy, e, en.y);
            if (C.ehp.valid()) {
                int hp = 1;
                if (ReadChain(C.ehp, e, hp) && hp <= 0) continue;
            }
            if (!std::isfinite(en.x) || !std::isfinite(en.z)) continue;
            n.en.push_back(en);
        }
    }
    n.ok = true;
    S = std::move(n);
    return true;
}

static void UpdateTracking() {
    static int prevArea = 0;
    static float lx = 0, ly = 0, lz = 0;
    static bool had = false;
    static DWORD lastSave = 0;
    if (!S.ok) return;

    if (had && S.area != prevArea && prevArea != 0 && S.area != 0 && C.autoTrans) {
        AddTransition(prevArea, lx, ly, lz, "-> " + Key(S.area));
        AddTransition(S.area, S.x, S.y, S.z, "<- " + Key(prevArea));
        SaveMarkers();
        SaveTrails();
    }
    prevArea = S.area; lx = S.x; ly = S.y; lz = S.z; had = true;

    auto& t = g_trail[Key(S.area)];
    if (t.size() < 2) {
        t.push_back(S.x); t.push_back(S.z);
    } else {
        float px = t[t.size() - 2], pz = t.back();
        float d = std::isfinite(px) ? std::hypot(px - S.x, pz - S.z) : 1e9f;
        if (d > 1.5f) {
            if (d > 30.f && std::isfinite(px)) { t.push_back(NAN); t.push_back(NAN); }  // телепорт
            t.push_back(S.x); t.push_back(S.z);
            if (t.size() > 40000) t.erase(t.begin(), t.begin() + 2000);
        }
    }
    DWORD now = GetTickCount();
    if (now - lastSave > 30000) { lastSave = now; SaveTrails(); }
}

// ---------------------------------------------------------------- рисование
struct View {
    ImVec2 center;   // экранная точка, где находится игрок
    float scale;     // пикселей на метр
    bool circle;
    float rad;
    ImVec2 rmin, rmax;
};

static ImVec2 W2S(const View& v, float wx, float wz) {
    float dx = (wx - S.x) * (C.flipX ? -1.f : 1.f);
    float dz = (wz - S.z) * (C.flipZ ? -1.f : 1.f);
    return ImVec2(v.center.x + dx * v.scale, v.center.y - dz * v.scale);
}
static void S2W(const View& v, ImVec2 p, float& wx, float& wz) {
    float dx = (p.x - v.center.x) / v.scale * (C.flipX ? -1.f : 1.f);
    float dz = -(p.y - v.center.y) / v.scale * (C.flipZ ? -1.f : 1.f);
    wx = S.x + dx; wz = S.z + dz;
}
static bool Inside(const View& v, ImVec2 p) {
    if (v.circle) {
        float dx = p.x - v.center.x, dy = p.y - v.center.y;
        return dx * dx + dy * dy <= (v.rad - 4) * (v.rad - 4);
    }
    return p.x >= v.rmin.x && p.y >= v.rmin.y && p.x <= v.rmax.x && p.y <= v.rmax.y;
}

static void DrawMarker(ImDrawList* dl, ImVec2 p, const Marker& m, float r, bool dim) {
    int a = dim ? 90 : 255;
    if (m.type == "loot") {
        dl->AddQuadFilled(p + ImVec2(0, -r), p + ImVec2(r, 0), p + ImVec2(0, r), p + ImVec2(-r, 0),
                          IM_COL32(255, 215, 0, a));
    } else if (m.type == "transition") {
        dl->AddRectFilled(p - ImVec2(r, r), p + ImVec2(r, r), IM_COL32(60, 200, 255, a), 2.f);
        dl->AddRect(p - ImVec2(r, r), p + ImVec2(r, r), IM_COL32(255, 255, 255, a), 2.f);
    } else {
        dl->AddCircleFilled(p, r, IM_COL32(255, 140, 40, a));
    }
}

static void DrawLayer(ImDrawList* dl, const View& v, float mr, ImVec2 mouse, std::string& hover) {
    const std::string area = Key(S.area);
    float best = 12.f;

    if (g_showTrail) {
        auto it = g_trail.find(area);
        if (it != g_trail.end()) {
            const auto& t = it->second;
            for (size_t i = 2; i + 1 < t.size(); i += 2) {
                if (!std::isfinite(t[i - 2]) || !std::isfinite(t[i])) continue;
                ImVec2 a = W2S(v, t[i - 2], t[i - 1]), b = W2S(v, t[i], t[i + 1]);
                if (Inside(v, a) && Inside(v, b)) dl->AddLine(a, b, IM_COL32(120, 200, 140, 150), 2.f);
            }
        }
    }

    auto mit = g_markers.find(area);
    if (mit != g_markers.end()) {
        for (auto& m : mit->second) {
            bool isLoot = m.type == "loot", isTrans = m.type == "transition";
            if ((isLoot && !g_showLoot) || (isTrans && !g_showTrans)) continue;
            ImVec2 p = W2S(v, m.x, m.z);
            if (!Inside(v, p)) continue;
            DrawMarker(dl, p, m, mr, std::fabs(m.y - S.y) > 8.f);
            float d = std::hypot(p.x - mouse.x, p.y - mouse.y);
            if (d < best) { best = d; hover = m.type + ": " + m.name; }
        }
    }

    if (g_showEnemies) {
        for (auto& e : S.en) {
            ImVec2 p = W2S(v, e.x, e.z);
            if (!Inside(v, p)) continue;
            int a = std::fabs(e.y - S.y) > 8.f ? 90 : 255;
            dl->AddCircleFilled(p, mr * 0.8f, IM_COL32(230, 50, 50, a));
        }
    }

    // игрок: стрелка по углу
    float ang = S.ang;
    ImVec2 c = v.center, d(std::sin(ang), -std::cos(ang));
    float r = mr * 1.6f;
    ImVec2 tip = c + d * r, l = c + ImVec2(-d.y, d.x) * r * 0.6f - d * r * 0.5f,
           rr = c - ImVec2(-d.y, d.x) * r * 0.6f - d * r * 0.5f;
    dl->AddTriangleFilled(tip, l, rr, IM_COL32(255, 255, 255, 255));
}

static void DrawMinimap() {
    ImGuiWindowFlags f = ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoScrollbar | ImGuiWindowFlags_NoCollapse |
                         ImGuiWindowFlags_NoSavedSettings | ImGuiWindowFlags_NoBackground |
                         ImGuiWindowFlags_NoFocusOnAppearing | ImGuiWindowFlags_NoNav;
    if (!g_edit) f |= ImGuiWindowFlags_NoMove | ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoInputs;
    ImGui::SetNextWindowPos(ImVec2(C.mmX, C.mmY), g_edit ? ImGuiCond_FirstUseEver : ImGuiCond_Always);
    ImGui::SetNextWindowSize(ImVec2(C.mmSize, C.mmSize), g_edit ? ImGuiCond_FirstUseEver : ImGuiCond_Always);
    ImGui::SetNextWindowSizeConstraints(ImVec2(120, 120), ImVec2(600, 600));
    ImGui::Begin("##minimap", nullptr, f);
    ImVec2 wp = ImGui::GetWindowPos(), ws = ImGui::GetWindowSize();
    if (g_edit) { C.mmX = wp.x; C.mmY = wp.y; C.mmSize = std::min(ws.x, ws.y); }

    ImDrawList* dl = ImGui::GetWindowDrawList();
    View v;
    v.center = ImVec2(wp.x + ws.x * 0.5f, wp.y + ws.y * 0.5f);
    v.rad = std::min(ws.x, ws.y) * 0.5f;
    v.scale = v.rad / std::max(5.f, C.range);
    v.circle = true;
    dl->AddCircleFilled(v.center, v.rad, IM_COL32(10, 10, 14, 170), 64);
    dl->AddCircle(v.center, v.rad, g_edit ? IM_COL32(80, 255, 120, 255) : IM_COL32(200, 200, 200, 120), 64, 2.f);
    if (S.ok) {
        std::string hover;
        DrawLayer(dl, v, 4.f, ImVec2(-1000, -1000), hover);
    } else {
        dl->AddText(ImVec2(wp.x + 10, v.center.y - 20), IM_COL32(255, 180, 80, 255), "DSRMap: оффсеты не заданы");
        dl->AddText(ImVec2(wp.x + 10, v.center.y), IM_COL32(255, 180, 80, 255), "см. DSRMods\\DSRMap.ini");
    }
    if (g_edit)
        dl->AddText(ImVec2(wp.x + 8, wp.y + 4), IM_COL32(80, 255, 120, 255), "Тяни/меняй размер. F7 - сохранить");
    ImGui::End();
}

static void DrawBigMap() {
    ImGuiIO& io = ImGui::GetIO();
    ImGui::SetNextWindowPos(ImVec2(0, 0));
    ImGui::SetNextWindowSize(io.DisplaySize);
    ImGui::Begin("##bigmap", nullptr,
                 ImGuiWindowFlags_NoDecoration | ImGuiWindowFlags_NoMove | ImGuiWindowFlags_NoSavedSettings |
                     ImGuiWindowFlags_NoBringToFrontOnFocus | ImGuiWindowFlags_NoNav | ImGuiWindowFlags_NoBackground);

    // управление: колесо — зум, ЛКМ-перетаскивание — сдвиг
    if (ImGui::IsWindowHovered() && !ImGui::IsAnyItemHovered()) {
        if (io.MouseWheel != 0.f) g_zoom = std::clamp(g_zoom * std::pow(1.15f, io.MouseWheel), 0.3f, 40.f);
        if (ImGui::IsMouseDragging(0)) { g_pan.x += io.MouseDelta.x; g_pan.y += io.MouseDelta.y; }
    }

    ImDrawList* dl = ImGui::GetWindowDrawList();
    ImVec2 ds = io.DisplaySize;
    dl->AddRectFilled(ImVec2(0, 0), ds, IM_COL32(8, 8, 12, 215));

    View v;
    v.center = ImVec2(ds.x * 0.5f + g_pan.x, ds.y * 0.5f + g_pan.y);
    v.scale = g_zoom;
    v.circle = false;
    v.rmin = ImVec2(0, 0);
    v.rmax = ds;

    // сетка
    float step = 10.f;
    if (step * v.scale < 14.f) step = 50.f;
    if (step * v.scale < 14.f) step = 200.f;
    float w0x, w0z, w1x, w1z;
    S2W(v, ImVec2(0, 0), w0x, w0z);
    S2W(v, ds, w1x, w1z);
    float xa = std::min(w0x, w1x), xb = std::max(w0x, w1x), za = std::min(w0z, w1z), zb = std::max(w0z, w1z);
    for (float x = std::floor(xa / step) * step; x <= xb; x += step) {
        float sx = W2S(v, x, 0).x;
        dl->AddLine(ImVec2(sx, 0), ImVec2(sx, ds.y), IM_COL32(255, 255, 255, 18));
    }
    for (float z = std::floor(za / step) * step; z <= zb; z += step) {
        float sy = W2S(v, 0, z).y;
        dl->AddLine(ImVec2(0, sy), ImVec2(ds.x, sy), IM_COL32(255, 255, 255, 18));
    }

    std::string hover;
    if (S.ok) DrawLayer(dl, v, 6.f, io.MousePos, hover);
    if (!hover.empty()) ImGui::SetTooltip("%s", hover.c_str());
    ImGui::End();

    // панель управления
    ImGui::SetNextWindowPos(ImVec2(20, 20), ImGuiCond_Always);
    ImGui::Begin("Карта", nullptr,
                 ImGuiWindowFlags_AlwaysAutoResize | ImGuiWindowFlags_NoSavedSettings | ImGuiWindowFlags_NoMove);
    ImGui::Text("Локация: %d", S.area);
    ImGui::Checkbox("Лут", &g_showLoot);
    ImGui::Checkbox("Враги", &g_showEnemies);
    ImGui::Checkbox("Переходы", &g_showTrans);
    ImGui::Checkbox("Пройденный путь", &g_showTrail);
    if (ImGui::Button("К игроку")) { g_pan = ImVec2(0, 0); }
    if (ImGui::Button("+ Лут здесь") && S.ok) {
        AddMarker(Key(S.area), "loot", "loot " + std::to_string(g_markers[Key(S.area)].size() + 1), S.x, S.y, S.z);
        SaveMarkers();
    }
    if (ImGui::Button("+ Переход здесь") && S.ok) {
        AddMarker(Key(S.area), "transition", "door " + std::to_string(g_markers[Key(S.area)].size() + 1), S.x, S.y, S.z);
        SaveMarkers();
    }
    ImGui::TextDisabled("Колесо - зум, ЛКМ - сдвиг");
    ImGui::End();
}

// ---------------------------------------------------------------- ввод
static bool GameFocused() {
    DWORD pid = 0;
    GetWindowThreadProcessId(GetForegroundWindow(), &pid);
    return pid == GetCurrentProcessId();
}
static bool Pressed(int vk) {
    static bool prev[256] = {};
    bool d = (GetAsyncKeyState(vk) & 0x8000) != 0;
    bool r = d && !prev[vk & 255];
    prev[vk & 255] = d;
    return r;
}

static void HandleKeys() {
    if (!GameFocused()) return;
    if (Pressed(C.toggleKey)) { g_big = !g_big; g_pan = ImVec2(0, 0); }
    if (Pressed(C.editKey)) {
        g_edit = !g_edit;
        if (!g_edit) SaveMinimapPos();
    }
    if (Pressed(C.lootKey) && S.ok) {
        AddMarker(Key(S.area), "loot", "loot " + std::to_string(g_markers[Key(S.area)].size() + 1), S.x, S.y, S.z);
        SaveMarkers();
    }
    if (Pressed(C.doorKey) && S.ok) {
        AddMarker(Key(S.area), "transition", "door " + std::to_string(g_markers[Key(S.area)].size() + 1), S.x, S.y, S.z);
        SaveMarkers();
    }
}

// ---------------------------------------------------------------- ImGui / хук
static bool g_init = false;
static HWND g_hwnd = nullptr;
static ID3D11Device* g_dev = nullptr;
static ID3D11DeviceContext* g_ctx = nullptr;
static WNDPROC g_oldProc = nullptr;

static LRESULT CALLBACK HkWndProc(HWND h, UINT m, WPARAM w, LPARAM l) {
    if (g_init && (g_big || g_edit)) {
        ImGui_ImplWin32_WndProcHandler(h, m, w, l);
        if (g_big && m >= WM_MOUSEFIRST && m <= WM_MOUSELAST) return 0;  // не пускаем мышь в игру
    }
    return CallWindowProcW(g_oldProc, h, m, w, l);
}

static void InitImGui(IDXGISwapChain* sc) {
    DXGI_SWAP_CHAIN_DESC d;
    sc->GetDesc(&d);
    g_hwnd = d.OutputWindow;
    if (FAILED(sc->GetDevice(__uuidof(ID3D11Device), (void**)&g_dev))) return;
    g_dev->GetImmediateContext(&g_ctx);

    ImGui::CreateContext();
    ImGuiIO& io = ImGui::GetIO();
    io.IniFilename = nullptr;
    const char* font = "C:\\Windows\\Fonts\\segoeui.ttf";
    if (GetFileAttributesA(font) != INVALID_FILE_ATTRIBUTES)
        io.Fonts->AddFontFromFileTTF(font, 16.f, nullptr, io.Fonts->GetGlyphRangesCyrillic());
    ImGui::StyleColorsDark();
    ImGui_ImplWin32_Init(g_hwnd);
    ImGui_ImplDX11_Init(g_dev, g_ctx);
    g_oldProc = (WNDPROC)SetWindowLongPtrW(g_hwnd, GWLP_WNDPROC, (LONG_PTR)HkWndProc);
    g_init = true;
}

static void OnPresent(IDXGISwapChain* sc, UINT&) {
    if (!g_init) { InitImGui(sc); if (!g_init) return; }

    HandleKeys();
    ReadState() ? void() : (void)(S.ok = false);
    UpdateTracking();

    ImGui_ImplDX11_NewFrame();
    ImGui_ImplWin32_NewFrame();
    ImGui::NewFrame();
    ImGui::GetIO().MouseDrawCursor = g_big || g_edit;

    DrawMinimap();
    if (g_big) DrawBigMap();

    ImGui::Render();
    ID3D11Texture2D* bb = nullptr;
    ID3D11RenderTargetView* rtv = nullptr;
    if (SUCCEEDED(sc->GetBuffer(0, __uuidof(ID3D11Texture2D), (void**)&bb))) {
        g_dev->CreateRenderTargetView(bb, nullptr, &rtv);
        bb->Release();
    }
    if (rtv) {
        g_ctx->OMSetRenderTargets(1, &rtv, nullptr);
        ImGui_ImplDX11_RenderDrawData(ImGui::GetDrawData());
        rtv->Release();
    }
}

static DWORD WINAPI Init(LPVOID) {
    char p[MAX_PATH];
    GetModuleFileNameA(g_self, p, MAX_PATH);
    g_dir = p;
    g_dir = g_dir.substr(0, g_dir.find_last_of("\\/") + 1);
    g_ini = g_dir + "DSRMap.ini";
    LoadConfig();
    LoadMarkers();
    LoadTrails();
    dx11::Callbacks cb;
    cb.onPresent = OnPresent;
    dx11::Install(cb);
    return 0;
}

BOOL APIENTRY DllMain(HMODULE m, DWORD reason, LPVOID) {
    if (reason == DLL_PROCESS_ATTACH) {
        g_self = m;
        DisableThreadLibraryCalls(m);
        CreateThread(nullptr, 0, Init, nullptr, 0, nullptr);
    }
    return TRUE;
}
