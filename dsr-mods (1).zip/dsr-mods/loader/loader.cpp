// Прокси dinput8.dll: пробрасывает DirectInput8Create в системную библиотеку
// и подгружает все *.dll из папки DSRMods рядом с собой.
#include <windows.h>
#include <objbase.h>
#include <string>

typedef HRESULT(WINAPI* DI8Create)(HINSTANCE, DWORD, REFIID, LPVOID*, LPUNKNOWN);

HRESULT WINAPI DirectInput8Create(HINSTANCE h, DWORD v, REFIID r, LPVOID* o, LPUNKNOWN u) {
    static DI8Create fn = nullptr;
    if (!fn) {
        char sys[MAX_PATH];
        GetSystemDirectoryA(sys, MAX_PATH);
        std::string p = std::string(sys) + "\\dinput8.dll";
        HMODULE real = LoadLibraryA(p.c_str());
        if (real) fn = (DI8Create)GetProcAddress(real, "DirectInput8Create");
    }
    return fn ? fn(h, v, r, o, u) : E_FAIL;
}

static DWORD WINAPI LoadMods(LPVOID self) {
    char path[MAX_PATH];
    GetModuleFileNameA((HMODULE)self, path, MAX_PATH);
    std::string dir = path;
    dir = dir.substr(0, dir.find_last_of("\\/") + 1) + "DSRMods\\";
    WIN32_FIND_DATAA fd;
    HANDLE h = FindFirstFileA((dir + "*.dll").c_str(), &fd);
    if (h == INVALID_HANDLE_VALUE) return 0;
    do {
        LoadLibraryA((dir + fd.cFileName).c_str());
    } while (FindNextFileA(h, &fd));
    FindClose(h);
    return 0;
}

BOOL APIENTRY DllMain(HMODULE m, DWORD reason, LPVOID) {
    if (reason == DLL_PROCESS_ATTACH) {
        DisableThreadLibraryCalls(m);
        CreateThread(nullptr, 0, LoadMods, m, 0, nullptr);
    }
    return TRUE;
}
