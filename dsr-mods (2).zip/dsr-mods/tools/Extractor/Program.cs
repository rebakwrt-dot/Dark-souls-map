// DSRExtract: читает карты Dark Souls Remastered (*.msb / *.msb.dcx) и создаёт markers.json
// для мода DSRMap: все враги и предметы (сундуки/трупы с лутом) на каждой карте.
//
// Использование:  DSRExtract.exe [папка_игры] [куда_сохранить_markers.json]
using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Numerics;
using System.Reflection;
using System.Text.Json;
using SoulsFormats;

static class Program
{
    static object Get(object o, string name)
    {
        var p = o.GetType().GetProperty(name, BindingFlags.Public | BindingFlags.Instance);
        return p?.GetValue(o);
    }

    static List<object> Entries(object container)
    {
        var res = new List<object>();
        if (container == null) return res;
        var m = container.GetType().GetMethod("GetEntries", BindingFlags.Public | BindingFlags.Instance, null, Type.EmptyTypes, null);
        if (m != null && m.Invoke(container, null) is IEnumerable en)
            foreach (var e in en) res.Add(e);
        return res;
    }

    static bool Pos(object o, out Vector3 v)
    {
        v = default;
        if (Get(o, "Position") is Vector3 p) { v = p; return true; }
        return false;
    }

    static int Main(string[] args)
    {
        string root = args.Length > 0 ? args[0] : Directory.GetCurrentDirectory();
        string outPath = args.Length > 1 ? args[1] : Path.Combine(root, "markers.json");

        var files = Directory.EnumerateFiles(root, "*.msb*", SearchOption.AllDirectories)
            .Where(f => f.EndsWith(".msb", StringComparison.OrdinalIgnoreCase) ||
                        f.EndsWith(".msb.dcx", StringComparison.OrdinalIgnoreCase))
            .OrderBy(f => f).ToList();
        if (files.Count == 0)
        {
            Console.WriteLine("Файлы *.msb не найдены в: " + root);
            Console.WriteLine("Сначала распакуйте игру (например, UXM Selective Unpacker), затем укажите папку игры.");
            return 1;
        }

        var result = new SortedDictionary<string, List<Dictionary<string, object>>>();
        int ok = 0, fail = 0;
        foreach (var f in files)
        {
            string map = Path.GetFileName(f);
            map = map.Substring(0, map.IndexOf('.'));
            try
            {
                var msb = MSB1.Read(f);
                var list = new List<Dictionary<string, object>>();
                var parts = Entries(Get(msb, "Parts"));
                var byName = new Dictionary<string, object>();
                foreach (var p in parts)
                    if (Get(p, "Name") is string n) byName[n] = p;

                foreach (var p in parts)
                {
                    if (p.GetType().Name != "Enemy" || !Pos(p, out var v)) continue;
                    string model = Get(p, "ModelName") as string ?? "enemy";
                    list.Add(new() { ["type"] = "enemy", ["name"] = model, ["x"] = v.X, ["y"] = v.Y, ["z"] = v.Z });
                }

                foreach (var e in Entries(Get(msb, "Events")))
                {
                    if (e.GetType().Name != "Treasure") continue;
                    string partName = (Get(e, "TreasurePartName") ?? Get(e, "PartName")) as string;
                    if (partName == null || !byName.TryGetValue(partName, out var part) || !Pos(part, out var v)) continue;
                    list.Add(new() { ["type"] = "loot", ["name"] = Get(e, "Name") as string ?? "treasure", ["x"] = v.X, ["y"] = v.Y, ["z"] = v.Z });
                }

                result[map] = list;
                Console.WriteLine($"{map}: {list.Count(m => (string)m["type"] == "enemy")} врагов, {list.Count(m => (string)m["type"] == "loot")} предметов");
                ok++;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"{map}: ошибка ({ex.GetType().Name}: {ex.Message})");
                fail++;
            }
        }

        Directory.CreateDirectory(Path.GetDirectoryName(Path.GetFullPath(outPath)));
        File.WriteAllText(outPath, JsonSerializer.Serialize(result, new JsonSerializerOptions { WriteIndented = false }));
        Console.WriteLine($"\nГотово: карт {ok}, ошибок {fail}. Файл: {outPath}");
        return ok > 0 ? 0 : 1;
    }
}
