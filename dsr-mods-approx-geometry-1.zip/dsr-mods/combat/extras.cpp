#define _CRT_SECURE_NO_WARNINGS
// DSRCombat: coordinate-only predictive dodge using configurable geometric proxies.
// These proxies are approximations, not the game's real attack hitboxes.
#include <windows.h>
#include <algorithm>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <string>
#include <unordered_map>
#include <vector>

#include "imgui.h"
#include "../common/mem.h"
#include "combat.h"

namespace {
struct Config {
    Chain animReq;
    int toggleKey = VK_NUMPAD9;
    int rollClass = 0;
    float rangeM = 3.5f;
    float leadMs = 130.0f;
    float cooldownMs = 800.0f;
    float playerRadius = 0.48f;
    float playerHeight = 1.65f;
    float playerYOffset = 0.10f;
    float enemyAttackRadius = 0.72f;
    float enemyAttackLength = 2.15f;
    float enemyAttackHeight = 1.35f;
    float enemyAttackYOffset = 0.65f;
    float predictionHorizonMs = 650.0f;
    bool predictionEnabled = true;
    bool debugDraw = false;
};
Config g_cfg;
uintptr_t g_base = 0;
bool g_loaded = false;
bool g_enabled = true;
bool g_prevToggle = false;
ULONGLONG g_nextRoll = 0;

struct Sample { float x=0, y=0, z=0; ULONGLONG ms=0; };
struct Track {
    Sample older{}, latest{};
    float vx=0, vy=0, vz=0;
    float ax=0, ay=0, az=0;
    bool valid=false;
    bool threatLatched=false;
};
std::unordered_map<uintptr_t, Track> g_tracks;
struct ThreatDebug {
    float ex=0, ey=0, ez=0, fx=0, fz=1, t=-1;
    bool hit=false;
};
std::vector<ThreatDebug> g_debug;

std::string Ini() { return CombatIniPath(); }
std::string ReadIni(const char* section, const char* key, const char* def) {
    char b[256]{};
    GetPrivateProfileStringA(section, key, def, b, sizeof(b), Ini().c_str());
    return b;
}
float ReadFloat(const char* key, float def, float lo, float hi) {
    char d[32]{}; snprintf(d, sizeof(d), "%g", def);
    return std::clamp((float)atof(ReadIni("auto_roll", key, d).c_str()), lo, hi);
}
bool ReadBool(const char* key, bool def) {
    return ReadIni("auto_roll", key, def ? "1" : "0") != "0";
}
void EnsureDefault(const char* key, const char* value) {
    char b[8]{};
    GetPrivateProfileStringA("auto_roll", key, "\x01", b, sizeof(b), Ini().c_str());
    if (b[0] == '\x01') WritePrivateProfileStringA("auto_roll", key, value, Ini().c_str());
}
void LoadCfg() {
    // Legacy INI entries are left untouched; only the keys below are consumed here.
    const char* defaults[][2] = {
        {"toggle_key", "0x69"}, {"roll_class", "0"}, {"range_m", "3.5"},
        {"roll_lead_ms", "130"}, {"cooldown_ms", "800"},
        {"player_radius", "0.48"}, {"player_height", "1.65"}, {"player_y_offset", "0.10"},
        {"enemy_attack_radius", "0.72"}, {"enemy_attack_length", "2.15"},
        {"enemy_attack_height", "1.35"}, {"enemy_attack_y_offset", "0.65"},
        {"prediction_horizon_ms", "650"}, {"prediction_enabled", "1"}, {"debug_draw", "0"}
    };
    for (const auto& d : defaults) EnsureDefault(d[0], d[1]);
    Config c;
    c.animReq = ParseChain(ReadIni("offsets", "anim_request", ""));
    c.toggleKey = (int)strtol(ReadIni("auto_roll", "toggle_key", "0x69").c_str(), nullptr, 0);
    c.rollClass = std::clamp(atoi(ReadIni("auto_roll", "roll_class", "0").c_str()), 0, 2);
    c.rangeM = ReadFloat("range_m", 3.5f, 0.5f, 15.0f);
    c.leadMs = ReadFloat("roll_lead_ms", 130.0f, 20.0f, 500.0f);
    c.cooldownMs = ReadFloat("cooldown_ms", 800.0f, 200.0f, 2500.0f);
    c.playerRadius = ReadFloat("player_radius", 0.48f, 0.15f, 1.5f);
    c.playerHeight = ReadFloat("player_height", 1.65f, 0.6f, 2.8f);
    c.playerYOffset = ReadFloat("player_y_offset", 0.10f, -1.0f, 1.0f);
    c.enemyAttackRadius = ReadFloat("enemy_attack_radius", 0.72f, 0.15f, 2.5f);
    c.enemyAttackLength = ReadFloat("enemy_attack_length", 2.15f, 0.3f, 6.0f);
    c.enemyAttackHeight = ReadFloat("enemy_attack_height", 1.35f, 0.3f, 3.5f);
    c.enemyAttackYOffset = ReadFloat("enemy_attack_y_offset", 0.65f, -1.0f, 2.5f);
    c.predictionHorizonMs = ReadFloat("prediction_horizon_ms", 650.0f, 100.0f, 1500.0f);
    c.predictionEnabled = ReadBool("prediction_enabled", true);
    c.debugDraw = ReadBool("debug_draw", false);
    g_cfg = c;
    g_loaded = true;
}

template <class T> bool WriteAt(uintptr_t address, T value) {
    if (address < 0x10000 || address > UINTPTR_MAX - sizeof(T)) return false;
    __try { *reinterpret_cast<T*>(address) = value; return true; }
    __except (EXCEPTION_EXECUTE_HANDLER) { return false; }
}
float Length2(float x, float z) { return std::sqrt(x*x + z*z); }
void Normalize(float& x, float& z) {
    const float n = Length2(x, z);
    if (n > 0.0001f) { x /= n; z /= n; }
    else { x = 0.0f; z = 1.0f; }
}
float PointSegmentDistance2D(float px, float pz, float ax, float az, float bx, float bz) {
    const float dx = bx - ax, dz = bz - az;
    const float d2 = dx*dx + dz*dz;
    float t = d2 > 0.000001f ? ((px-ax)*dx + (pz-az)*dz) / d2 : 0.0f;
    t = std::clamp(t, 0.0f, 1.0f);
    return Length2(px - (ax + t*dx), pz - (az + t*dz));
}

bool UpdateTrack(const EnemyView& e, ULONGLONG now, Track& tr) {
    if (!tr.valid) {
        tr.latest = {e.x,e.y,e.z,now}; tr.older = tr.latest; tr.valid = true;
        return false;
    }
    if (now <= tr.latest.ms) return false;
    const float dt = (float)(now - tr.latest.ms) / 1000.0f;
    const float dx=e.x-tr.latest.x, dy=e.y-tr.latest.y, dz=e.z-tr.latest.z;
    const float jump = std::sqrt(dx*dx + dy*dy + dz*dz);
    // Ignore implausible teleports / entity reuse and restart the history.
    if (dt > 0.30f || dt < 0.004f || jump > 8.0f) {
        tr = Track{}; tr.latest = {e.x,e.y,e.z,now}; tr.older = tr.latest; tr.valid = true;
        return false;
    }
    const float ivx=dx/dt, ivy=dy/dt, ivz=dz/dt;
    const float oldVx=tr.vx, oldVy=tr.vy, oldVz=tr.vz;
    tr.ax = std::clamp((ivx-oldVx)/dt, -35.0f, 35.0f);
    tr.ay = std::clamp((ivy-oldVy)/dt, -35.0f, 35.0f);
    tr.az = std::clamp((ivz-oldVz)/dt, -35.0f, 35.0f);
    // Smooth velocity to reduce noisy single-frame position changes.
    tr.vx = oldVx*0.35f + ivx*0.65f;
    tr.vy = oldVy*0.35f + ivy*0.65f;
    tr.vz = oldVz*0.35f + ivz*0.65f;
    tr.older = tr.latest;
    tr.latest = {e.x,e.y,e.z,now};
    return true;
}

bool FindPredictedContact(const EnemyView& e, const PeerView& me, const Track& tr,
                          float& contactTime, float& outFx, float& outFz) {
    const float rx=me.x-e.x, rz=me.z-e.z;
    if (Length2(rx,rz) > g_cfg.rangeM) return false; // range_m is the real detection limit

    float fx=std::sin(e.ang), fz=std::cos(e.ang);
    Normalize(fx,fz);
    const float speed=Length2(tr.vx,tr.vz);
    if (speed > 0.45f) {
        float mx=tr.vx/speed, mz=tr.vz/speed;
        // Blend facing and measured travel direction; never infer attack state from animation.
        fx=fx*0.65f + mx*0.35f; fz=fz*0.65f + mz*0.35f;
        Normalize(fx,fz);
    }
    outFx=fx; outFz=fz;
    const float horizon=g_cfg.predictionEnabled ? g_cfg.predictionHorizonMs/1000.0f : 0.0f;
    const float radius=g_cfg.enemyAttackRadius + g_cfg.playerRadius;
    const float playerBottom=me.y + g_cfg.playerYOffset;
    const float playerTop=playerBottom + g_cfg.playerHeight;
    if (e.hasY) {
        const float attackBottom=e.y + g_cfg.enemyAttackYOffset;
        const float attackTop=attackBottom + g_cfg.enemyAttackHeight;
        if (attackTop < playerBottom || attackBottom > playerTop) return false;
    }

    // Sweep the approximate forward capsule along the predicted root trajectory.
    // This is intentionally a configurable proxy, not a claim about real game hitboxes.
    const float step=0.025f;
    const int steps=std::max(1,(int)std::ceil(horizon/step));
    for (int i=0;i<=steps;++i) {
        const float t=(horizon>0.0f) ? std::min(horizon, i*step) : 0.0f;
        const float ex=e.x + tr.vx*t + 0.5f*tr.ax*t*t;
        const float ez=e.z + tr.vz*t + 0.5f*tr.az*t*t;
        float ax=ex + fx*0.20f, az=ez + fz*0.20f;
        float bx=ex + fx*std::min(g_cfg.enemyAttackLength,g_cfg.rangeM);
        float bz=ez + fz*std::min(g_cfg.enemyAttackLength,g_cfg.rangeM);
        const float d=PointSegmentDistance2D(me.x,me.z,ax,az,bx,bz);
        if (d <= radius) { contactTime=t; return true; }
    }
    return false;
}

void DrawDebug(const PeerView& me, const std::vector<EnemyView>& enemies) {
    if (!g_cfg.debugDraw) return;
    ImDrawList* dl=ImGui::GetForegroundDrawList();
    const ImVec2 display=ImGui::GetIO().DisplaySize;
    const ImVec2 origin(display.x-190.0f, 190.0f);
    constexpr float scale=34.0f;
    dl->AddCircle(origin, 4.0f, IM_COL32(80,220,120,255), 16, 2.0f);
    dl->AddCircle(origin, g_cfg.rangeM*scale, IM_COL32(120,120,120,90), 48, 1.0f);
    dl->AddText(ImVec2(origin.x-45,origin.y+8),IM_COL32(100,240,140,255),"PLAYER");
    for (const auto& e:enemies) {
        auto it=g_tracks.find(e.ptr); if (it==g_tracks.end()) continue;
        const Track& tr=it->second;
        const float dx=e.x-me.x, dz=e.z-me.z;
        const ImVec2 ep(origin.x+dx*scale,origin.y-dz*scale);
        float fx=std::sin(e.ang), fz=std::cos(e.ang); Normalize(fx,fz);
        const ImVec2 end(ep.x+fx*g_cfg.enemyAttackLength*scale,ep.y-fz*g_cfg.enemyAttackLength*scale);
        dl->AddCircle(ep,4.0f,IM_COL32(255,180,70,255),12,1.5f);
        dl->AddLine(ep,end,IM_COL32(255,150,60,180),2.0f);
        dl->AddCircle(end,g_cfg.enemyAttackRadius*scale,IM_COL32(255,100,70,110),16,1.0f);
        const float sp=Length2(tr.vx,tr.vz);
        if (sp>0.05f) dl->AddLine(ep,ImVec2(ep.x+tr.vx*0.25f*scale,ep.y-tr.vz*0.25f*scale),IM_COL32(80,180,255,255),2.0f);
        auto dbg=std::find_if(g_debug.begin(),g_debug.end(),[&](const ThreatDebug& d){return d.ex==e.x&&d.ez==e.z;});
        if (dbg!=g_debug.end() && dbg->hit) {
            char label[64]; snprintf(label,sizeof(label),"CONTACT %.0f ms",dbg->t*1000.0f);
            dl->AddText(ImVec2(ep.x+5,ep.y-18),IM_COL32(255,90,90,255),label);
        }
    }
}

bool Focused() {
    DWORD pid=0; GetWindowThreadProcessId(GetForegroundWindow(),&pid);
    return pid==GetCurrentProcessId();
}

void AutoRollTick(ULONGLONG now) {
    if (!Focused()) return;
    const bool toggle=g_cfg.toggleKey && (GetAsyncKeyState(g_cfg.toggleKey)&0x8000);
    if (toggle && !g_prevToggle) g_enabled=!g_enabled;
    g_prevToggle=toggle;
    if (!g_enabled || now<g_nextRoll) return;

    PeerView me;
    if (!CoopMyPosition(me)) return;
    if (!g_cfg.animReq.valid()) return;
    std::vector<EnemyView> enemies;
    if (!WorldEnemyPositions(enemies)) return;

    if (g_tracks.size()>512) {
        for (auto it=g_tracks.begin();it!=g_tracks.end();) {
            if (now>it->second.latest.ms+2000) it=g_tracks.erase(it); else ++it;
        }
    }
    g_debug.clear();
    for (const auto& enemy:enemies) {
        if (!enemy.ptr) continue;
        Track& tr=g_tracks[enemy.ptr];
        const bool hasMotion=UpdateTrack(enemy,now,tr);
        if (!hasMotion) continue;
        float tContact=0,fx=0,fz=1;
        const bool threat=FindPredictedContact(enemy,me,tr,tContact,fx,fz);
        g_debug.push_back({enemy.x,enemy.y,enemy.z,fx,fz,tContact,threat});
        if (!threat) { tr.threatLatched=false; continue; }
        if (tContact*1000.0f > g_cfg.leadMs+35.0f || tr.threatLatched) continue;

        const float dx=enemy.x-me.x, dz=enemy.z-me.z;
        const float playerFx=std::sin(me.ang), playerFz=std::cos(me.ang);
        const bool threatFront=(playerFx*dx+playerFz*dz)>0.0f;
        const int direction=threatFront?1:0;
        uintptr_t requestAddress=0;
        if (!Resolve(g_cfg.animReq,g_base,requestAddress)) continue;
        const int32_t command=700+g_cfg.rollClass*10+direction;
        if (!WriteAt<int32_t>(requestAddress,command)) continue;
        tr.threatLatched=true;
        g_nextRoll=now+(ULONGLONG)g_cfg.cooldownMs;
        break;
    }
    DrawDebug(me,enemies);
}
} // namespace

void ExtrasReloadCfg() { LoadCfg(); }
float ExtrasSpent() { return 0.0f; }
bool ExtrasNoDamageBuff() { return false; }

void ExtrasTick() {
    static ULONGLONG next=0;
    const ULONGLONG now=GetTickCount64();
    if (now<next) return;
    next=now+8;
    if (!g_base) g_base=(uintptr_t)GetModuleHandleA(nullptr);
    if (!g_loaded) LoadCfg();
    AutoRollTick(now);
}

void ExtrasUI() {
    ImGui::Separator();
    ImGui::Text("Автоматический перекат: %s",g_enabled?"включён":"выключен");
    ImGui::TextDisabled("NumPad 9 / toggle_key — переключение. Геометрия атак приблизительная.");
    ImGui::TextDisabled("Координаты и угол; без чтения анимаций и выносливости.");
}
