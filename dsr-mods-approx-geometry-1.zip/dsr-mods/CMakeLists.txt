cmake_minimum_required(VERSION 3.24)
project(DSRMods CXX)

set(CMAKE_CXX_STANDARD 20)
set(CMAKE_CXX_STANDARD_REQUIRED ON)
set(CMAKE_MSVC_RUNTIME_LIBRARY "MultiThreaded")
add_compile_options(/utf-8 /EHsc)
add_definitions(-DNOMINMAX -DWIN32_LEAN_AND_MEAN)

include(FetchContent)
set(FETCHCONTENT_QUIET OFF)
FetchContent_Declare(imgui
    GIT_REPOSITORY https://github.com/ocornut/imgui.git
    GIT_TAG v1.91.5)
FetchContent_MakeAvailable(imgui)

add_library(imgui_lib STATIC
    ${imgui_SOURCE_DIR}/imgui.cpp
    ${imgui_SOURCE_DIR}/imgui_draw.cpp
    ${imgui_SOURCE_DIR}/imgui_tables.cpp
    ${imgui_SOURCE_DIR}/imgui_widgets.cpp
    ${imgui_SOURCE_DIR}/backends/imgui_impl_win32.cpp
    ${imgui_SOURCE_DIR}/backends/imgui_impl_dx11.cpp)
target_include_directories(imgui_lib PUBLIC ${imgui_SOURCE_DIR} ${imgui_SOURCE_DIR}/backends)
target_link_libraries(imgui_lib PUBLIC d3d11 dxgi d3dcompiler)

set(PKG "${CMAKE_BINARY_DIR}/package")

# 1) Загрузчик: dinput8.dll -> подгружает все DLL из папки DSRMods
add_library(dinput8 SHARED loader/loader.cpp loader/dinput8.def)
set_target_properties(dinput8 PROPERTIES
    PREFIX "" RUNTIME_OUTPUT_DIRECTORY "${PKG}/$<0:>")


# 2) Мод оптимизации
add_library(DSROptimize SHARED optimize/optimize.cpp common/dx11_hook.cpp)
target_link_libraries(DSROptimize PRIVATE d3d11 dxgi)
set_target_properties(DSROptimize PROPERTIES
    PREFIX "" RUNTIME_OUTPUT_DIRECTORY "${PKG}/DSRMods/$<0:>")

# 3) Боевой мод: авто-перекат + LAN-кооператив
add_library(DSRCombat SHARED combat/combat.cpp combat/calib.cpp combat/coop.cpp combat/world.cpp combat/extras.cpp common/dx11_hook.cpp)
target_link_libraries(DSRCombat PRIVATE imgui_lib ws2_32)
set_target_properties(DSRCombat PROPERTIES
    PREFIX "" RUNTIME_OUTPUT_DIRECTORY "${PKG}/DSRMods/$<0:>")
