#define _CRT_SECURE_NO_WARNINGS
// DSRCombat: coordinate-only predictive dodge using configurable geometric proxies.
// These proxies are approximations, not the game's real attack hitboxes.
#include <windows.h>
#include <algorithm>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <atomic>
#include <mutex>
#include <set>
#include <string>
#include <unordered_map>
#include <vector>

#include "imgui.h"
#include "../common/mem.h"
#include "combat.h"

namespace {
struct Config {
    Chain animReq;
    int toggleKey = VK_NUMPAD9;
    int rollClass = 0;
    float rangeM = 3.5f;
    float leadMs = 130.0f;
    float cooldownMs = 800.0f;
    float playerRadius = 0.48f;
    float playerHeight = 1.65f;
    float playerYOffset = 0.10f;
    float enemyAttackRadius = 0.72f;
    float enemyAttackLength = 2.15f;
    float enemyAttackHeight = 1.35f;
    float enemyAttackYOffset = 0.65f;
    float predictionHorizonMs = 650.0f;
    bool predictionEnabled = true;
    bool debugDraw = false;
    // Только боссы: перекат срабатывает лишь на врагов из списка боссов / отмеченных вручную.
    // Если цепочка anim_request не задана, перекат выполняется «нажатием» клавиши (по умолчанию Left Shift).
    int rollKey = 0xA0;         // VK_LSHIFT
    int rollHoldMs = 60;
    bool bossesOnly = true;
    int markKey = VK_NUMPAD8;   // пометить / снять метку «босс» с ближайшего врага
    int clearKey = VK_NUMPAD7;  // снять все ручные метки
    float markRangeM = 25.0f;
    std::vector<int32_t> extraBossIds;
};

// Entity ID боссов Dark Souls (Souls Modding Wiki, страница ds1-refmat:boss-info).
// У Bed of Chaos, Ornstein & Smough и Four Kings на вики нет entity ID — их отмечайте клавишей mark_key.
constexpr int32_t kBossIds[] = {
    1000800,           // Gaping Dragon
    1010700,           // Taurus Demon
    1010800, 1010801,  // Bell Gargoyles
    1010750,           // Capra Demon
    1100160,           // Priscilla
    1200801,           // Moonlight Butterfly
    1200800,           // Wolf Sif
    1210800,           // Sanctuary Guardian
    1210820,           // Knight Artorias
    1210840,           // Manus
    1210401, 1210402,  // Kalameet
    1300800,           // Pinwheel
    1310800,           // Nito
    1400800,           // Quelaag
    1410600,           // Ceaseless Discharge
    1410400,           // Demon Firesage
    1410700,           // Centipede Demon
    1500800,           // Iron Golem
    1510650,           // Gwyndolin
    1700800,           // Seath
    1800800,           // Gwyn
    1810800,           // Asylum Demon
    1810810,           // Stray Demon
};
Config g_cfg;
uintptr_t g_base = 0;
bool g_loaded = false;
bool g_enabled = true;
bool g_prevToggle = false;
ULONGLONG g_nextRoll = 0;
uintptr_t g_playerPtr = 0;               // указатель на сущность игрока (если найден автопоиском)
std::set<uintptr_t> g_marked;            // ручные метки боссов (только поток логики)
std::atomic<int> g_markedCount{0}, g_bossInView{0}, g_idsRead{0};
std::mutex g_uiMx;
std::string g_uiStatus;
void SetUi(const std::string& t) { std::lock_guard<std::mutex> l(g_uiMx); g_uiStatus = t; }

struct Sample { float x=0, y=0, z=0; ULONGLONG ms=0; };
struct Track {
    Sample older{}, latest{};
    float vx=0, vy=0, vz=0;
    float ax=0, ay=0, az=0;
    bool valid=false;
    bool threatLatched=false;
};
std::unordered_map<uintptr_t, Track> g_tracks;
struct ThreatDebug {
    float ex=0, ey=0, ez=0, fx=0, fz=1, t=-1;
    bool hit=false;
};
std::vector<ThreatDebug> g_debug;

std::string Ini() { return CombatIniPath(); }
std::string ReadIni(const char* section, const char* key, const char* def) {
    char b[256]{};
    GetPrivateProfileStringA(section, key, def, b, sizeof(b), Ini().c_str());
    return b;
}
float ReadFloat(const char* key, float def, float lo, float hi) {
    char d[32]{}; snprintf(d, sizeof(d), "%g", def);
    return std::clamp((float)atof(ReadIni("auto_roll", key, d).c_str()), lo, hi);
}
bool ReadBool(const char* key, bool def) {
    return ReadIni("auto_roll", key, def ? "1" : "0") != "0";
}
void EnsureDefault(const char* key, const char* value) {
    char b[8]{};
    GetPrivateProfileStringA("auto_roll", key, "\x01", b, sizeof(b), Ini().c_str());
    if (b[0] == '\x01') WritePrivateProfileStringA("auto_roll", key, value, Ini().c_str());
}
void LoadCfg() {
    // Legacy INI entries are left untouched; only the keys below are consumed here.
    const char* defaults[][2] = {
        {"toggle_key", "0x69"}, {"roll_class", "0"}, {"range_m", "3.5"},
        {"roll_lead_ms", "130"}, {"cooldown_ms", "800"},
        {"player_radius", "0.48"}, {"player_height", "1.65"}, {"player_y_offset", "0.10"},
        {"enemy_attack_radius", "0.72"}, {"enemy_attack_length", "2.15"},
        {"enemy_attack_height", "1.35"}, {"enemy_attack_y_offset", "0.65"},
        {"prediction_horizon_ms", "650"}, {"prediction_enabled", "1"}, {"debug_draw", "0"},
        {"roll_key", "0xA0"}, {"roll_hold_ms", "60"}, {"bosses_only", "1"}, {"boss_ids", ""}, {"mark_key", "0x68"}, {"clear_marks_key", "0x67"}, {"mark_range_m", "25"}
    };
    for (const auto& d : defaults) EnsureDefault(d[0], d[1]);
    Config c;
    c.animReq = ParseChain(ReadIni("offsets", "anim_request", ""));
    c.toggleKey = (int)strtol(ReadIni("auto_roll", "toggle_key", "0x69").c_str(), nullptr, 0);
    c.rollClass = std::clamp(atoi(ReadIni("auto_roll", "roll_class", "0").c_str()), 0, 2);
    c.rangeM = ReadFloat("range_m", 3.5f, 0.5f, 15.0f);
    c.leadMs = ReadFloat("roll_lead_ms", 130.0f, 20.0f, 500.0f);
    c.cooldownMs = ReadFloat("cooldown_ms", 800.0f, 200.0f, 2500.0f);
    c.playerRadius = ReadFloat("player_radius", 0.48f, 0.15f, 1.5f);
    c.playerHeight = ReadFloat("player_height", 1.65f, 0.6f, 2.8f);
    c.playerYOffset = ReadFloat("player_y_offset", 0.10f, -1.0f, 1.0f);
    c.enemyAttackRadius = ReadFloat("enemy_attack_radius", 0.72f, 0.15f, 2.5f);
    c.enemyAttackLength = ReadFloat("enemy_attack_length", 2.15f, 0.3f, 6.0f);
    c.enemyAttackHeight = ReadFloat("enemy_attack_height", 1.35f, 0.3f, 3.5f);
    c.enemyAttackYOffset = ReadFloat("enemy_attack_y_offset", 0.65f, -1.0f, 2.5f);
    c.predictionHorizonMs = ReadFloat("prediction_horizon_ms", 650.0f, 100.0f, 1500.0f);
    c.predictionEnabled = ReadBool("prediction_enabled", true);
    c.debugDraw = ReadBool("debug_draw", false);
    c.rollKey = (int)strtol(ReadIni("auto_roll", "roll_key", "0xA0").c_str(), nullptr, 0);
    c.rollHoldMs = (int)ReadFloat("roll_hold_ms", 60.0f, 20.0f, 250.0f);
    c.bossesOnly = ReadBool("bosses_only", true);
    c.markKey = (int)strtol(ReadIni("auto_roll", "mark_key", "0x68").c_str(), nullptr, 0);
    c.clearKey = (int)strtol(ReadIni("auto_roll", "clear_marks_key", "0x67").c_str(), nullptr, 0);
    c.markRangeM = ReadFloat("mark_range_m", 25.0f, 3.0f, 100.0f);
    {   // boss_ids=1234567, 1234568 — дополнительные entity ID сверх встроенного списка
        const std::string list = ReadIni("auto_roll", "boss_ids", "");
        size_t i = 0;
        while (i < list.size()) {
            size_t j = list.find_first_of(",; ", i);
            if (j == std::string::npos) j = list.size();
            if (j > i) {
                const long v = strtol(list.substr(i, j - i).c_str(), nullptr, 0);
                if (v > 0) c.extraBossIds.push_back((int32_t)v);
            }
            i = j + 1;
        }
    }
    g_cfg = c;
    g_loaded = true;
}

template <class T> bool WriteAt(uintptr_t address, T value) {
    if (address < 0x10000 || address > UINTPTR_MAX - sizeof(T)) return false;
    __try { *reinterpret_cast<T*>(address) = value; return true; }
    __except (EXCEPTION_EXECUTE_HANDLER) { return false; }
}
float Length2(float x, float z) { return std::sqrt(x*x + z*z); }
void Normalize(float& x, float& z) {
    const float n = Length2(x, z);
    if (n > 0.0001f) { x /= n; z /= n; }
    else { x = 0.0f; z = 1.0f; }
}
float PointSegmentDistance2D(float px, float pz, float ax, float az, float bx, float bz) {
    const float dx = bx - ax, dz = bz - az;
    const float d2 = dx*dx + dz*dz;
    float t = d2 > 0.000001f ? ((px-ax)*dx + (pz-az)*dz) / d2 : 0.0f;
    t = std::clamp(t, 0.0f, 1.0f);
    return Length2(px - (ax + t*dx), pz - (az + t*dz));
}

bool UpdateTrack(const EnemyView& e, ULONGLONG now, Track& tr) {
    if (!tr.valid) {
        tr.latest = {e.x,e.y,e.z,now}; tr.older = tr.latest; tr.valid = true;
        return false;
    }
    if (now <= tr.latest.ms) return false;
    const float dt = (float)(now - tr.latest.ms) / 1000.0f;
    const float dx=e.x-tr.latest.x, dy=e.y-tr.latest.y, dz=e.z-tr.latest.z;
    const float jump = std::sqrt(dx*dx + dy*dy + dz*dz);
    // Ignore implausible teleports / entity reuse and restart the history.
    if (dt > 0.30f || dt < 0.004f || jump > 8.0f) {
        tr = Track{}; tr.latest = {e.x,e.y,e.z,now}; tr.older = tr.latest; tr.valid = true;
        return false;
    }
    const float ivx=dx/dt, ivy=dy/dt, ivz=dz/dt;
    const float oldVx=tr.vx, oldVy=tr.vy, oldVz=tr.vz;
    tr.ax = std::clamp((ivx-oldVx)/dt, -35.0f, 35.0f);
    tr.ay = std::clamp((ivy-oldVy)/dt, -35.0f, 35.0f);
    tr.az = std::clamp((ivz-oldVz)/dt, -35.0f, 35.0f);
    // Smooth velocity to reduce noisy single-frame position changes.
    tr.vx = oldVx*0.35f + ivx*0.65f;
    tr.vy = oldVy*0.35f + ivy*0.65f;
    tr.vz = oldVz*0.35f + ivz*0.65f;
    tr.older = tr.latest;
    tr.latest = {e.x,e.y,e.z,now};
    return true;
}

bool FindPredictedContact(const EnemyView& e, const PeerView& me, const Track& tr,
                          float& contactTime, float& outFx, float& outFz) {
    const float rx=me.x-e.x, rz=me.z-e.z;
    if (Length2(rx,rz) > g_cfg.rangeM) return false; // range_m is the real detection limit

    float fx=std::sin(e.ang), fz=std::cos(e.ang);
    Normalize(fx,fz);
    const float speed=Length2(tr.vx,tr.vz);
    if (speed > 0.45f) {
        float mx=tr.vx/speed, mz=tr.vz/speed;
        // Blend facing and measured travel direction; never infer attack state from animation.
        fx=fx*0.65f + mx*0.35f; fz=fz*0.65f + mz*0.35f;
        Normalize(fx,fz);
    }
    outFx=fx; outFz=fz;
    const float horizon=g_cfg.predictionEnabled ? g_cfg.predictionHorizonMs/1000.0f : 0.0f;
    const float radius=g_cfg.enemyAttackRadius + g_cfg.playerRadius;
    const float playerBottom=me.y + g_cfg.playerYOffset;
    const float playerTop=playerBottom + g_cfg.playerHeight;
    if (e.hasY) {
        const float attackBottom=e.y + g_cfg.enemyAttackYOffset;
        const float attackTop=attackBottom + g_cfg.enemyAttackHeight;
        if (attackTop < playerBottom || attackBottom > playerTop) return false;
    }

    // Sweep the approximate forward capsule along the predicted root trajectory.
    // This is intentionally a configurable proxy, not a claim about real game hitboxes.
    const float step=0.025f;
    const int steps=std::max(1,(int)std::ceil(horizon/step));
    for (int i=0;i<=steps;++i) {
        const float t=(horizon>0.0f) ? std::min(horizon, i*step) : 0.0f;
        const float ex=e.x + tr.vx*t + 0.5f*tr.ax*t*t;
        const float ez=e.z + tr.vz*t + 0.5f*tr.az*t*t;
        float ax=ex + fx*0.20f, az=ez + fz*0.20f;
        float bx=ex + fx*std::min(g_cfg.enemyAttackLength,g_cfg.rangeM);
        float bz=ez + fz*std::min(g_cfg.enemyAttackLength,g_cfg.rangeM);
        const float d=PointSegmentDistance2D(me.x,me.z,ax,az,bx,bz);
        if (d <= radius) { contactTime=t; return true; }
    }
    return false;
}

// Снимок для отладочной отрисовки: ImGui можно трогать только из потока рендера, а AutoRollTick
// работает в потоке логики. Поэтому логика кладёт сюда копию, а рисует ExtrasDrawDebug() в Present.
struct DbgItem { EnemyView e; Track tr; ThreatDebug d; bool hasD=false; };
struct DbgSnap { PeerView me; std::vector<DbgItem> items; };
std::mutex g_dbgMx;
DbgSnap g_snap;
std::atomic<bool> g_dbgOn{false};
std::atomic<bool> g_reload{false};
ULONGLONG g_idleUntil = 0;

void SaveSnap(const PeerView& me, const std::vector<EnemyView>& enemies) {
    DbgSnap n;
    n.me = me;
    for (const auto& e : enemies) {
        auto it = g_tracks.find(e.ptr);
        if (it == g_tracks.end()) continue;
        DbgItem d;
        d.e = e; d.tr = it->second;
        auto dbg = std::find_if(g_debug.begin(), g_debug.end(), [&](const ThreatDebug& t){ return t.ex==e.x && t.ez==e.z; });
        if (dbg != g_debug.end()) { d.d = *dbg; d.hasD = true; }
        n.items.push_back(d);
    }
    std::lock_guard<std::mutex> l(g_dbgMx);
    g_snap = std::move(n);
}

void DrawDebugSnap(const DbgSnap& sn) {
    const PeerView& me = sn.me;
    ImDrawList* dl=ImGui::GetForegroundDrawList();
    const ImVec2 display=ImGui::GetIO().DisplaySize;
    const ImVec2 origin(display.x-190.0f, 190.0f);
    constexpr float scale=34.0f;
    dl->AddCircle(origin, 4.0f, IM_COL32(80,220,120,255), 16, 2.0f);
    dl->AddCircle(origin, g_cfg.rangeM*scale, IM_COL32(120,120,120,90), 48, 1.0f);
    dl->AddText(ImVec2(origin.x-45,origin.y+8),IM_COL32(100,240,140,255),"PLAYER");
    for (const auto& it : sn.items) {
        const EnemyView& e = it.e; const Track& tr = it.tr;
        const float dx=e.x-me.x, dz=e.z-me.z;
        const ImVec2 ep(origin.x+dx*scale,origin.y-dz*scale);
        float fx=std::sin(e.ang), fz=std::cos(e.ang); Normalize(fx,fz);
        const ImVec2 end(ep.x+fx*g_cfg.enemyAttackLength*scale,ep.y-fz*g_cfg.enemyAttackLength*scale);
        dl->AddCircle(ep,4.0f,IM_COL32(255,180,70,255),12,1.5f);
        dl->AddLine(ep,end,IM_COL32(255,150,60,180),2.0f);
        dl->AddCircle(end,g_cfg.enemyAttackRadius*scale,IM_COL32(255,100,70,110),16,1.0f);
        const float sp=Length2(tr.vx,tr.vz);
        if (sp>0.05f) dl->AddLine(ep,ImVec2(ep.x+tr.vx*0.25f*scale,ep.y-tr.vz*0.25f*scale),IM_COL32(80,180,255,255),2.0f);
        if (it.hasD && it.d.hit) {
            char label[64]; snprintf(label,sizeof(label),"CONTACT %.0f ms",it.d.t*1000.0f);
            dl->AddText(ImVec2(ep.x+5,ep.y-18),IM_COL32(255,90,90,255),label);
        }
    }
}

bool IsBossId(int32_t id) {
    if (id <= 0) return false;
    for (int32_t b : kBossIds) if (b == id) return true;
    for (int32_t b : g_cfg.extraBossIds) if (b == id) return true;
    return false;
}
bool IsBoss(const EnemyView& e) { return g_marked.count(e.ptr) > 0 || IsBossId(e.entityId); }

bool KeyHit(int vk, bool& prev) {
    if (!vk) return false;
    const SHORT st = GetAsyncKeyState(vk);
    const bool down = (st & 0x8000) != 0;
    const bool hit = (down && !prev) || (st & 1);  // низкий бит ловит короткое нажатие между опросами
    prev = down;
    return hit;
}

// Ручная метка: ближайший к игроку враг в mark_range_m становится (или перестаёт быть) боссом.
void HandleMarkKeys() {
    static bool prevMark = false, prevClear = false;
    const bool clear = KeyHit(g_cfg.clearKey, prevClear);
    const bool mark = KeyHit(g_cfg.markKey, prevMark);
    if (clear) {
        g_marked.clear(); g_markedCount = 0;
        SetUi("Ручные метки боссов сброшены.");
    }
    if (!mark) return;
    PeerView me;
    std::vector<EnemyView> en;
    if (!CoopMyPosition(me) || !WorldEnemyPositions(en)) {
        SetUi("Не удалось прочитать позицию игрока или список врагов: проверьте цепочки в DSRCombat.ini.");
        return;
    }
    const EnemyView* best = nullptr;
    float bestD = g_cfg.markRangeM;
    for (const auto& e : en) {
        if (!e.ptr) continue;
        const float d = Length2(e.x - me.x, e.z - me.z);
        if (e.ptr == g_playerPtr || d < 0.5f) continue;  // сам игрок
        if (d < bestD) { bestD = d; best = &e; }
    }
    char msg[200];
    if (!best) {
        snprintf(msg, sizeof(msg), "Нет врагов в радиусе %.0f м от игрока.", g_cfg.markRangeM);
    } else if (g_marked.erase(best->ptr)) {
        snprintf(msg, sizeof(msg), "Метка снята: враг на %.1f м (entity ID %d).", bestD, best->entityId);
    } else {
        g_marked.insert(best->ptr);
        snprintf(msg, sizeof(msg), "Босс отмечен: враг на %.1f м (entity ID %d).", bestD, best->entityId);
    }
    g_markedCount = (int)g_marked.size();
    SetUi(msg);
}

bool CanRoll() { return g_cfg.animReq.valid() || g_cfg.rollKey != 0; }

// Короткое нажатие клавиши переката в отдельном потоке (в DS перекат срабатывает по отпусканию короткого нажатия).
DWORD WINAPI KeyTapThread(LPVOID param) {
    const int vk = (int)(INT_PTR)param & 0xFFFF;
    const int hold = (int)((INT_PTR)param >> 16);
    const WORD scan = (WORD)MapVirtualKeyA((UINT)vk, MAPVK_VK_TO_VSC);
    INPUT in{};
    in.type = INPUT_KEYBOARD;
    in.ki.wVk = 0; in.ki.wScan = scan; in.ki.dwFlags = KEYEVENTF_SCANCODE;
    SendInput(1, &in, sizeof(INPUT));
    Sleep((DWORD)hold);
    in.ki.dwFlags = KEYEVENTF_SCANCODE | KEYEVENTF_KEYUP;
    SendInput(1, &in, sizeof(INPUT));
    return 0;
}
void TapRollKey() {
    HANDLE h = CreateThread(nullptr, 0, KeyTapThread, (LPVOID)(INT_PTR)((g_cfg.rollHoldMs << 16) | (g_cfg.rollKey & 0xFFFF)), 0, nullptr);
    if (h) CloseHandle(h);
}

// ---------- автонастройка цепочек ----------
// Смещения взяты из исходников DSR-Gadget (DSROffsets.cs): WorldChrBase -> +0x68 ChrData1 -> +0x48 (+0x20 на 1.03) ChrMapData
// -> +0x28 ChrPosData -> +0x10 X, +0x14 Y, +0x18 Z, +0x4 угол. Пишутся только в ПУСТЫЕ ключи [offsets].
std::atomic<bool> g_autoDone{false};

bool OffsetKeyEmpty(const char* key) {
    char b[512]{};
    GetPrivateProfileStringA("offsets", key, "", b, sizeof(b), Ini().c_str());
    return b[0] == 0;
}
bool FillIfEmpty(const char* key, const std::string& value) {
    if (!OffsetKeyEmpty(key)) return false;
    WritePrivateProfileStringA("offsets", key, value.c_str(), Ini().c_str());
    return true;
}
int MapDataOffset() {
    const IMAGE_DOS_HEADER* dos = reinterpret_cast<const IMAGE_DOS_HEADER*>(g_base);
    const IMAGE_NT_HEADERS* nt = reinterpret_cast<const IMAGE_NT_HEADERS*>(g_base + dos->e_lfanew);
    const DWORD sz = nt->OptionalHeader.SizeOfImage;
    // Старые сборки 1.01 / 1.01.1 / 1.01.2 — без сдвига; всё остальное считаем как 1.03.
    const bool old = sz == 0x4869400 || sz == 0x496BE00 || sz == 0x37CB400;
    return old ? 0x48 : 0x68;
}
bool Readable(uintptr_t a, size_t n) {
    if (a < 0x10000) return false;
    MEMORY_BASIC_INFORMATION m{};
    if (!VirtualQuery(reinterpret_cast<void*>(a), &m, sizeof(m))) return false;
    if (m.State != MEM_COMMIT || (m.Protect & (PAGE_GUARD | PAGE_NOACCESS))) return false;
    return a + n <= (uintptr_t)m.BaseAddress + m.RegionSize;
}
bool Peek64(uintptr_t a, uintptr_t& o) { return Readable(a, 8) && Rd(a, o); }
bool Peek32(uintptr_t a, int32_t& o) { return Readable(a, 4) && Rd(a, o); }

// Ищем в объекте WorldChrBase (и на уровень глубже) массив указателей, в котором лежит указатель на игрока.
// Рядом с указателем на массив ищем счётчик элементов.
bool ArrayHasPlayer(uintptr_t holder, int& idx) {
    uintptr_t arr = 0;
    if (!Peek64(holder, arr) || !Readable(arr, 8)) return false;
    for (int i = 0; i < 256; ++i) {
        uintptr_t v = 0;
        if (!Peek64(arr + (uintptr_t)i * 8, v)) break;
        if (v == g_playerPtr) { idx = i; return true; }
    }
    return false;
}
bool FindCount(uintptr_t holder, int idx, int& countOff) {
    static const int offs[] = {8, 0xC, 0x10, 4, 0x14, 0x18};
    for (int o : offs) {
        int32_t v = 0;
        if (Peek32(holder + o, v) && v > idx && v <= 1024) { countOff = o; return true; }
    }
    return false;
}
bool DiscoverEnemyList(std::string& msg) {
    const uintptr_t S = FindWorldChrStatic();
    uintptr_t W = 0;
    if (!S || !Peek64(S, W) || !W) { msg = "Автопоиск врагов: WorldChrBase пока недоступен (меню/загрузка?)."; return false; }
    if (!Peek64(W + 0x68, g_playerPtr) || !g_playerPtr) { msg = "Автопоиск врагов: игрок ещё не создан."; return false; }
    char list[96], count[96], skip[8];
    int idx = 0, co = 0;
    for (int k = 0; k < 0x400; k += 8) {                       // глубина 1
        if (ArrayHasPlayer(W + k, idx) && FindCount(W + k, idx, co)) {
            snprintf(list, sizeof(list), "@world, 0x%X", k);
            snprintf(count, sizeof(count), "@world, 0x%X", k + co);
            goto found;
        }
    }
    for (int k1 = 0; k1 < 0x400; k1 += 8) {                    // глубина 2
        uintptr_t B = 0;
        if (!Peek64(W + k1, B) || !Readable(B, 0x400)) continue;
        for (int k2 = 0; k2 < 0x400; k2 += 8) {
            if (ArrayHasPlayer(B + k2, idx) && FindCount(B + k2, idx, co)) {
                snprintf(list, sizeof(list), "@world, 0x%X, 0x%X", k1, k2);
                snprintf(count, sizeof(count), "@world, 0x%X, 0x%X", k1, k2 + co);
                goto found;
            }
        }
    }
    msg = "Автопоиск врагов: массив с игроком не найден. Задайте enemy_list/enemy_count вручную.";
    return false;
found:
    WritePrivateProfileStringA("offsets", "enemy_list", list, Ini().c_str());
    WritePrivateProfileStringA("offsets", "enemy_count", count, Ini().c_str());
    snprintf(skip, sizeof(skip), "%d", idx == 0 ? 1 : 0);
    if ((int)GetPrivateProfileIntA("offsets", "enemy_skip_first", -12345, Ini().c_str()) == -12345)
        WritePrivateProfileStringA("offsets", "enemy_skip_first", skip, Ini().c_str());
    msg = std::string("Автопоиск врагов: список найден (enemy_list = ") + list + ", игрок на позиции " + std::to_string(idx) + ").";
    return true;
}

void AutoSetup(ULONGLONG now) {
    static ULONGLONG next = 0;
    static int attempts = 0;
    if (g_autoDone || now < next) return;
    next = now + 2500;
    char b[96];
    bool changed = false;
    const int md = MapDataOffset();
    snprintf(b, sizeof(b), "@world, 0x68, 0x%X, 0x28, 0x10", md); changed |= FillIfEmpty("pos_x", b);
    snprintf(b, sizeof(b), "@world, 0x68, 0x%X, 0x28, 0x4", md);  changed |= FillIfEmpty("angle", b);
    snprintf(b, sizeof(b), "0x%X, 0x28, 0x10", md); changed |= FillIfEmpty("enemy_x", b);
    snprintf(b, sizeof(b), "0x%X, 0x28, 0x14", md); changed |= FillIfEmpty("enemy_y", b);
    snprintf(b, sizeof(b), "0x%X, 0x28, 0x18", md); changed |= FillIfEmpty("enemy_z", b);
    snprintf(b, sizeof(b), "0x%X, 0x28, 0x4", md);  changed |= FillIfEmpty("enemy_angle", b);
    if (changed) { CombatReloadCfg(); SetUi("Цепочки игрока и врагов созданы автоматически (по данным DSR-Gadget)."); return; }
    if (!OffsetKeyEmpty("enemy_list") && !OffsetKeyEmpty("enemy_count")) { g_autoDone = true; return; }
    std::string msg;
    if (DiscoverEnemyList(msg)) { CombatReloadCfg(); g_autoDone = true; }
    else if (++attempts >= 40) { g_autoDone = true; msg += " (попытки прекращены)"; }
    SetUi(msg);
}

bool Focused() {
    DWORD pid=0; GetWindowThreadProcessId(GetForegroundWindow(),&pid);
    return pid==GetCurrentProcessId();
}

void AutoRollTick(ULONGLONG now) {
    if (!Focused()) return;
    const bool toggle=g_cfg.toggleKey && (GetAsyncKeyState(g_cfg.toggleKey)&0x8000);
    if (toggle && !g_prevToggle) g_enabled=!g_enabled;
    g_prevToggle=toggle;
    if (g_cfg.bossesOnly) HandleMarkKeys();
    if (!g_enabled || now<g_nextRoll || now<g_idleUntil) return;

    PeerView me;
    // нет позиции / цепочек / списка врагов (меню, загрузка) — не долбим память каждые 8 мс
    if (!CanRoll() || !CoopMyPosition(me)) { g_idleUntil=now+250; return; }
    std::vector<EnemyView> enemies;
    if (!WorldEnemyPositions(enemies)) { g_idleUntil=now+250; return; }

    if (g_tracks.size()>512) {
        for (auto it=g_tracks.begin();it!=g_tracks.end();) {
            if (now>it->second.latest.ms+2000) it=g_tracks.erase(it); else ++it;
        }
    }
    if (!g_marked.empty()) {  // сущность исчезла из списка (смерть/выгрузка зоны) — метка больше не нужна
        std::set<uintptr_t> alive;
        for (const auto& e:enemies) alive.insert(e.ptr);
        for (auto it=g_marked.begin();it!=g_marked.end();) { if (!alive.count(*it)) it=g_marked.erase(it); else ++it; }
        g_markedCount=(int)g_marked.size();
    }
    {
        int bosses=0, ids=0;
        for (const auto& e:enemies) { if (e.entityId>0) ++ids; if (IsBoss(e)) ++bosses; }
        g_bossInView=bosses; g_idsRead=ids;
    }
    g_debug.clear();
    for (const auto& enemy:enemies) {
        if (!enemy.ptr) continue;
        if (g_cfg.bossesOnly && !IsBoss(enemy)) continue;  // обычных врагов пропускаем: не отслеживаем и не катимся
        Track& tr=g_tracks[enemy.ptr];
        const bool hasMotion=UpdateTrack(enemy,now,tr);
        if (!hasMotion) continue;
        float tContact=0,fx=0,fz=1;
        const bool threat=FindPredictedContact(enemy,me,tr,tContact,fx,fz);
        g_debug.push_back({enemy.x,enemy.y,enemy.z,fx,fz,tContact,threat});
        if (!threat) { tr.threatLatched=false; continue; }
        if (tContact*1000.0f > g_cfg.leadMs+35.0f || tr.threatLatched) continue;

        const float dx=enemy.x-me.x, dz=enemy.z-me.z;
        const float playerFx=std::sin(me.ang), playerFz=std::cos(me.ang);
        const bool threatFront=(playerFx*dx+playerFz*dz)>0.0f;
        const int direction=threatFront?1:0;
        if (g_cfg.animReq.valid()) {
            uintptr_t requestAddress=0;
            if (!Resolve(g_cfg.animReq,g_base,requestAddress)) continue;
            const int32_t command=700+g_cfg.rollClass*10+direction;
            if (!WriteAt<int32_t>(requestAddress,command)) continue;
        } else {
            TapRollKey();  // направление определяет игра: по текущему вводу движения (без ввода — шаг назад)
        }
        tr.threatLatched=true;
        g_nextRoll=now+(ULONGLONG)g_cfg.cooldownMs;
        break;
    }
    if (g_cfg.debugDraw) SaveSnap(me,enemies);
}
} // namespace

// LoadCfg меняет g_cfg (внутри вектор цепочки), а читает его поток логики: перечитываем только в нём
void ExtrasReloadCfg() { g_reload = true; }
bool ExtrasDebugActive() { return g_dbgOn; }
bool ExtrasWantsFast() { return g_loaded ? (g_enabled && CanRoll()) : true; }
bool ExtrasWantsPoll() { return !g_loaded || g_reload || !g_autoDone || CanRoll(); }
void ExtrasDrawDebug() {
    if (!g_dbgOn) return;
    DbgSnap sn;
    {
        std::lock_guard<std::mutex> l(g_dbgMx);
        sn = g_snap;
    }
    DrawDebugSnap(sn);
}
float ExtrasSpent() { return 0.0f; }
bool ExtrasNoDamageBuff() { return false; }

void ExtrasTick() {
    static ULONGLONG next=0;
    const ULONGLONG now=GetTickCount64();
    if (now<next) return;
    next=now+8;
    if (!g_base) g_base=(uintptr_t)GetModuleHandleA(nullptr);
    if (!g_loaded || g_reload.exchange(false)) { LoadCfg(); g_dbgOn = g_cfg.debugDraw; }
    AutoSetup(now);
    AutoRollTick(now);
}

void ExtrasUI() {
    ImGui::Separator();
    ImGui::Text("Автоматический перекат: %s",g_enabled?"включён":"выключен");
    ImGui::TextDisabled("NumPad 9 / toggle_key — переключение. Геометрия атак приблизительная.");
    ImGui::TextDisabled("Координаты и угол; без чтения анимаций и выносливости.");
    if (g_cfg.bossesOnly) {
        ImGui::Text("Режим: только боссы. В списке боссов сейчас: %d (ручных меток: %d, entity ID прочитано: %d)",
                    g_bossInView.load(), g_markedCount.load(), g_idsRead.load());
        ImGui::TextDisabled("NumPad 8 — пометить/снять босса рядом, NumPad 7 — сбросить метки.");
        if (g_idsRead.load() == 0)
            ImGui::TextDisabled("enemy_id не задан: автоопределение по entity ID не работает, используйте ручную метку.");
        std::string st; { std::lock_guard<std::mutex> l(g_uiMx); st = g_uiStatus; }
        if (!st.empty()) ImGui::TextWrapped("%s", st.c_str());
    } else {
        ImGui::TextDisabled("Режим: все враги (bosses_only=0).");
    }
}
