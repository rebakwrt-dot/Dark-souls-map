#include "dx11_hook.h"
#include "probe.h"

#include <cstdarg>
#include <cstdio>
#include <cstring>
#include <string>

namespace dx11 {

using PresentFn = HRESULT(STDMETHODCALLTYPE*)(IDXGISwapChain*, UINT, UINT);
using SamplerFn = HRESULT(STDMETHODCALLTYPE*)(ID3D11Device*, const D3D11_SAMPLER_DESC*, ID3D11SamplerState**);

static Callbacks g_cb;
static PresentFn g_origPresent = nullptr;
static SamplerFn g_origSampler = nullptr;

static volatile LONG g_faults = 0;
static volatile LONG g_skipSlow = 0;

// ---- диагностика: DSRMods\<имя dll>.hook.log (дописывается; присылайте его при вылетах/фризах) ----
static LONG g_logLock = 0;
static void LogLine(const char* fmt, ...) {
    char msg[512];
    va_list ap;
    va_start(ap, fmt);
    vsnprintf(msg, sizeof(msg), fmt, ap);
    va_end(ap);
    while (InterlockedExchange(&g_logLock, 1)) Sleep(0);
    HMODULE self = nullptr;
    GetModuleHandleExA(GET_MODULE_HANDLE_EX_FLAG_FROM_ADDRESS | GET_MODULE_HANDLE_EX_FLAG_UNCHANGED_REFCOUNT, (LPCSTR)&LogLine, &self);
    char path[MAX_PATH]{};
    GetModuleFileNameA(self, path, MAX_PATH);
    std::string p = path;
    size_t dot = p.find_last_of('.');
    if (dot != std::string::npos) p.resize(dot);
    p += ".hook.log";
    HANDLE f = CreateFileA(p.c_str(), FILE_APPEND_DATA, FILE_SHARE_READ | FILE_SHARE_WRITE, nullptr, OPEN_ALWAYS, FILE_ATTRIBUTE_NORMAL, nullptr);
    if (f != INVALID_HANDLE_VALUE) {
        SYSTEMTIME t{};
        GetLocalTime(&t);
        char line[640];
        int n = snprintf(line, sizeof(line), "[%02u:%02u:%02u.%03u] %s\r\n", t.wHour, t.wMinute, t.wSecond, t.wMilliseconds, msg);
        DWORD w = 0;
        if (n > 0) WriteFile(f, line, (DWORD)n, &w, nullptr);
        CloseHandle(f);
    }
    InterlockedExchange(&g_logLock, 0);
}

static double Ms(LONGLONG a, LONGLONG b) {
    static LARGE_INTEGER fq = [] { LARGE_INTEGER q; QueryPerformanceFrequency(&q); return q; }();
    return (double)(b - a) * 1000.0 / (double)fq.QuadPart;
}
static LONGLONG Now() { LARGE_INTEGER q; QueryPerformanceCounter(&q); return q.QuadPart; }

// Фатальные исключения (не пробы чтения памяти) пишем в лог: по ним видно, где именно падает игра.
static LONG CALLBACK Veh(PEXCEPTION_POINTERS p) {
    DWORD code = p->ExceptionRecord->ExceptionCode;
    bool fatalish = code == EXCEPTION_ACCESS_VIOLATION || code == EXCEPTION_ILLEGAL_INSTRUCTION ||
                    code == EXCEPTION_STACK_OVERFLOW || code == EXCEPTION_INT_DIVIDE_BY_ZERO ||
                    code == 0xC0000374 /*heap corruption*/ || code == 0xC0000409 /*fail fast*/ ||
                    code == EXCEPTION_PRIV_INSTRUCTION || code == EXCEPTION_IN_PAGE_ERROR;
    if (!fatalish || probe::inProbe) return EXCEPTION_CONTINUE_SEARCH;
    static volatile LONG n = 0;
    if (InterlockedIncrement(&n) > 40) return EXCEPTION_CONTINUE_SEARCH;
    void* addr = p->ExceptionRecord->ExceptionAddress;
    char mod[MAX_PATH] = "?";
    HMODULE hm = nullptr;
    if (GetModuleHandleExA(GET_MODULE_HANDLE_EX_FLAG_FROM_ADDRESS | GET_MODULE_HANDLE_EX_FLAG_UNCHANGED_REFCOUNT, (LPCSTR)addr, &hm) && hm) {
        GetModuleFileNameA(hm, mod, MAX_PATH);
        const char* b = strrchr(mod, '\\');
        if (b) memmove(mod, b + 1, strlen(b));
    }
    unsigned long long info1 = p->ExceptionRecord->NumberParameters > 1 ? (unsigned long long)p->ExceptionRecord->ExceptionInformation[1] : 0;
    LogLine("EXCEPTION code=0x%08lX at %p (%s+0x%llX) tid=%lu info=%llX", code, addr, mod,
            (unsigned long long)((uintptr_t)addr - (uintptr_t)hm), GetCurrentThreadId(), info1);
    return EXCEPTION_CONTINUE_SEARCH;
}

static void SafeCall(void (*f)(IDXGISwapChain*, UINT&), IDXGISwapChain* sc, UINT& sync) {
    __try { f(sc, sync); } __except (EXCEPTION_EXECUTE_HANDLER) { InterlockedIncrement(&g_faults); }
}
static void SafeCall2(void (*f)(IDXGISwapChain*), IDXGISwapChain* sc) {
    __try { f(sc); } __except (EXCEPTION_EXECUTE_HANDLER) { InterlockedIncrement(&g_faults); }
}

static HRESULT STDMETHODCALLTYPE HkPresent(IDXGISwapChain* sc, UINT sync, UINT flags) {
    static volatile LONG slowLogs = 0;
    bool live = g_faults < 5;  // после нескольких сбоев мод отключается, игра продолжает работать
    LONGLONG t0 = Now();
    if (live && g_cb.onPresent && !(flags & DXGI_PRESENT_TEST)) SafeCall(g_cb.onPresent, sc, sync);
    LONGLONG t1 = Now();
    HRESULT hr = g_origPresent(sc, sync, flags);
    LONGLONG t2 = Now();
    if (live && g_cb.onAfterPresent && !(flags & DXGI_PRESENT_TEST)) SafeCall2(g_cb.onAfterPresent, sc);
    LONGLONG t3 = Now();
    // «наш» код: до и после оригинального Present; сам Present (t1..t2) включает остальные хуки/VSync/GPU
    double mine = Ms(t0, t1) + Ms(t2, t3);
    if (InterlockedExchange(&g_skipSlow, 0)) return hr;  // кадр после паузы
    if ((mine > 8.0 || Ms(t1, t2) > 250.0) && InterlockedIncrement(&slowLogs) <= 25)
        LogLine("slow frame: our callbacks %.1f ms, Present %.1f ms (sync=%u flags=0x%X faults=%ld memFaults=%u)",
                mine, Ms(t1, t2), sync, flags, g_faults, probe::totalFaults.load());
    return hr;
}

static HRESULT STDMETHODCALLTYPE HkSampler(ID3D11Device* dev, const D3D11_SAMPLER_DESC* d, ID3D11SamplerState** out) {
    if (d && g_cb.onCreateSampler) {
        D3D11_SAMPLER_DESC c = *d;
        g_cb.onCreateSampler(c);
        return g_origSampler(dev, &c, out);
    }
    return g_origSampler(dev, d, out);
}

static bool Patch(void** slot, void* hook, void** orig) {
    DWORD old;
    if (!VirtualProtect(slot, sizeof(void*), PAGE_READWRITE, &old)) return false;
    *orig = *slot;
    *slot = hook;
    VirtualProtect(slot, sizeof(void*), old, &old);
    return true;
}

bool Install(const Callbacks& cb) {
    g_cb = cb;
    static bool vehOn = false;
    if (!vehOn) { vehOn = AddVectoredExceptionHandler(1, Veh) != nullptr; }
    LogLine("Install begin (onPresent=%d after=%d sampler=%d)", cb.onPresent != nullptr, cb.onAfterPresent != nullptr, cb.onCreateSampler != nullptr);
    // один установщик на весь процесс: имя общее для всех модов
    HANDLE mx = CreateMutexW(nullptr, FALSE, L"Local\\DSRMods_dx11_install");
    if (!mx) { LogLine("Install: CreateMutex failed %lu", GetLastError()); return false; }
    DWORD lockResult = WaitForSingleObject(mx, 10000);
    if (lockResult != WAIT_OBJECT_0 && lockResult != WAIT_ABANDONED) {
        LogLine("Install: mutex wait failed (%lu)", lockResult);
        CloseHandle(mx);
        return false;  // не трогаем общую DX11-таблицу без гарантированной блокировки
    }
    struct Rel { HANDLE m; ~Rel() { if (m) { ReleaseMutex(m); CloseHandle(m); } } } rel{mx};

    WNDCLASSEXW wc{};
    wc.cbSize = sizeof(wc);
    wc.lpfnWndProc = DefWindowProcW;
    wc.hInstance = GetModuleHandleW(nullptr);
    wc.lpszClassName = L"DSRModsDummy";
    RegisterClassExW(&wc);
    HWND hwnd = CreateWindowW(wc.lpszClassName, L"", WS_OVERLAPPEDWINDOW, 0, 0, 100, 100, nullptr, nullptr, wc.hInstance, nullptr);

    DXGI_SWAP_CHAIN_DESC sd{};
    sd.BufferCount = 1;
    sd.BufferDesc.Format = DXGI_FORMAT_R8G8B8A8_UNORM;
    sd.BufferUsage = DXGI_USAGE_RENDER_TARGET_OUTPUT;
    sd.OutputWindow = hwnd;
    sd.SampleDesc.Count = 1;
    sd.Windowed = TRUE;
    sd.SwapEffect = DXGI_SWAP_EFFECT_DISCARD;

    ID3D11Device* dev = nullptr;
    ID3D11DeviceContext* ctx = nullptr;
    IDXGISwapChain* sc = nullptr;
    HRESULT hr = D3D11CreateDeviceAndSwapChain(nullptr, D3D_DRIVER_TYPE_HARDWARE, nullptr, 0, nullptr, 0,
                                               D3D11_SDK_VERSION, &sd, &sc, &dev, nullptr, &ctx);
    bool ok = false;
    if (SUCCEEDED(hr)) {
        void** scVt = *reinterpret_cast<void***>(sc);
        void** devVt = *reinterpret_cast<void***>(dev);
        void* prev = scVt[8];
        ok = Patch(&scVt[8], (void*)HkPresent, (void**)&g_origPresent);  // IDXGISwapChain::Present
        LogLine("Present patched ok=%d previous=%p (если не в dxgi.dll — уже перехвачен другим модом/оверлеем)", ok, prev);
        if (ok && g_cb.onCreateSampler) {
            bool sok = Patch(&devVt[23], (void*)HkSampler, (void**)&g_origSampler);  // ID3D11Device::CreateSamplerState
            LogLine("CreateSamplerState patched ok=%d", sok);
        }
    } else {
        LogLine("Install: D3D11CreateDeviceAndSwapChain failed hr=0x%08lX", (unsigned long)hr);
    }
    if (ctx) ctx->Release();
    if (dev) dev->Release();
    if (sc) sc->Release();
    DestroyWindow(hwnd);
    UnregisterClassW(wc.lpszClassName, wc.hInstance);
    LogLine("Install end ok=%d", ok);
    return ok;
}

void SkipSlowLog() { InterlockedExchange(&g_skipSlow, 1); }

}  // namespace dx11
